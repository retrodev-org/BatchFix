﻿using System;

namespace BatchFixer
{
	class Program
	{
		static void Main(string[] args)
		{
			string inputState;

			// Gather state from user
			Console.Write("Input state: ");
			inputState = Console.Read().ToString();
			Console.WriteLine("Processing for " + inputState);
		}
	}
}
