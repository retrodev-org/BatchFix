﻿using System;
using System.Collections.Generic;

namespace BatchConfigConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MODE_CREATE = 1;
            const int MODE_ERROR = 0;
            const int MODE_EXIT = 9;
            const int MODE_PARSE = 2;
            const int MODE_PRINT = 7;

            int mode = MODE_ERROR;
            int newVarLength = 0;
            string input = null;
            string inputName = null;
            string newVarName = null;
            string newVarType = "string";
            List<string> varList = new List<string>();

            while (mode == MODE_CREATE || mode == MODE_PARSE || mode == MODE_ERROR)
            {
                while (mode == MODE_ERROR)
                {
                    Console.WriteLine("What would you like to do?");
                    Console.WriteLine("1. Create variable list");
                    Console.WriteLine("2. Parse XML variable list\n");
                    Console.Write("Your Choice: ");
                    input = Console.ReadLine();
                    if (Int32.TryParse(input, out mode) == true)
                    {
                        if (mode == MODE_CREATE)
                            mode = MODE_CREATE;
                        else if (mode == MODE_PARSE)
                            mode = MODE_PARSE;
                        else
                            mode = MODE_EXIT;
                    }
                    else
                        mode = MODE_ERROR;
                }                

                

                // Parse existing XML variable list


                // Create variable list
                if (mode == MODE_CREATE)
                {
                    Console.WriteLine("Enter each variable name, followed by the length. Type 'Print' to print the list or 'Exit' to exit.");
                    while (mode == MODE_CREATE)
                    {
                        Console.Write("Variable Name: ");
                        input = Console.ReadLine();

                        if (input == "print")
                        {
                            mode = MODE_PRINT;
                        }
                        else if (input == "exit")
                            mode = MODE_EXIT;
                        else
                        {
                            mode = MODE_CREATE;
                            inputName = input;

                            Console.Write("Length: ");
                            input = Console.ReadLine();

                            try
                            {
                                newVarLength = Int32.Parse(input);
                                newVarName = inputName;
                                // TODO newVarType update

                                string varBegin = "<" + newVarName + ">";
                                string varEnd = "</" + newVarName + ">";

                                string varType = "<type>" + newVarType + "</type>";
                                string varLength = "<length>" + newVarLength.ToString() + "</length>";
                                string varDescription = "<description>" + newVarName + "</DescriptionAttribute>";

                                varList.Add(varBegin);
                                varList.Add(varType);
                                varList.Add(varLength);
                                varList.Add(varDescription);
                                varList.Add(varEnd);
                            }
                            catch (Exception error)
                            {
                                if (input == "exit")
                                    Console.WriteLine("Thank you.");
                                else
                                    Console.WriteLine("Error: invalid length. Try again. Must be numeric. " + error);
                            }
                        }
                    } // end while(mode == MODE_CREATE)
                } // end 

                if (mode == MODE_PRINT)
                {
                    Console.Write("Print list? (Y/N) ");
                    input = Console.ReadLine();
                    if (input == "Y" || input == "y" || input == "yes" || input == "Yes")
                    {
                        foreach (var str in varList)
                        {
                            Console.WriteLine(str);
                        }

                        Console.Write("Start over? (Y/N) ");
                        input = Console.ReadLine();
                        if (input == "N" || input == "n" || input == "no" || input == "No")
                            mode = MODE_EXIT;
                        else
                            mode = MODE_CREATE;
                    }
                }
            } // end while(mode == MODE_CREATE || mode == MODE_PARSE || mode == MODE_PRINT)
        }
    }
}
