﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Constants;

namespace BatchFix
{
	public class Files
	{
		// todo file open, read, write, close utilities
		
		// OpenFileDialog
		// https://www.c-sharpcorner.com/uploadfile/mahesh/openfiledialog-in-C-Sharp/
		private System.Windows.Forms.OpenFileDialog openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
	}
}
