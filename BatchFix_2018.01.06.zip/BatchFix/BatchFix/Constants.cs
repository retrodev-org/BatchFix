﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Constants
{
	public class MyConst
	{
        // ALLOWED CHARACTERS
        public const string ALLOWED_CHARS   = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        public const string ALLOWED_DIGITS  = "0123456789";
        public const string INVALID_CHARS   = "";   // TODO establish disallowed invalid characters

        // CONSULTANT EF
        public const string EF_ABBREVIATION = "EF";
        public const string EF_NAME         = "Efficient Forms, LLC";
		public const string EF_ADDRESS		= "10499 West Bradford Rd, Suite 102";
		public const string EF_CITY		    = "Littleton";
		public const string EF_STATE		= "CO";
		public const string EF_ZIP			= "80127";
		public const string EF_PHONE		= "3037858600";
		public const string EF_FAX			= "3034849586";
		public const string EF_EMAIL		= "wotc@efficientforms.com";
		public const string EF_SIGNER		= "Dave Kenney";
		public const string EF_SIGNER_TITLE = "Dir WOTC Operations";

        // CONSULTANT NTC
        public const string NTC_ABBREVIATION = "NTC";
        public const string NTC_NAME        = "National Tax Credit";
		public const string NTC_ADDRESS	    = "1025 Rose Creek Dr PO Box 620-324";
		public const string NTC_CITY		= "Woodstock";
		public const string NTC_STATE		= "GA";
		public const string NTC_ZIP		    = "30189";
		public const string NTC_PHONE		= "8664996356";
		public const string NTC_FAX		    = "4043934468";
		public const string NTC_EMAIL		= "aankele@ntcusa.com";
		public const string NTC_SIGNER		= "Stephen Johnstone";
		public const string NTC_SIGNER_TITLE = "WOTC Coordinator";

        // Date formats
        public const int MMDDYY = 1;
        public const int MMDDYY_HYPHEN = 2;
        public const int MMDDYY_SLASH = 3;
        public const int MMDDYYYY = 4;
        public const int MMDDYYYY_HYPHEN = 5;
        public const int MMDDYYYY_SLASH = 6;
        public const int YYYYMMDD = 7;
        public const int YYYYMMDD_HYPHEN = 8;
        public const int YYYYMMDD_SLASH = 9;
		
		// DELIMITERS
		public const string DELMT_PIPE		= "|";
		public const string DELMT_COMMA	    = ",";
		public const string DELMT_HYPHEN	= "-";
		public const string DELMT_SPACE	    = " ";
        public const string DELMT_FWDSLASH = "/";

        // Minimum wages
        public const double WAGE_DEFAULT = 09.00;
        public const double MIN_AK = 09.84;
        public const double MIN_AL = WAGE_DEFAULT;
        public const double MIN_AR = 08.50;
        public const double MIN_AZ = 10.50;
        public const double MIN_CA = 11.00;
        public const double MIN_CO = 10.20;
        public const double MIN_CT = 10.10;
        public const double MIN_DC = 13.25;
        public const double MIN_DE = 08.25;
        public const double MIN_FL = 08.25;
        public const double MIN_GA = 05.15;
        public const double MIN_GUAM = 08.25;
        public const double MIN_HI = 10.10;
        public const double MIN_IA = 07.25;
        public const double MIN_ID = 07.25;
        public const double MIN_IL = 08.25;
        public const double MIN_IN = 07.25;
        public const double MIN_KS = 07.25;
        public const double MIN_KY = 07.25;
        public const double MIN_LA = WAGE_DEFAULT;
        public const double MIN_MA = 11.00;
        public const double MIN_MD = 10.10;
        public const double MIN_ME = 10.00;
        public const double MIN_MI = 09.25;
        public const double MIN_MN = 09.65;
        public const double MIN_MO = 07.85;
        public const double MIN_MS = WAGE_DEFAULT;
        public const double MIN_MT = 08.30;
        public const double MIN_NC = 07.25;
        public const double MIN_ND = 07.25;
        public const double MIN_NE = 09.00;
        public const double MIN_NH = WAGE_DEFAULT;
        public const double MIN_NJ = 08.60;
        public const double MIN_NM = 07.50;
        public const double MIN_NV = 08.25;
        public const double MIN_NY = 10.40;
        public const double MIN_OH = 08.30;
        public const double MIN_OK = 07.25;
        public const double MIN_OR = 10.75;
        public const double MIN_PA = 07.25;
        public const double MIN_PR = 07.25;
        public const double MIN_RI = 10.10;
        public const double MIN_SC = WAGE_DEFAULT;
        public const double MIN_SD = 08.85;
        public const double MIN_TN = WAGE_DEFAULT;
        public const double MIN_TX = 07.25;
        public const double MIN_UT = 07.25;
        public const double MIN_VA = 07.25;
        public const double MIN_VI = 10.50;
        public const double MIN_VT = 10.50;
        public const double MIN_WA = 11.50;
        public const double MIN_WI = 07.25;
        public const double MIN_WV = 08.75;
        public const double MIN_WY = 05.15;

        // STATES
        public const int	STATE_AK		= 1;
		public const int	STATE_AL		= 2;
		public const int	STATE_AR		= 3;
		public const int	STATE_AZ		= 4;
		public const int	STATE_CA		= 5;
		public const int	STATE_CO		= 6;
		public const int	STATE_CT		= 7;
		public const int	STATE_DC		= 8;
		public const int	STATE_DE		= 9;
		public const int	STATE_FL		= 10;
		public const int	STATE_GA		= 11;
		public const int	STATE_GUAM		= 12;
		public const int	STATE_HI		= 13;
		public const int	STATE_IA		= 14;
		public const int	STATE_ID		= 15;
		public const int	STATE_IL		= 16;
		public const int	STATE_IN		= 17;
		public const int	STATE_KS		= 18;
		public const int	STATE_KY		= 19;
		public const int	STATE_LA		= 20;
		public const int	STATE_MA		= 21;
		public const int	STATE_MD		= 22;
		public const int	STATE_ME		= 23;
		public const int	STATE_MI		= 24;
		public const int	STATE_MN		= 25;
		public const int	STATE_MO		= 26;
		public const int	STATE_MS		= 27;
		public const int	STATE_MT		= 28;
		public const int	STATE_NC		= 29;
		public const int	STATE_ND		= 30;
		public const int	STATE_NE		= 31;
		public const int	STATE_NH		= 32;
		public const int	STATE_NJ		= 33;
		public const int	STATE_NM		= 34;
		public const int	STATE_NV		= 35;
		public const int	STATE_NY		= 36;
		public const int	STATE_OH		= 37;
		public const int	STATE_OK		= 38;
		public const int	STATE_OR		= 39;
		public const int	STATE_PA		= 40;
		public const int	STATE_PR		= 41;
		public const int	STATE_RI		= 42;
		public const int	STATE_SC		= 43;
		public const int	STATE_SD		= 44;
		public const int	STATE_TN		= 45;
		public const int	STATE_TX		= 46;
		public const int	STATE_UT		= 47;
		public const int	STATE_VA		= 48;
		public const int	STATE_VI		= 49;
		public const int	STATE_VT		= 50;
		public const int	STATE_WA		= 51;
		public const int	STATE_WI		= 52;
		public const int	STATE_WV		= 53;
		public const int	STATE_WY		= 54;

        // TRUE-FALSE
        public const string TRUE_Y = "Y";
        public const string TRUE_WORD = "TRUE";
        public const string TRUE_NUM = "1";
        public const string FALSE_N = "N";
        public const string FALSE_WORD = "FALSE";
        public const string FALSE_NUM = "0";
	}
}
