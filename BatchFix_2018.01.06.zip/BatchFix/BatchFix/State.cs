﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Constants;

namespace BatchFix
{
	class State
	{
        // Does the state allow apps for out of state employees/employers?
        private bool outOfStateEmployee = true;
        private bool outOfStateEmployer = true;

        private string name;
		private string delimiter;			// delimiter symbol (comma, carat, or space)
		private string answerTrue;			// 1, Y, or TRUE - sets format for state
		private string answerFalse;			// 0, N, or FALSE - sets format for state
		private Array zipCodesRRC;			// list of zip codes that qualify for RRC
		private Array citiesEmpowerment;    // list of cities that are empowerment zones

        public void InitializeState(int thisState){

            // TODO load CitiesEmpowerment from RuralRenewalCounties.csv
            // TODO load ZipCodesRRC from EmpowermentZones.csv

            // Set specific values for states
            switch (thisState){
			    case MyConst.STATE_AK:
				    // TODO Verify these answers. This is just an example.
				    Name = "AK";
				    Delimiter = MyConst.DELMT_COMMA;
				    AnswerTrue = MyConst.TRUE_Y;
				    AnswerFalse = MyConst.FALSE_N;
				    break;
			    case MyConst.STATE_AL:
                    Name = "AL";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
				    break;
			    case MyConst.STATE_AR:
                    Name = "AR";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
			    case MyConst.STATE_AZ:
                    // TODO add this state
                    break;
			    case MyConst.STATE_CA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_CO:
                    Name = "CO";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
                case MyConst.STATE_CT:
                    // TODO add this state
                    break;
			    case MyConst.STATE_DC:
                    Name = "DC";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
                case MyConst.STATE_DE:
                    // TODO add this state
                    break;
			    case MyConst.STATE_FL:
                    // TODO add this state
                    break;
			    case MyConst.STATE_GA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_GUAM:
                    // TODO add this state
                    break;
                case MyConst.STATE_HI:
                    // TODO add this state
                    break;
                case MyConst.STATE_IA:
                    // TODO add this state
                    break;
                case MyConst.STATE_ID:
                    // TODO add this state
                    break;
			    case MyConst.STATE_IL:
                    // TODO add this state
                    break;
			    case MyConst.STATE_IN:
                    // TODO add this state
                    break;
			    case MyConst.STATE_KS:
                    // TODO add this state
                    break;
			    case MyConst.STATE_KY:
                    // TODO add this state
                    break;
			    case MyConst.STATE_LA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MD:
                    // TODO add this state
                    break;
			    case MyConst.STATE_ME:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MI:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MN:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MO:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MS:
                    // TODO add this state
                    break;
			    case MyConst.STATE_MT:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NC:
                    // TODO add this state
                    break;
			    case MyConst.STATE_ND:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NE:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NH:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NJ:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NM:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NV:
                    // TODO add this state
                    break;
			    case MyConst.STATE_NY:
                    // TODO add this state
                    break;
			    case MyConst.STATE_OH:
                    // TODO add this state
                    break;
			    case MyConst.STATE_OK:
                    Name = "OK";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
			    case MyConst.STATE_OR:
                    Name = "OR";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
                case MyConst.STATE_PA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_PR:
                    // TODO add this state
                    break;
			    case MyConst.STATE_RI:
                    // TODO add this state
                    break;
			    case MyConst.STATE_SC:
                    Name = "SC";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
                case MyConst.STATE_SD:
                    // TODO add this state
                    break;
			    case MyConst.STATE_TN:
                    // TODO add this state
                    break;
			    case MyConst.STATE_TX:
                    // TODO add this state
                    break;
			    case MyConst.STATE_UT:
                    // TODO add this state
                    break;
			    case MyConst.STATE_VA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_VT:
                    // TODO add this state
                    break;
			    case MyConst.STATE_WA:
                    // TODO add this state
                    break;
			    case MyConst.STATE_WI:
                    // TODO add this state
                    break;
			    case MyConst.STATE_WV:
                    Name = "WV";
                    Delimiter = MyConst.DELMT_SPACE;
                    AnswerTrue = MyConst.TRUE_Y;
                    AnswerFalse = MyConst.FALSE_N;
                    break;
                case MyConst.STATE_WY:
                    // TODO add this state
                    break;
		    } //end switch case state
	    } // end InitializeState

        // Getters and Setters
        public bool OutOfStateEmployee { get => outOfStateEmployee; set => outOfStateEmployee = value; }
        public bool OutOfStateEmployer { get => outOfStateEmployer; set => outOfStateEmployer = value; }
        public string Name { get => name; set => name = value; }
        public string Delimiter { get => delimiter; set => delimiter = value; }
        public string AnswerTrue { get => answerTrue; set => answerTrue = value; }
        public string AnswerFalse { get => answerFalse; set => answerFalse = value; }
        public Array ZipCodesRRC { get => zipCodesRRC; set => zipCodesRRC = value; }
        public Array CitiesEmpowerment { get => citiesEmpowerment; set => citiesEmpowerment = value; }

    } // end class State
}
