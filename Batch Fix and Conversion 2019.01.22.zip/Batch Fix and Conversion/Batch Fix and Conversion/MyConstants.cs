﻿using System;

namespace Batch_Fix_and_Conversion
{
    public class MyConst
    {
        // CONSULTANT EF
        public const string EF_NAME = "Efficient Forms, LLC";
        public const string EF_ADDRESS = "10499 West Bradford Rd, Suite 102";
        public const string EF_CITY = "Littleton";
        public const string EF_STATE = "CO";
        public const string EF_ZIP = "80127";
        public const string EF_PHONE = "3037858600";
        public const string EF_PHONE_DASH = "303-785-8600";
        public const string EF_FAX = "3034849586";
        public const string EF_EMAIL = "wotc@efficientforms.com";
        public const string EF_SIGNER = "Dave Kenney";
        public const string EF_SIGNER_TITLE = "Dir WOTC Operations";

        // CONSULTANT NTC
        public const string NTC_NAME = "National Tax Credit";
        public const string NTC_ADDRESS = "1025 Rose Creek Dr PO Box 620-324";
        public const string NTC_CITY = "Woodstock";
        public const string NTC_STATE = "GA";
        public const string NTC_ZIP = "30189";
        public const string NTC_PHONE = "8664996356";
        public const string NTC_PHONE_DASH = "866-499-6356";
        public const string NTC_FAX = "4043934468";
        public const string NTC_EMAIL = "aankele@ntcusa.com";
        public const string NTC_SIGNER = "Stephen Johnstone";
        public const string NTC_SIGNER_TITLE = "WOTC Coordinator";

        // TRUE-FALSE
        public const string TRUE_Y = "Y";
        public const string TRUE_WORD = "TRUE";
        public const string TRUE_NUM = "1";
        public const string FALSE_N = "N";
        public const string FALSE_WORD = "FALSE";
        public const string FALSE_NUM = "0";

        // DELIMITERS
        public const string DELMT_PIPE = "|";
        public const string DELMT_COMMA = ",";
        public const string DELMT_HYPHEN = "-";
        public const string DELMT_SPACE = " ";

        // STATES
        public const int STATE_AK = 1;
        public const int STATE_AL = 2;
        public const int STATE_AR = 3;
        public const int STATE_AZ = 4;
        public const int STATE_CA = 5;
        public const int STATE_CO = 6;
        public const int STATE_CT = 7;
        public const int STATE_DC = 8;
        public const int STATE_DE = 9;
        public const int STATE_FL = 10;
        public const int STATE_GA = 11;
        public const int STATE_GU = 12;
        public const int STATE_HI = 13;
        public const int STATE_IA = 14;
        public const int STATE_ID = 15;
        public const int STATE_IL = 16;
        public const int STATE_IN = 17;
        public const int STATE_KS = 18;
        public const int STATE_KY = 19;
        public const int STATE_LA = 20;
        public const int STATE_MA = 21;
        public const int STATE_MD = 22;
        public const int STATE_ME = 23;
        public const int STATE_MI = 24;
        public const int STATE_MN = 25;
        public const int STATE_MO = 26;
        public const int STATE_MS = 27;
        public const int STATE_MT = 28;
        public const int STATE_NC = 29;
        public const int STATE_ND = 30;
        public const int STATE_NE = 31;
        public const int STATE_NH = 32;
        public const int STATE_NJ = 33;
        public const int STATE_NM = 34;
        public const int STATE_NV = 35;
        public const int STATE_NY = 36;
        public const int STATE_OH = 37;
        public const int STATE_OK = 38;
        public const int STATE_OR = 39;
        public const int STATE_PA = 40;
        public const int STATE_PR = 41;
        public const int STATE_RI = 42;
        public const int STATE_SC = 43;
        public const int STATE_SD = 44;
        public const int STATE_TN = 45;
        public const int STATE_TX = 46;
        public const int STATE_UT = 47;
        public const int STATE_VA = 48;
        public const int STATE_VT = 49;
        public const int STATE_WA = 50;
        public const int STATE_WI = 51;
        public const int STATE_WV = 52;
        public const int STATE_WY = 53;
        public const int STATE_VI = 54;

        // Minimum wages
        public const double WAGE_DEFAULT = 9.00;

        // Input validation
        public const string VALID_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789//";
    }
}
