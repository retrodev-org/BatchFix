﻿using System;

namespace Batch_Fix_and_Conversion
{
    public class MyApp
    {
        // General Variables
        private string delimiter;
        private string positive;
        private string negative;
        private int recordFormat;
        private MyState submissionState;
        private bool isReady = false;

        // Application Variables
        private MyEmployee employee;
        private MyEmployer employer;

        private MyDate convictionDate;
        private MyDate dateOfBirth;
        private MyDate employeeSignDate8850;
        private MyDate employeeSignDate9061;
        private MyDate employerSignDate9061;
        private MyDate felConvictionDate;
        private MyDate felReleaseDate;
        private MyDate hireDate;
        private MyDate infoDate;
        private MyDate offerDate;
        private MyDate postmarkDate;
        private MyDate rehireDate;
        private MyDate releaseDate;
        private MyDate startDate;
        private MyDate unemploymentDeclarationDate;
        private MyDate unemploymentEndDate;
        private MyDate unemploymentStartDate;
        private string ageEligible;
        private string arraVetCategory;
        private string arraYouthCategory;
        private string consultantAddress;
        private string consultantCity;
        private string consultantEmail;
        private string consultantFax;
        private string consultantFEIN;
        private string consultantID;
        private string consultantName;
        private string consultantPhone;
        private string consultantSignerName;
        private string consultantSignerTitle;
        private string consultantState;
        private string consultantZipCode;
        private string employeeSignatureOnFile;
        private string employerCity;
        private string employerCounty;
        private string employerEmail;
        private string employerFax;
        private string employerFEIN;
        private string employerName;
        private string employerPhone;
        private string employerPhoneDash;
        private string employerPhoneExtension;
        private string employerState;
        private string employerStreet;
        private string employerStreet2;
        private string employerZip;
        private string empowermentZone;
        private string empowermentZoneSummerJob;
        private string felonFederalStateFS;
        private string felonFederalStatus;
        private string felonStateName;
        private string felonStateStatus;
        private string felonStatus;
        private string form9062;
        private string formCompletedBy;
        private string katrinaEmployee;
        private string katrinaEmployeeCity;
        private string katrinaEmployeeCounty;
        private string katrinaEmployeeState;
        private string katrinaEmployeeStreet;
        private string katrinaEmployeeZip;
        private string katrinaJobCounty;
        private string katrinaJobState;
        private string katrinaNewEmployee;
        private string occupationCodeONET;
        private string outOfStateBenCity;
        private string outOfStateBenRecipient;
        private string outOfStateBenState;
        private string pin8850;
        private string position;
        private string positionTitle;
        private string q1_8850;
        private string q2_8850;
        private string q3_8850;
        private string q4_8850;
        private string q5_8850;
        private string q6_8850;
        private string q7_8850;
        private string rehire;
        private string representativeName;
        private string requestID;
        private string ruralRenewalCountyName;
        private string ruralRenewalCountyStatus;
        private string signatureOnFileForm9175;
        private string snap01;
        private string snap02;
        private string snapCity;
        private string snapRecipient;
        private string snapState;
        private string sourceDocuments01;
        private string sourceDocuments02;
        private string sourceDocuments03;
        private string sourceDocuments04;
        private string supplementalSecurity;
        private string tanf01;
        private string tanf02;
        private string tanf03;
        private string tanf04;
        private string tanfRecipient;
        private string tanfState;
        private string targetGroup;
        private string unemploymentFederal_YN;
        private string unemploymentFedState_FS;
        private string unemploymentState_YN;
        private string unemploymentStateName;
        private string unemploymentStatus;
        private string version8850;
        private string version9061;
        private string veteran1Year;
        private string veteran4Weeks;
        private string veteran6Months;
        private string veteranDisabled;
        private string veteranSnapRecipient;
        private string veteranSnapState;
        private string veteranStatus;
        private string veteranSNAP;
        private string vocRehabAgency;
        private string vocRehabTicketToWork;
        private string vocRehabVeteranAffairs;
        private string vowToHireHeroes;
        private string wage = MyConst.WAGE_DEFAULT.ToString();
        private string wageCentsOnly;
        private string wageDollarsOnly;

        // Getters and Setters
        public int RecordFormat { get => recordFormat; set => recordFormat = value; }
        internal MyDate ConvictionDate { get => convictionDate; set => convictionDate = value; }
        internal MyDate DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        internal MyDate EmployeeSignDate8850 { get => employeeSignDate8850; set => employeeSignDate8850 = value; }
        internal MyDate EmployeeSignDate9061 { get => employeeSignDate9061; set => employeeSignDate9061 = value; }
        internal MyDate EmployerSignDate9061 { get => employerSignDate9061; set => employerSignDate9061 = value; }
        internal MyDate FelConvictionDate { get => felConvictionDate; set => felConvictionDate = value; }
        internal MyDate FelReleaseDate { get => felReleaseDate; set => felReleaseDate = value; }
        internal MyDate HireDate { get => hireDate; set => hireDate = value; }
        internal MyDate InfoDate { get => infoDate; set => infoDate = value; }
        internal MyDate OfferDate { get => offerDate; set => offerDate = value; }
        internal MyDate PostmarkDate { get => postmarkDate; set => postmarkDate = value; }
        internal MyDate RehireDate { get => rehireDate; set => rehireDate = value; }
        internal MyDate ReleaseDate { get => releaseDate; set => releaseDate = value; }
        internal MyDate StartDate { get => startDate; set => startDate = value; }
        internal MyDate UnemploymentDeclarationDate { get => unemploymentDeclarationDate; set => unemploymentDeclarationDate = value; }
        internal MyDate UnemploymentEndDate { get => unemploymentEndDate; set => unemploymentEndDate = value; }
        internal MyDate UnemploymentStartDate { get => unemploymentStartDate; set => unemploymentStartDate = value; }
        public string AgeEligible { get => ageEligible; set => ageEligible = value; }
        public string ArraVetCategory { get => arraVetCategory; set => arraVetCategory = value; }
        public string ArraYouthCategory { get => arraYouthCategory; set => arraYouthCategory = value; }
        public string ConsultantAddress { get => consultantAddress; set => consultantAddress = value; }
        public string ConsultantCity { get => consultantCity; set => consultantCity = value; }
        public string ConsultantEmail { get => consultantEmail; set => consultantEmail = value; }
        public string ConsultantFax { get => consultantFax; set => consultantFax = value; }
        public string ConsultantFEIN { get => consultantFEIN; set => consultantFEIN = value; }
        public string ConsultantID { get => consultantID; set => consultantID = value; }
        public string ConsultantName { get => consultantName; set => consultantName = value; }
        public string ConsultantPhone { get => consultantPhone; set => consultantPhone = value; }
        public string ConsultantSignerName { get => consultantSignerName; set => consultantSignerName = value; }
        public string ConsultantSignerTitle { get => consultantSignerTitle; set => consultantSignerTitle = value; }
        public string ConsultantState { get => consultantState; set => consultantState = value; }
        public string ConsultantZipCode { get => consultantZipCode; set => consultantZipCode = value; }
        public string EmployeeSignatureOnFile { get => employeeSignatureOnFile; set => employeeSignatureOnFile = value; }
        public string EmployerCity { get => employerCity; set => employerCity = value; }
        public string EmployerCounty { get => employerCounty; set => employerCounty = value; }
        public string EmployerEmail { get => employerEmail; set => employerEmail = value; }
        public string EmployerFax { get => employerFax; set => employerFax = value; }
        public string EmployerFEIN { get => employerFEIN; set => employerFEIN = value; }
        public string EmployerName { get => employerName; set => employerName = value; }
        public string EmployerPhone { get => employerPhone; set => employerPhone = value; }
        public string EmployerPhoneDash { get => employerPhoneDash; set => employerPhoneDash = value; }
        public string EmployerPhoneExtension { get => employerPhoneExtension; set => employerPhoneExtension = value; }
        public string EmployerState { get => employerState; set => employerState = value; }
        public string EmployerStreet { get => employerStreet; set => employerStreet = value; }
        public string EmployerStreet2 { get => employerStreet2; set => employerStreet2 = value; }
        public string EmployerZip { get => employerZip; set => employerZip = value; }
        public string EmpowermentZone { get => empowermentZone; set => empowermentZone = value; }
        public string EmpowermentZoneSummerJob { get => empowermentZoneSummerJob; set => empowermentZoneSummerJob = value; }
        public string FelonFederalStateFS { get => felonFederalStateFS; set => felonFederalStateFS = value; }
        public string FelonFederalStatus { get => felonFederalStatus; set => felonFederalStatus = value; }
        public string FelonStateName { get => felonStateName; set => felonStateName = value; }
        public string FelonStateStatus { get => felonStateStatus; set => felonStateStatus = value; }
        public string FelonStatus { get => felonStatus; set => felonStatus = value; }
        public string Form9062 { get => form9062; set => form9062 = value; }
        public string FormCompletedBy { get => formCompletedBy; set => formCompletedBy = value; }
        public string KatrinaEmployee { get => katrinaEmployee; set => katrinaEmployee = value; }
        public string KatrinaEmployeeCity { get => katrinaEmployeeCity; set => katrinaEmployeeCity = value; }
        public string KatrinaEmployeeCounty { get => katrinaEmployeeCounty; set => katrinaEmployeeCounty = value; }
        public string KatrinaEmployeeState { get => katrinaEmployeeState; set => katrinaEmployeeState = value; }
        public string KatrinaEmployeeStreet { get => katrinaEmployeeStreet; set => katrinaEmployeeStreet = value; }
        public string KatrinaEmployeeZip { get => katrinaEmployeeZip; set => katrinaEmployeeZip = value; }
        public string KatrinaJobCounty { get => katrinaJobCounty; set => katrinaJobCounty = value; }
        public string KatrinaJobState { get => katrinaJobState; set => katrinaJobState = value; }
        public string KatrinaNewEmployee { get => katrinaNewEmployee; set => katrinaNewEmployee = value; }
        public string OccupationCodeONET { get => occupationCodeONET; set => occupationCodeONET = value; }
        public string OutOfStateBenCity { get => outOfStateBenCity; set => outOfStateBenCity = value; }
        public string OutOfStateBenRecipient { get => outOfStateBenRecipient; set => outOfStateBenRecipient = value; }
        public string OutOfStateBenState { get => outOfStateBenState; set => outOfStateBenState = value; }
        public string Pin8850 { get => pin8850; set => pin8850 = value; }
        public string Position { get => position; set => position = value; }
        public string PositionTitle { get => positionTitle; set => positionTitle = value; }
        public string Q1_8850 { get => q1_8850; set => q1_8850 = value; }
        public string Q2_8850 { get => q2_8850; set => q2_8850 = value; }
        public string Q3_8850 { get => q3_8850; set => q3_8850 = value; }
        public string Q4_8850 { get => q4_8850; set => q4_8850 = value; }
        public string Q5_8850 { get => q5_8850; set => q5_8850 = value; }
        public string Q6_8850 { get => q6_8850; set => q6_8850 = value; }
        public string Q7_8850 { get => q7_8850; set => q7_8850 = value; }
        public string Rehire { get => rehire; set => rehire = value; }
        public string RepresentativeName { get => representativeName; set => representativeName = value; }
        public string RequestID { get => requestID; set => requestID = value; }
        public string RuralRenewalCountyName { get => ruralRenewalCountyName; set => ruralRenewalCountyName = value; }
        public string RuralRenewalCountyStatus { get => ruralRenewalCountyStatus; set => ruralRenewalCountyStatus = value; }
        public string SignatureOnFileForm9175 { get => signatureOnFileForm9175; set => signatureOnFileForm9175 = value; }
        public string Snap01 { get => snap01; set => snap01 = value; }
        public string Snap02 { get => snap02; set => snap02 = value; }
        public string SnapCity { get => snapCity; set => snapCity = value; }
        public string SnapRecipient { get => snapRecipient; set => snapRecipient = value; }
        public string SnapState { get => snapState; set => snapState = value; }
        public string SourceDocuments01 { get => sourceDocuments01; set => sourceDocuments01 = value; }
        public string SourceDocuments02 { get => sourceDocuments02; set => sourceDocuments02 = value; }
        public string SourceDocuments03 { get => sourceDocuments03; set => sourceDocuments03 = value; }
        public string SourceDocuments04 { get => sourceDocuments04; set => sourceDocuments04 = value; }
        public string SupplementalSecurity { get => supplementalSecurity; set => supplementalSecurity = value; }
        public string Tanf01 { get => tanf01; set => tanf01 = value; }
        public string Tanf02 { get => tanf02; set => tanf02 = value; }
        public string Tanf03 { get => tanf03; set => tanf03 = value; }
        public string Tanf04 { get => tanf04; set => tanf04 = value; }
        public string TanfRecipient { get => tanfRecipient; set => tanfRecipient = value; }
        public string TanfState { get => tanfState; set => tanfState = value; }
        public string TargetGroup { get => targetGroup; set => targetGroup = value; }
        public string UnemploymentFederal_YN { get => unemploymentFederal_YN; set => unemploymentFederal_YN = value; }
        public string UnemploymentFedState_FS { get => unemploymentFedState_FS; set => unemploymentFedState_FS = value; }
        public string UnemploymentState_YN { get => unemploymentState_YN; set => unemploymentState_YN = value; }
        public string UnemploymentStateName { get => unemploymentStateName; set => unemploymentStateName = value; }
        public string UnemploymentStatus { get => unemploymentStatus; set => unemploymentStatus = value; }
        public string Version8850 { get => version8850; set => version8850 = value; }
        public string Version9061 { get => version9061; set => version9061 = value; }
        public string Veteran1Year { get => veteran1Year; set => veteran1Year = value; }
        public string Veteran4Weeks { get => veteran4Weeks; set => veteran4Weeks = value; }
        public string Veteran6Months { get => veteran6Months; set => veteran6Months = value; }
        public string VeteranDisabled { get => veteranDisabled; set => veteranDisabled = value; }
        public string VeteranSnapRecipient { get => veteranSnapRecipient; set => veteranSnapRecipient = value; }
        public string VeteranSnapState { get => veteranSnapState; set => veteranSnapState = value; }
        public string VeteranStatus { get => veteranStatus; set => veteranStatus = value; }
        public string VeteranSNAP { get => veteranSNAP; set => veteranSNAP = value; }
        public string VocRehabAgency { get => vocRehabAgency; set => vocRehabAgency = value; }
        public string VocRehabTicketToWork { get => vocRehabTicketToWork; set => vocRehabTicketToWork = value; }
        public string VocRehabVeteranAffairs { get => vocRehabVeteranAffairs; set => vocRehabVeteranAffairs = value; }
        public string VowToHireHeroes { get => vowToHireHeroes; set => vowToHireHeroes = value; }
        public string Wage { get => wage; set => wage = value; }
        public string WageCentsOnly { get => wageCentsOnly; set => wageCentsOnly = value; }
        public string WageDollarsOnly { get => wageDollarsOnly; set => wageDollarsOnly = value; }
        public bool IsReady { get => isReady; set => isReady = value; }
        public string Delimiter { get => delimiter; set => delimiter = value; }
        public string Positive { get => positive; set => positive = value; }
        public string Negative { get => negative; set => negative = value; }
        public MyEmployee Employee { get => employee; set => employee = value; }
        public MyEmployer Employer { get => employer; set => employer = value; }
        public MyState SubmissionState { get => submissionState; set => submissionState = value; }

        public MyApp(int stateSelector)
        {
        }
        
        public void LoadApplicationToState(int stateSelector)
        {
            // TODO format application for state and load into list
            throw new NotImplementedException();
        }

        public bool ValidateApplication(int stateSelector)
        {
            // Validate employee information
            IsReady = ValidateEmployee();

            // Validate employer, consultant, etc
            if (IsReady)
                IsReady = ValidateEmployer();

            // Veteran Status
            if (VeteranStatus == Positive)
            {
                if (Q3_8850 == Negative && Veteran1Year == Negative && Veteran6Months == Negative && VeteranDisabled == Negative && Veteran4Weeks == Negative)
                {
                    if (AskUserVeteranStatus() == true)
                    {
                        // TODO implement message box answers about veteran target groups
                    }
                }
                
            } else
            { // if veteran status == false
                // If vet unemployed 4 weeks is marked
                if (Veteran4Weeks == Positive)
                {
                    Q2_8850 = Positive;
                    VeteranStatus = Positive;
                    IsReady = true;
                }

                // If vet disabled, left service within one year, or unemployed 6 months is marked
                if (Q3_8850 == Positive || Veteran1Year == Positive || Veteran6Months == Positive || VeteranDisabled == Positive)
                {
                    VeteranStatus = Positive;

                    if (Q3_8850 == Positive)
                        Veteran6Months = Positive;
                    IsReady = true;

                    // If left svc within one year, must also be disabled
                    if (Veteran1Year == Positive)
                    {
                        Q4_8850 = Positive;
                        VeteranDisabled = Positive;
                        IsReady = true;
                    }

                    // Mark 8850 question 5 if disabled vet and unempl 6 months are both true
                    if (Veteran6Months == Positive && VeteranDisabled == Positive)
                    {
                        Q5_8850 = Positive;
                        IsReady = true;
                    }
                        
                }

                // if Vet Status still false and one of the target groups is true
                if (VeteranStatus == Negative && (Q3_8850 == Positive || Veteran1Year == Positive || Veteran6Months == Positive || VeteranDisabled == Positive || Veteran4Weeks == Positive))
                    VeteranStatus = Positive;
            } // end veteran status check

            // SNAP Answers
            if (Snap01 == Positive || Snap02 == Positive)
            {
                Snap01 = Positive;
                Snap02 = Positive;

                if (SnapRecipient.Trim() == "")
                    SnapRecipient = Employee.GetNameFull();

                if (SnapState.Trim() == "")
                    SnapState = Employee.State;
            } // end SNAP

            // TANF Answers
            if (Tanf01 == Positive || Tanf02 == Positive || Tanf03 == Positive || Tanf04 == Positive)
            {
                Q6_8850 = Positive;

                Tanf01 = Positive;
                Tanf02 = Positive;
                Tanf03 = Positive;
                Tanf04 = Positive;

                if (TanfRecipient.Trim() == "")
                    TanfRecipient = Employee.GetNameFull();

                if (TanfState.Trim() == "")
                    TanfState = Employee.State;

                IsReady = true;
            } // end TANF

            /* Vocational Rehabilitation
             * If any voc rehab answer is true, mark all true unless the state is known to reject multiple true answers
             */
            if (VocRehabAgency == Positive || VocRehabTicketToWork == Positive || VocRehabVeteranAffairs == Positive)
            {
                // Exclude the states that only accept one Voc rehab answer
                if (stateSelector == MyConst.STATE_PA || stateSelector == MyConst.STATE_TN)
                {
                    if (VeteranStatus == Positive)
                    {
                        VocRehabVeteranAffairs = Positive;
                        VocRehabAgency = Negative;
                        VocRehabTicketToWork = Negative;
                    }
                    else
                    {
                        VocRehabAgency = Positive;
                        VocRehabTicketToWork = Negative;
                        VocRehabVeteranAffairs = Negative;
                    }
                // Set all available voc rehab categories to true
                } else {
                    VocRehabAgency = Positive;
                    VocRehabTicketToWork = Positive;

                    if (VeteranStatus == Positive)
                        VocRehabVeteranAffairs = Positive;
                    else
                        VocRehabVeteranAffairs = Negative;
                }
            } // end Vocational Rehabilitation

            // Ex-Felon
            if (FelonStatus == Positive)

            // If IsReady remains true, return true and confirm app valid
            return IsReady;
        }

        private bool AskUserVeteranStatus()
        {
            // TODO Ask user to verify veteran status and target group(s) via checkboxes and text boxes for primary benefit recipient name & state
            throw new NotImplementedException("Not implemented: Gather veteran status and target groups from user.");
        }

        public bool ValidateEmployee()
        {
            // Trim employee name elements. Padding length occurs at the state level when adding an app to the batch list
            if (Employee.FirstName.Trim().Length < 1)
            {
                // TODO request full name and address from user
                throw new NotImplementedException("Employee first name cannot be blank: " + Employee.LastName + GetSSNLast4());
            }
            else
                Employee.FirstName = Employee.FirstName.Trim();

            if (Employee.LastName.Trim().Length < 1)
            {
                // TODO request full name and address from user
                throw new NotImplementedException("Employee last name cannot be blank: " + Employee.FirstName + " (" + GetSSNLast4() + "), " + Employer.Fein);
            }
            else
                Employee.LastName = Employee.LastName.Trim();

            // Social Security Number
            Employee.Social.Replace("-", "");           // Remove hyphen(s)
            Employee.Social = Employee.Social.Trim();   // Remove leading / trailing spaces

            if (Employee.Social.Length > 0)
                Employee.Social = AddLeadingZeros(Employee.Social, 9);

            if (Employee.Social.Length < 1 || Employee.Social == "123456789" || Employee.Social == "987654321")
            {
                // TODO Request SSN from user
                throw new NotImplementedException("Employee SSN cannot be blank: " + Employee.GetNameFull());
            }

            // Phone number
            Employee.Phone = Employee.Phone.Trim();
            foreach (char a in Employee.Phone)
            {
                // Substitute hyphen for invalid characters
                if (char.IsDigit(a) == false)
                {
                    Employee.Phone.Replace(a, '-');
                }
            }

            // Remove hyphen(s)
            Employee.Phone.Replace("-", "");

            // If employee phone is invalid
            if (Employee.Phone.Length != 10)
            {
                Employee.Phone = AddBlankSpaces(10);
            }

            // Address Information
            if (Employee.Street.Trim().Length < 1 && Employee.Street2.Trim().Length > 5)
            { // if employee entered info in street 2 instead of street 1, move the info to street 1
                Employee.Street = Employee.Street2.Trim();
                Employee.Street2 = "";
            }

            if (Employee.State.Trim() == "" || Employee.City.Trim() == ""
                || (Employee.Street.Trim() == "" && Employee.Street2.Trim() == ""))
            {
                // TODO request full address, give option to enter name, etc.
                // add a period to the address so it will be accepted
                throw new NotImplementedException("Employee address cannot be incomplete: " + Employee.LastName + GetSSNLast4());
            }

            return true;
        }

        // Validate employer and consultant
        public bool ValidateEmployer()
        {
            // TODO Validate employer & consultant info
            throw new NotImplementedException();

            // return IsReady;
        }

        // Will substitute default phone number if given phone is invalid
        public void CheckEmployerPhone()
        {
            // If phone is not present or invalid (less than 10 chars), substitute consultant phone number 
            if (Employer.Phone == null || Employer.Phone.Length < 10)
            {
                // Auto populate default phone num for NTC, EF
                if (ConsultantName == "NTC")
                {
                    Employer.Phone = MyConst.NTC_PHONE;
                }
                else
                {
                    Employer.Phone = MyConst.EF_PHONE;
                }
            }
        }


        private string GetSSNLast4()
        {
            return Employee.Social.Substring(Employee.Social.Trim().Length - 4);
        }

        public string AddTrailingSpaces(string input, int count)
        {
            while (input.Length < count)
                input = input + " ";
            return input;
        }

        public string AddBlankSpaces(int count)
        {
            string spaces = "";
            while (spaces.Length < count)
                spaces = spaces + " ";
            return spaces;
        }

        public string AddLeadingZeros(string input, int length)
        {
            while (input.Length < length)
                input = "0" + input;

            return input;
        }
    }
}
