﻿using System;
using System.Collections.Generic;

namespace Batch_Fix_and_Conversion
{
    public class MyBatchFile
    {
        private MyState stateOfSubmission;
        private string errorConfirmationMessage;
        private string logMessage;
        private MyConsultant thisConsultant;
        private List<MyApp> appsErrorList;
        private List<MyApp> appList;
        private List<MyApp> appListFormatted;
        private List<MyApp> appsNeedInfoList;
        private bool isReady = true;

        /* Interpret state abbreviation string into constant state values, 
         * then initialize the state with delimiter, minimum wage, true/false values
         */
        public MyBatchFile(string stateAbbreviation)
        {
            // Set up list of applications
            AppList = new List<MyApp>();
            AppsErrorList = new List<MyApp>();
            AppsNeedInfoList = new List<MyApp>();

            /* Interpret state abbreviation string into constant state values, 
             * then initialize the state with delimiter, minimum wage, true/false values
             */
            if (stateAbbreviation == "AK")
                StateOfSubmission = new MyState(MyConst.STATE_AK);
            if (stateAbbreviation == "AL")
                StateOfSubmission = new MyState(MyConst.STATE_AL);
            if (stateAbbreviation == "AR")
                StateOfSubmission = new MyState(MyConst.STATE_AR);
            if (stateAbbreviation == "AZ")
                StateOfSubmission = new MyState(MyConst.STATE_AZ);
            if (stateAbbreviation == "CA")
                StateOfSubmission = new MyState(MyConst.STATE_CA);
            if (stateAbbreviation == "CO")
                StateOfSubmission = new MyState(MyConst.STATE_CO);
            if (stateAbbreviation == "CT")
                StateOfSubmission = new MyState(MyConst.STATE_CT);
            if (stateAbbreviation == "DC")
                StateOfSubmission = new MyState(MyConst.STATE_DC);
            if (stateAbbreviation == "DE")
                StateOfSubmission = new MyState(MyConst.STATE_DE);
            if (stateAbbreviation == "FL")
                StateOfSubmission = new MyState(MyConst.STATE_FL);
            if (stateAbbreviation == "GA")
                StateOfSubmission = new MyState(MyConst.STATE_GA);
            if (stateAbbreviation == "GU")
                StateOfSubmission = new MyState(MyConst.STATE_GU);
            if (stateAbbreviation == "HI")
                StateOfSubmission = new MyState(MyConst.STATE_HI);
            if (stateAbbreviation == "IA")
                StateOfSubmission = new MyState(MyConst.STATE_IA);
            if (stateAbbreviation == "ID")
                StateOfSubmission = new MyState(MyConst.STATE_ID);
            if (stateAbbreviation == "IL")
                StateOfSubmission = new MyState(MyConst.STATE_IL);
            if (stateAbbreviation == "IN")
                StateOfSubmission = new MyState(MyConst.STATE_IN);
            if (stateAbbreviation == "KS")
                StateOfSubmission = new MyState(MyConst.STATE_KS);
            if (stateAbbreviation == "KY")
                StateOfSubmission = new MyState(MyConst.STATE_KY);
            if (stateAbbreviation == "LA")
                StateOfSubmission = new MyState(MyConst.STATE_LA);
            if (stateAbbreviation == "MA")
                StateOfSubmission = new MyState(MyConst.STATE_MA);
            if (stateAbbreviation == "MD")
                StateOfSubmission = new MyState(MyConst.STATE_MD);
            if (stateAbbreviation == "ME")
                StateOfSubmission = new MyState(MyConst.STATE_ME);
            if (stateAbbreviation == "MI")
                StateOfSubmission = new MyState(MyConst.STATE_MI);
            if (stateAbbreviation == "MN")
                StateOfSubmission = new MyState(MyConst.STATE_MN);
            if (stateAbbreviation == "MO")
                StateOfSubmission = new MyState(MyConst.STATE_MO);
            if (stateAbbreviation == "MS")
                StateOfSubmission = new MyState(MyConst.STATE_MS);
            if (stateAbbreviation == "MT")
                StateOfSubmission = new MyState(MyConst.STATE_MT);
            if (stateAbbreviation == "NC")
                StateOfSubmission = new MyState(MyConst.STATE_NC);
            if (stateAbbreviation == "ND")
                StateOfSubmission = new MyState(MyConst.STATE_ND);
            if (stateAbbreviation == "NE")
                StateOfSubmission = new MyState(MyConst.STATE_NE);
            if (stateAbbreviation == "NH")
                StateOfSubmission = new MyState(MyConst.STATE_NH);
            if (stateAbbreviation == "NJ")
                StateOfSubmission = new MyState(MyConst.STATE_NJ);
            if (stateAbbreviation == "NM")
                StateOfSubmission = new MyState(MyConst.STATE_NM);
            if (stateAbbreviation == "NV")
                StateOfSubmission = new MyState(MyConst.STATE_NV);
            if (stateAbbreviation == "NY")
                StateOfSubmission = new MyState(MyConst.STATE_NY);
            if (stateAbbreviation == "OH")
                StateOfSubmission = new MyState(MyConst.STATE_OH);
            if (stateAbbreviation == "OK")
                StateOfSubmission = new MyState(MyConst.STATE_OK);
            if (stateAbbreviation == "OR")
                StateOfSubmission = new MyState(MyConst.STATE_OR);
            if (stateAbbreviation == "PA")
                StateOfSubmission = new MyState(MyConst.STATE_PA);
            if (stateAbbreviation == "PR")
                StateOfSubmission = new MyState(MyConst.STATE_PR);
            if (stateAbbreviation == "RI")
                StateOfSubmission = new MyState(MyConst.STATE_RI);
            if (stateAbbreviation == "SC")
                StateOfSubmission = new MyState(MyConst.STATE_SC);
            if (stateAbbreviation == "SD")
                StateOfSubmission = new MyState(MyConst.STATE_SD);
            if (stateAbbreviation == "TN")
                StateOfSubmission = new MyState(MyConst.STATE_TN);
            if (stateAbbreviation == "TX")
                StateOfSubmission = new MyState(MyConst.STATE_TX);
            if (stateAbbreviation == "UT")
                StateOfSubmission = new MyState(MyConst.STATE_UT);
            if (stateAbbreviation == "VA")
                StateOfSubmission = new MyState(MyConst.STATE_VA);
            if (stateAbbreviation == "VT")
                StateOfSubmission = new MyState(MyConst.STATE_VT);
            if (stateAbbreviation == "WA")
                StateOfSubmission = new MyState(MyConst.STATE_WA);
            if (stateAbbreviation == "WI")
                StateOfSubmission = new MyState(MyConst.STATE_WI);
            if (stateAbbreviation == "WV")
                StateOfSubmission = new MyState(MyConst.STATE_WV);
            if (stateAbbreviation == "WY")
                StateOfSubmission = new MyState(MyConst.STATE_WY);

            // Validate application, all fields
            foreach (MyApp app in appList)
            {
                if (app.ValidateApplication(StateOfSubmission.StateIdentifier) == true)
                {
                    // Format application for state and save to new list of formatted apps
                    AppListFormatted.Add(FormatApplication(app, StateOfSubmission));
                } else
                {
                    AppsErrorList.Add(app);
                    // TODO Report from app's list of errors
                    throw new NotImplementedException("Unable to resolve error in app for " 
                        + app.Employee.GetNameFull() + " (" 
                        + app.Employee.Social.Substring(app.Employee.Social.Length - 4) 
                        + ") FEIN " + app.Employer.Fein);
                }

                // Format for the submission state
                AppListFormatted.Add(FormatApplication(app, StateOfSubmission));
            }
        }

        private MyApp FormatApplication(MyApp appOriginal, MyState thisState)
        {
            MyApp appFormatted = new MyApp(thisState.StateIdentifier);
            // TODO Format application to be written to file for state of submission
            throw new NotImplementedException();
        }

        private bool ValidateApplication(MyApp app, int submissionState)
        {
            IsReady = ValidateEmployee();

            if (IsReady == true)
                IsReady = app.Employer.IsReady;
            else
                MyString.WriteError("Fail on Employee validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateState();
            else
                MyString.WriteError("Fail on State validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateDates();
            else
                MyString.WriteError("Fail on Dates validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateRehire();
            else
                MyString.WriteError("Fail on Rehire validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateTargetGroups(app);
            else
                MyString.WriteError("Fail on Target Group validation for request ID " + app.RequestID);

            return IsReady;
        }

        private bool ValidateEmployee()
        {
            throw new NotImplementedException();
        }

        // Validators
        private bool CheckAddress(MyEmployer employer)
        {
            // TODO validating CheckAddress() characters

            // Default state is true, updated if either address 1 or 2 fails validation
            bool isReady = true;
            int index = 0;

            foreach (char a in employer.Street1.ToCharArray())
            {
                if (!MyConst.VALID_CHARACTERS.Contains(a.ToString()))
                {
                    Console.WriteLine("Street 1: replaced character " + a.ToString() + " in space " + index + ".");
                    employer.Street1.Replace(a, ' ');
                }
                index++;
            }

            Console.WriteLine("Fail on Employer City validation.");
            isReady = false;

            return isReady;
        }

        private bool ValidateTargetGroups(MyApp app)
        {
            // TODO check for all N, lacking target group. If is ready, return true.
            return true;
        }

        private bool ValidateRehire()
        {
            throw new NotImplementedException();
        }

        private bool ValidateDates()
        {
            throw new NotImplementedException();
        }

        private bool ValidateState()
        {
            throw new NotImplementedException();
        }

        private bool ValidateConsultant()
        {
            throw new NotImplementedException();
        }

        public string ErrorConfirmationMessage { get => errorConfirmationMessage; set => errorConfirmationMessage = value; }
        public string LogMessage { get => logMessage; set => logMessage = value; }
        internal MyState StateOfSubmission { get => stateOfSubmission; set => stateOfSubmission = value; }
        internal MyConsultant ThisConsultant { get => thisConsultant; set => thisConsultant = value; }
        internal List<MyApp> AppList { get => appList; set => appList = value; }

        public bool IsReady { get => isReady; set => isReady = value; }
        public List<MyApp> AppsNeedInfoList { get => appsNeedInfoList; set => appsNeedInfoList = value; }
        public List<MyApp> AppListFormatted { get => appListFormatted; set => appListFormatted = value; }
        public List<MyApp> AppsErrorList { get => appsErrorList; set => appsErrorList = value; }
    }
}
