﻿using System;

namespace MyString
{
    public static class MyExtensions
    {
        public static string AddLeadingZeros(this String str, int length)
        {
            str = str.Trim();
            while (str.Length < length)
                str = "0" + str;

            return str;
        }

        // Will pad beginning of FEIN with zeros until it reaches 9 digits
        public static void CheckFEIN(this String fein)
        {
            fein.AddLeadingZeros(9);
        }

        // Will pad beginning of Zip with zeros until it reaches 5 digits
        public static void CheckZip(this String zipCode)
        {
            zipCode.AddLeadingZeros(5);
        }
    }
}
