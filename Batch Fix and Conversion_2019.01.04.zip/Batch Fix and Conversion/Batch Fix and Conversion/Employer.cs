﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Consultant;
using MyString;

namespace Employer
{
    /// <summary>
	/// Class:	MyEmployer
	/// Use:	Read and store employer information. (EIN, Address, Phone, etc.)
	/// </summary>
	public static class MyEmployer
    {
        // Input validation
        public readonly String VALID_CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789//";


        // Variables
        private String fein;
        private String name;
        private String street1;
        private String street2;
        private String city;
        private String state;
        private String zipCode;
        private String phone;
        private MyConsultant thisConsultant;

        private bool isReady;

        public String Fein { get => fein; set => fein = value; }
        public String Name { get => name; set => name = value; }
        public String Street1 { get => street1; set => street1 = value; }
        public String Street2 { get => street2; set => street2 = value; }
        public String City { get => city; set => city = value; }
        public String State { get => state; set => state = value; }
        public String ZipCode { get => zipCode; set => zipCode = value; }
        public String Phone { get => phone; set => phone = value; }
        internal MyConsultant ThisConsultant { get => thisConsultant; set => thisConsultant = value; }
        public bool IsReady { get => isReady; set => isReady = value; }


        // TODO: create getters and setters (encapsulate, use field?)

        public MyEmployer()
        {
            // TODO: create Employer public constructor	
        }


        // Validators
        public bool CheckAddress(String street1, String street2)
        {
            // TODO validating CheckAddress() characters

            // Default state is true, updated if either address 1 or 2 fails validation
            bool isReady = true;
            int index = 0;

            foreach (char a in Street1.ToCharArray())
            {
                if (!VALID_CHARACTERS.Contains(a.ToString()))
                {
                    Console.WriteLine("Street 1: replaced character " + a.ToString() + " at index " + index + ".");
                    Street1.Replace(a, ' ');
                }
                index++;
            }

            Console.WriteLine("Fail on Employer City validation.");
            isReady = false;

            return isReady;
        }

        // Will substitute default phone number is given phone is invalid
        public void CheckPhone(String phone)
        {
            // If phone is not present or invalid (less than 10 chars), substitute consultant phone number 
            if (this.Phone == null || this.Phone.Length < 10)
            {
                // Auto populate default phone num for NTC, EF
                if (ThisConsultant.Name == "NTC")
                {
                    this.Phone = ThisConsultant.NTC_PHONE;
                }
                else
                {
                    this.Phone = ThisConsultant.EF_PHONE;
                }
            }
        }

        public void ValidateEmployer(this MyEmployer employer)
        {
            // TODO implement validation of all employer fields
        }
    }
}
