﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Application;
using Consultant;
using Employee;
using Employer;
using MyString;


namespace Batch_Fix_and_Conversion
{
    class Batch
    {
        string stateAbbr = null;
        MyConsultant thisConsultant;

        List<MyApplication> applicationList;
    }
}
