﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Batch_Fix_and_Conversion
{
    public static class MyError
    {
        // TODO Create standard error messages as constants
        // TODO Create error for each type (employee, application, employer, etc.)
        public static void WriteError(string message)
        {
            Console.WriteLine(message);
        }

        public static void MyException(this Exception e, string message)
        {
            throw e;
        }
    }
}
