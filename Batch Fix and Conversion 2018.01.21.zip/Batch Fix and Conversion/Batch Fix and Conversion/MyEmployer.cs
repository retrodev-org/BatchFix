﻿using System;

namespace Batch_Fix_and_Conversion
{
    /// <summary>
	/// Class:	MyEmployer
	/// Use:	Read and store employer information. (EIN, Address, Phone, etc.)
	/// </summary>
	public class MyEmployer
    {
        // Variables
        private String fein;
        private String name;
        private String street1;
        private String street2;
        private String city;
        private String state;
        private String zipCode;
        private String phone;
        private MyConsultant thisConsultant;

        private bool isReady;

        public String Fein { get => fein; set => fein = value; }
        public String Name { get => name; set => name = value; }
        public String Street1 { get => street1; set => street1 = value; }
        public String Street2 { get => street2; set => street2 = value; }
        public String City { get => city; set => city = value; }
        public String State { get => state; set => state = value; }
        public String ZipCode { get => zipCode; set => zipCode = value; }
        public String Phone { get => phone; set => phone = value; }
        internal MyConsultant ThisConsultant { get => thisConsultant; set => thisConsultant = value; }
        public bool IsReady { get => isReady; set => isReady = value; }


        // TODO: create getters and setters (encapsulate, use field?)

        public MyEmployer()
        {
            // TODO: create Employer public constructor	
        }
    }
}
