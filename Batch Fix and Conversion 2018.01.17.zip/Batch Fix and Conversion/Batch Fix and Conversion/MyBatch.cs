﻿using System;
using System.Collections.Generic;


namespace Batch_Fix_and_Conversion
{
    public class MyBatchFile
    {
        private MyState state;
        private string errorConfirmationMessage;
        private string logMessage;
        private MyConsultant thisConsultant;
        private List<MyApp> applicationList;
        private bool isReady = true;

        /* Interpret state abbreviation string into constant state values, 
         * then initialize the state with delimiter, minimum wage, true/false values
         */
        public MyBatchFile(string stateAbbreviation)
        {
            // Set up list of applications
            ApplicationList = new List<MyApp>();

            /* Interpret state abbreviation string into constant state values, 
             * then initialize the state with delimiter, minimum wage, true/false values
             */
            if (stateAbbreviation == "AK")
                State = new MyState(MyConst.STATE_AK);
            if (stateAbbreviation == "AL")
                State = new MyState(MyConst.STATE_AL);
            if (stateAbbreviation == "AR")
                State = new MyState(MyConst.STATE_AR);
            if (stateAbbreviation == "AZ")
                State = new MyState(MyConst.STATE_AZ);
            if (stateAbbreviation == "CA")
                State = new MyState(MyConst.STATE_CA);
            if (stateAbbreviation == "CO")
                State = new MyState(MyConst.STATE_CO);
            if (stateAbbreviation == "CT")
                State = new MyState(MyConst.STATE_CT);
            if (stateAbbreviation == "DC")
                State = new MyState(MyConst.STATE_DC);
            if (stateAbbreviation == "DE")
                State = new MyState(MyConst.STATE_DE);
            if (stateAbbreviation == "FL")
                State = new MyState(MyConst.STATE_FL);
            if (stateAbbreviation == "GA")
                State = new MyState(MyConst.STATE_GA);
            if (stateAbbreviation == "GU")
                State = new MyState(MyConst.STATE_GU);
            if (stateAbbreviation == "HI")
                State = new MyState(MyConst.STATE_HI);
            if (stateAbbreviation == "IA")
                State = new MyState(MyConst.STATE_IA);
            if (stateAbbreviation == "ID")
                State = new MyState(MyConst.STATE_ID);
            if (stateAbbreviation == "IL")
                State = new MyState(MyConst.STATE_IL);
            if (stateAbbreviation == "IN")
                State = new MyState(MyConst.STATE_IN);
            if (stateAbbreviation == "KS")
                State = new MyState(MyConst.STATE_KS);
            if (stateAbbreviation == "KY")
                State = new MyState(MyConst.STATE_KY);
            if (stateAbbreviation == "LA")
                State = new MyState(MyConst.STATE_LA);
            if (stateAbbreviation == "MA")
                State = new MyState(MyConst.STATE_MA);
            if (stateAbbreviation == "MD")
                State = new MyState(MyConst.STATE_MD);
            if (stateAbbreviation == "ME")
                State = new MyState(MyConst.STATE_ME);
            if (stateAbbreviation == "MI")
                State = new MyState(MyConst.STATE_MI);
            if (stateAbbreviation == "MN")
                State = new MyState(MyConst.STATE_MN);
            if (stateAbbreviation == "MO")
                State = new MyState(MyConst.STATE_MO);
            if (stateAbbreviation == "MS")
                State = new MyState(MyConst.STATE_MS);
            if (stateAbbreviation == "MT")
                State = new MyState(MyConst.STATE_MT);
            if (stateAbbreviation == "NC")
                State = new MyState(MyConst.STATE_NC);
            if (stateAbbreviation == "ND")
                State = new MyState(MyConst.STATE_ND);
            if (stateAbbreviation == "NE")
                State = new MyState(MyConst.STATE_NE);
            if (stateAbbreviation == "NH")
                State = new MyState(MyConst.STATE_NH);
            if (stateAbbreviation == "NJ")
                State = new MyState(MyConst.STATE_NJ);
            if (stateAbbreviation == "NM")
                State = new MyState(MyConst.STATE_NM);
            if (stateAbbreviation == "NV")
                State = new MyState(MyConst.STATE_NV);
            if (stateAbbreviation == "NY")
                State = new MyState(MyConst.STATE_NY);
            if (stateAbbreviation == "OH")
                State = new MyState(MyConst.STATE_OH);
            if (stateAbbreviation == "OK")
                State = new MyState(MyConst.STATE_OK);
            if (stateAbbreviation == "OR")
                State = new MyState(MyConst.STATE_OR);
            if (stateAbbreviation == "PA")
                State = new MyState(MyConst.STATE_PA);
            if (stateAbbreviation == "PR")
                State = new MyState(MyConst.STATE_PR);
            if (stateAbbreviation == "RI")
                State = new MyState(MyConst.STATE_RI);
            if (stateAbbreviation == "SC")
                State = new MyState(MyConst.STATE_SC);
            if (stateAbbreviation == "SD")
                State = new MyState(MyConst.STATE_SD);
            if (stateAbbreviation == "TN")
                State = new MyState(MyConst.STATE_TN);
            if (stateAbbreviation == "TX")
                State = new MyState(MyConst.STATE_TX);
            if (stateAbbreviation == "UT")
                State = new MyState(MyConst.STATE_UT);
            if (stateAbbreviation == "VA")
                State = new MyState(MyConst.STATE_VA);
            if (stateAbbreviation == "VT")
                State = new MyState(MyConst.STATE_VT);
            if (stateAbbreviation == "WA")
                State = new MyState(MyConst.STATE_WA);
            if (stateAbbreviation == "WI")
                State = new MyState(MyConst.STATE_WI);
            if (stateAbbreviation == "WV")
                State = new MyState(MyConst.STATE_WV);
            if (stateAbbreviation == "WY")
                State = new MyState(MyConst.STATE_WY);

            // Validate application, all fields
            foreach (MyApp app in applicationList)
            {
                // Substitute default phone number if employer phone is invalid
                CheckEmployerPhone(app);
            }
        }

        // Will substitute default phone number is given phone is invalid
        private void CheckEmployerPhone(MyApp app)
        {
            // If phone is not present or invalid (less than 10 chars), substitute consultant phone number 
            if (app.Employer.Phone == null || app.Employer.Phone.Length < 10)
            {
                // Auto populate default phone num for NTC, EF
                if (this.ThisConsultant.Name == "NTC")
                {
                    app.Employer.Phone = ThisConsultant.NTC_PHONE;
                }
                else
                {
                    app.Employer.Phone = ThisConsultant.EF_PHONE;
                }
            }
        }

        private bool ValidateApplication(MyApp app, int submissionState)
        {
            IsReady = ValidateEmployee();

            if (IsReady == true)
                IsReady = app.Employer.IsReady;
            else
                MyString.MyString.WriteError("Fail on Employee validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateState();
            else
                MyString.MyString.WriteError("Fail on State validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateDates();
            else
                MyString.MyString.WriteError("Fail on Dates validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateRehire();
            else
                MyString.MyString.WriteError("Fail on Rehire validation for request ID " + app.RequestID);

            if (IsReady == true)
                IsReady = ValidateTargetGroups(app);
            else
                MyString.MyString.WriteError("Fail on Target Group validation for request ID " + app.RequestID);

            return IsReady;
        }

        private bool ValidateEmployee()
        {
            throw new NotImplementedException();
        }

        // Validators
        private bool CheckAddress(Employer.MyEmployer employer)
        {
            // TODO validating CheckAddress() characters

            // Default state is true, updated if either address 1 or 2 fails validation
            bool isReady = true;
            int index = 0;

            foreach (char a in employer.Street1.ToCharArray())
            {
                if (!MyConst.VALID_CHARACTERS.Contains(a.ToString()))
                {
                    Console.WriteLine("Street 1: replaced character " + a.ToString() + " in space " + index + ".");
                    employer.Street1.Replace(a, ' ');
                }
                index++;
            }

            Console.WriteLine("Fail on Employer City validation.");
            isReady = false;

            return isReady;
        }

        private bool ValidateTargetGroups(MyApp app)
        {
            // TODO check for all N, lacking target group. If is ready, return true.
            return true;
        }

        private bool ValidateRehire()
        {
            throw new NotImplementedException();
        }

        private bool ValidateDates()
        {
            throw new NotImplementedException();
        }

        private bool ValidateState()
        {
            throw new NotImplementedException();
        }

        private bool ValidateConsultant()
        {
            throw new NotImplementedException();
        }

        public string ErrorConfirmationMessage { get => errorConfirmationMessage; set => errorConfirmationMessage = value; }
        public string LogMessage { get => logMessage; set => logMessage = value; }
        internal MyState State { get => state; set => state = value; }
        internal MyConsultant ThisConsultant { get => thisConsultant; set => thisConsultant = value; }
        internal List<MyApp> ApplicationList { get => applicationList; set => applicationList = value; }
        public bool IsReady { get => isReady; set => isReady = value; }
    }
}
