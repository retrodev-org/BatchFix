﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch_Fix_and_Conversion
{
    public partial class BatchFixForm : Form
    {
        // String to receive data from the batch input file
        private static String inputData;

        public BatchFixForm()
        {
            InitializeComponent();
        }

        private void StartBatch(string stateAbbreviation)
        {
            MyBatchFile thisBatch = new MyBatchFile(stateAbbreviation);
        }

        private void btnFileBrowse_Click(object sender, EventArgs e)
        {
            // Displays an OpenFileDialog so the user can select a file.  
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Select a State Batch File";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                System.IO.StreamReader sr = new
                   System.IO.StreamReader(openFileDialog1.FileName);
                MessageBox.Show(sr.ReadToEnd());
                sr.Close();

                inputData = sr.ToString();
            }
        }
    }
}
