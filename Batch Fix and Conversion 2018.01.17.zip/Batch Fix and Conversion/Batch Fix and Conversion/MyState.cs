﻿using System;
using System.Collections.Generic;

namespace Batch_Fix_and_Conversion
{
    class MyState
    {
        // TODO Continue adding variables that exist in other states, then continue AL configuration


        // Basic Values
        int state;
        string delimiter;
        string trueAnswer;
        string falseAnswer;
        double minimumWage;
        List<string> validCities;
        List<string> varList;
        List<int> varLength;

        // Variables
        private int recordFormat;
        private int submissionState;
        private MyDate convictionDate;
        private MyDate dateOfBirth;
        private MyDate employeeSignDate8850;
        private MyDate employeeSignDate9061;
        private MyDate employerSignDate9061;
        private MyDate felConvictionDate;
        private MyDate felReleaseDate;
        private MyDate hireDate;
        private MyDate infoDate;
        private MyDate offerDate;
        private MyDate postmarkDate;
        private MyDate rehireDate;
        private MyDate releaseDate;
        private MyDate startDate;
        private MyDate unemploymentDeclarationDate;
        private MyDate unemploymentEndDate;
        private MyDate unemploymentStartDate;
        private string ageEligible;
        private string arraVetCategory;
        private string arraYouthCategory;
        private string consultantAddress;
        private string consultantCity;
        private string consultantEmail;
        private string consultantFax;
        private string consultantFEIN;
        private string consultantID;
        private string consultantName;
        private string consultantPhone;
        private string consultantSignerName;
        private string consultantSignerTitle;
        private string consultantState;
        private string consultantZipCode;
        private string employeeCity;
        private string employeeCounty;
        private string employeeEmail;
        private string employeeFirstName;
        private string employeeLastName;
        private string employeeMiddleName;
        private string employeePhone;
        private string employeeSignatureOnFile;
        private string employeeSocial;
        private string employeeState;
        private string employeeStreet;
        private string employeeStreet2;
        private string employeeZip;
        private string employerCity;
        private string employerCounty;
        private string employerEmail;
        private string employerFax;
        private string employerFEIN;
        private string employerName;
        private string employerPhone;
        private string employerPhoneDash;
        private string employerPhoneExtension;
        private string employerState;
        private string employerStreet;
        private string employerStreet2;
        private string employerZip;
        private string empowermentZone;
        private string empowermentZoneSummerJob;
        private string felonFederalStatus;
        private string felonStateName;
        private string felonStateStatus;
        private string felonStatus;
        private string form9062;
        private string formCompletedBy;
        private string katrinaEmployee;
        private string katrinaEmployeeCity;
        private string katrinaEmployeeCounty;
        private string katrinaEmployeeState;
        private string katrinaEmployeeStreet;
        private string katrinaEmployeeZip;
        private string katrinaJobCounty;
        private string katrinaJobState;
        private string katrinaNewEmployee;
        private string occupationCodeONET;
        private string outOfStateBenCity;
        private string outOfStateBenRecipient;
        private string outOfStateBenState;
        private string pin8850;
        private string position;
        private string positionTitle;
        private string q1_8850;
        private string q2_8850;
        private string q3_8850;
        private string q4_8850;
        private string q5_8850;
        private string q6_8850;
        private string q7_8850;
        private string rehire;
        private string representativeName;
        private string requestID;
        private string ruralRenewalCountyName;
        private string ruralRenewalCountyStatus;
        private string signatureOnFileForm9175;
        private string snap01;
        private string snap02;
        private string snapRecipient;
        private string snapState;
        private string sourceDocuments01;
        private string sourceDocuments02;
        private string sourceDocuments03;
        private string sourceDocuments04;
        private string supplementalSecurity;
        private string tanf01;
        private string tanf02;
        private string tanf03;
        private string tanf04;
        private string tanfRecipient;
        private string tanfState;
        private string targetGroup;
        private string unemploymentFederal_YN;
        private string unemploymentFedState_FS;
        private string unemploymentState_YN;
        private string unemploymentStateName;
        private string unemploymentStatus;
        private string version8850;
        private string version9061;
        private string veteran1Year;
        private string veteran4Weeks;
        private string veteran6Months;
        private string veteranDisabled;
        private string veteranSnapRecipient;
        private string veteranSnapState;
        private string veteranStatus;
        private string vetSNAP;
        private string vocRehabAgency;
        private string vocRehabTicketToWork;
        private string vocRehabVeteranAffairs;
        private string vowToHireHeroes;
        private string wage = MyConst.WAGE_DEFAULT.ToString();
        private string wageCentsOnly;
        private string wageDollarsOnly;


        public MyState()
        {
            // TODO MyState constructor
        }

        public MyState(int stateSelector)
        {
            // For each state, initialize with the following:
            // Delimiter = MyConst.DELMT_SPACE;
            // TrueAnswer = MyConst.TRUE_Y;
            // FalseAnswer = MyConst.FALSE_N;
            // MinimumWage = MyConst.WAGE_DEFAULT;
            // ValidCities = list of cities, if necessary (see IN)

            VarList = new List<string>();
            VarLength = new List<int>();

            // Initialize the state with delimiter, minimum wage, true/false values
            switch (stateSelector)
            {
                case MyConst.STATE_AK:
                    // TODO Configure State
                    break;

                case MyConst.STATE_AL:
                    // Basic values
                    Delimiter = MyConst.DELMT_SPACE;
                    TrueAnswer = MyConst.TRUE_Y;
                    FalseAnswer = MyConst.FALSE_N;
                    MinimumWage = 0.00;

                    // Variables
                    varList.Add(consultantID);
                    varLength.Add(12);
                    VarList.Add(employerFEIN);
                    VarLength.Add(9);

                    break;

                case MyConst.STATE_AR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_AZ:
                    // TODO Configure State
                    break;

                case MyConst.STATE_CA:
                    // TODO Configure state
                    break;

                case MyConst.STATE_CO:
                    // TODO Configure State
                    break;

                case MyConst.STATE_CT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_DC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_DE:
                    // TODO Configure State
                    break;

                case MyConst.STATE_FL:
                    // TODO Configure State
                    break;

                case MyConst.STATE_GA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_GU:
                    // TODO Configure State
                    break;

                case MyConst.STATE_HI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ID:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IL:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_KS:
                    // TODO Configure State
                    break;

                case MyConst.STATE_KY:
                    // TODO Configure State
                    break;

                case MyConst.STATE_LA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MD:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ME:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MO:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MS:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ND:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NE:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NH:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NJ:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NM:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NV:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NY:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OH:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OK:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_PA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_PR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_RI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_SC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_SD:
                    // TODO Configure State
                    break;

                case MyConst.STATE_TN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_TX:
                    // TODO Configure State
                    break;

                case MyConst.STATE_UT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_VA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_VT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WV:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WY:
                    // TODO Configure State
                    break;
            } // end switch (stateSelector)
        } // end constructor MyState(int stateSelector)

        // Getters and Setters
        public int State { get => state; set => state = value; }
        public string Delimiter { get => delimiter; set => delimiter = value; }
        public string TrueAnswer { get => trueAnswer; set => trueAnswer = value; }
        public string FalseAnswer { get => falseAnswer; set => falseAnswer = value; }
        public double MinimumWage { get => minimumWage; set => minimumWage = value; }
        public List<string> ValidCities { get => validCities; set => validCities = value; }
        public List<string> VarList { get => varList; set => varList = value; }
        public List<int> VarLength { get => varLength; set => varLength = value; }
    }
}
