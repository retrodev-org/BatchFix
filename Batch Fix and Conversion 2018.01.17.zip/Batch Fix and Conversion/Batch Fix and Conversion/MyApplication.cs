﻿using System;

namespace Batch_Fix_and_Conversion
{
    class MyApp
    {
        private int recordFormat;
        private int submissionState;
        private MyConsultant thisConsultant;
        private MyDate employeeSignDate;
        private MyDate employerSignDate;
        private MyDate felConvictionDate;
        private MyDate felReleaseDate;
        private MyDate hireDate;
        private MyDate infoDate;
        private MyDate offerDate;
        private MyDate rehireDate;
        private MyDate startDate;
        private MyEmployee employee;
        private MyEmployer employer;
        private string ageEligible;
        private string benefitsRecipientSNAP;
        private string benefitsRecipientTANF;
        private string benefitsRecipientVetSNAP;
        private string benefitsStateSNAP;
        private string benefitsStateTANF;
        private string benefitsStateVetSNAP;
        private string empowermentZone;
        private string empowermentZoneSummerJob;
        private string felFederal;
        private string felon;
        private string felState;
        private string occupationCodeONET;
        private string positionTitle;
        private string rehire;
        private string requestID;
        private string ruralRenewalCounty;
        private string supplementalSecurity;
        private string unemploymentState;
        private string unemploymentStatus;
        private string vet1Year;
        private string vet4Weeks;
        private string vet6Months;
        private string vetDisabled;
        private string vetStatus;
        private string vocRehabAgency;
        private string vocRehabTTW;
        private string vocRehabVA;
        private string wage = MyConst.WAGE_DEFAULT.ToString();

        private bool prescreenQ1; // Form 8850 conditional certification from state workforce agency (SWA)
        private bool prescreenQ2; // SNAP, TANF, Vet SNAP, Ex-Felon, RRC, SSI, Vet 4wks-6mo
        private bool prescreenQ3; // Veteran unemployed 6+ months
        private bool prescreenQ4; // Veteran with service-connected disability, discharge w/in past year
        private bool prescreenQ5; // Veteran with service-connected disability, unemployed 6+ months
        private bool prescreenQ6; // TANF
        private bool prescreenQ7; // Long term unemployment
        private bool isReady = false;
        private bool rehiredEmployee;

        // Getters and setters
        public string RequestID { get => requestID; set => requestID = value; }
        public string Wage { get => wage; set => wage = value; }
        public string Position { get => positionTitle; set => positionTitle = value; }
        public string OccupationCode { get => occupationCodeONET; set => occupationCodeONET = value; }
        public string BenefitsRecipientSNAP { get => benefitsRecipientSNAP; set => benefitsRecipientSNAP = value; }
        public string BenefitsStateSNAP { get => benefitsStateSNAP; set => benefitsStateSNAP = value; }
        public string BenefitsRecipientTANF { get => benefitsRecipientTANF; set => benefitsRecipientTANF = value; }
        public string BenefitsStateTANF { get => benefitsStateTANF; set => benefitsStateTANF = value; }
        public string BenefitsRecipientVetSNAP { get => benefitsRecipientVetSNAP; set => benefitsRecipientVetSNAP = value; }
        public string BenefitsStateVetSNAP { get => benefitsStateVetSNAP; set => benefitsStateVetSNAP = value; }
        public string UnemploymentState { get => unemploymentState; set => unemploymentState = value; }
        public bool PrescreenQ1 { get => prescreenQ1; set => prescreenQ1 = value; }
        public bool PrescreenQ2 { get => prescreenQ2; set => prescreenQ2 = value; }
        public bool PrescreenQ3 { get => prescreenQ3; set => prescreenQ3 = value; }
        public bool PrescreenQ4 { get => prescreenQ4; set => prescreenQ4 = value; }
        public bool PrescreenQ5 { get => prescreenQ5; set => prescreenQ5 = value; }
        public bool PrescreenQ6 { get => prescreenQ6; set => prescreenQ6 = value; }
        public bool PrescreenQ7 { get => prescreenQ7; set => prescreenQ7 = value; }
        public bool IsReady { get => isReady; set => isReady = value; }
        public bool Rehire { get => rehiredEmployee; set => rehiredEmployee = value; }
        internal MyEmployee Employee { get => employee; set => employee = value; }
        internal MyEmployer Employer { get => employer; set => employer = value; }
        internal MyConsultant ThisConsultant { get => thisConsultant; set => thisConsultant = value; }
        internal MyDate StartDate { get => startDate; set => startDate = value; }
        internal MyDate HireDate { get => hireDate; set => hireDate = value; }
        internal MyDate InfoDate { get => infoDate; set => infoDate = value; }
        internal MyDate OfferDate { get => offerDate; set => offerDate = value; }
        internal MyDate EmployeeSignDate { get => employeeSignDate; set => employeeSignDate = value; }
        internal MyDate EmployerSignDate { get => employerSignDate; set => employerSignDate = value; }
        internal MyDate RehireWorkDate { get => rehireDate; set => rehireDate = value; }
        internal MyDate ConvictionDate { get => felConvictionDate; set => felConvictionDate = value; }
        internal MyDate ReleaseDate { get => felReleaseDate; set => felReleaseDate = value; }
        public int SubmissionState { get => submissionState; set => submissionState = value; }
        public int RecordFormat { get => recordFormat; set => recordFormat = value; }
        public string AgeEligible { get => ageEligible; set => ageEligible = value; }
        public string VetStatus { get => vetStatus; set => vetStatus = value; }
        public string VetDisabled { get => vetDisabled; set => vetDisabled = value; }
        public string Vet1Year { get => vet1Year; set => vet1Year = value; }
        public string Vet6Months { get => vet6Months; set => vet6Months = value; }
        public string Vet4Weeks { get => vet4Weeks; set => vet4Weeks = value; }
        public string VocRehabAgency { get => vocRehabAgency; set => vocRehabAgency = value; }
        public string VocRehabTTW { get => vocRehabTTW; set => vocRehabTTW = value; }
        public string VocRehabVA { get => vocRehabVA; set => vocRehabVA = value; }
        public string Felon { get => felon; set => felon = value; }
        public string FelFederal { get => felFederal; set => felFederal = value; }
        public string FelState { get => felState; set => felState = value; }
        public string RuralRenewalCounty { get => ruralRenewalCounty; set => ruralRenewalCounty = value; }
        public string EmpowermentZone { get => empowermentZone; set => empowermentZone = value; }
        public string EmpowermentZoneSummerJob { get => empowermentZoneSummerJob; set => empowermentZoneSummerJob = value; }
        public string SupplementalSecurity { get => supplementalSecurity; set => supplementalSecurity = value; }
        public string UnemploymentStatus { get => unemploymentStatus; set => unemploymentStatus = value; }
        public string Rehire1 { get => rehire; set => rehire = value; }

        public MyApp(int submissionState)
        {
            SubmissionState = submissionState;
        }
        

        

        public bool ValidateEmployee(MyEmployee employee)
        {

            employee.Social = AddTrailingSpaces(employee.Social,9);
            return true;

        }

        public void ValidateEmployer(MyEmployer employer)
        {
            // TODO implement validation of all employer fields
        }

        public string AddTrailingSpaces(string input, int length)
        {
            while (input.Length < length)
                input = input + " ";

            return input;
        }

        public string AddLeadingZeros(string input, int length)
        {
            while (input.Length < length)
                input = "0" + input;

            return input;
        }
    }
}
