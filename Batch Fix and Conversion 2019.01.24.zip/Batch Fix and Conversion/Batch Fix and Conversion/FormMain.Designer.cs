﻿namespace Batch_Fix_and_Conversion
{
    partial class FormMain
    {
        /// <summary>
        /// Designer variable used to keep track of non-visual components.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TableLayoutPanel tblLayoutPanelStates;
        private System.Windows.Forms.Button btnAK;
        private System.Windows.Forms.Button btnAL;
        private System.Windows.Forms.Button btnAR;
        private System.Windows.Forms.Button btnAZ;
        private System.Windows.Forms.Button btnCA;
        private System.Windows.Forms.Button btnCO;
        private System.Windows.Forms.Button btnCT;
        private System.Windows.Forms.Button btnDC;
        private System.Windows.Forms.Button btnDE;
        private System.Windows.Forms.Button btnFL;
        private System.Windows.Forms.Button btnGA;
        private System.Windows.Forms.Button btnHI;
        private System.Windows.Forms.Button btnIA;
        private System.Windows.Forms.Button btnID;
        private System.Windows.Forms.Button btnIL;
        private System.Windows.Forms.Button btnIN;
        private System.Windows.Forms.Button btnKS;
        private System.Windows.Forms.Button btnKY;
        private System.Windows.Forms.Button btnLA;
        private System.Windows.Forms.Button btnMA;
        private System.Windows.Forms.Button btnMD;
        private System.Windows.Forms.Button btnME;
        private System.Windows.Forms.Button btnMI;
        private System.Windows.Forms.Button btnMN;
        private System.Windows.Forms.Button btnMO;
        private System.Windows.Forms.Button btnMS;
        private System.Windows.Forms.Button btnMT;
        private System.Windows.Forms.Button btnNC;
        private System.Windows.Forms.Button btnND;
        private System.Windows.Forms.Button btnNE;
        private System.Windows.Forms.Button btnNH;
        private System.Windows.Forms.Button btnNJ;
        private System.Windows.Forms.Button btnNM;
        private System.Windows.Forms.Button btnNV;
        private System.Windows.Forms.Button btnNY;
        private System.Windows.Forms.Button btnOH;
        private System.Windows.Forms.Button btnOK;
        private System.Windows.Forms.Button btnOR;
        private System.Windows.Forms.Button btnPA;
        private System.Windows.Forms.Button btnRI;
        private System.Windows.Forms.Button btnSC;
        private System.Windows.Forms.Button btnSD;
        private System.Windows.Forms.Button btnTN;
        private System.Windows.Forms.Button btnTX;
        private System.Windows.Forms.Button btnUT;
        private System.Windows.Forms.Button btnVA;
        private System.Windows.Forms.Button btnVT;
        private System.Windows.Forms.Button btnWA;
        private System.Windows.Forms.Button btnWI;
        private System.Windows.Forms.Button btnWV;
        private System.Windows.Forms.Button btnWY;
        private System.Windows.Forms.Button btnPR;
        private System.Windows.Forms.Button btnGuam;
        private System.Windows.Forms.Label lblStateButtons;
        private System.Windows.Forms.Button btnFileBrowse;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Label lblInstruct1;
        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Label lblConfirmation;
        private System.Windows.Forms.RichTextBox txtSuccessFailMessage;
        private System.Windows.Forms.Button btnFileClear;
        private System.Windows.Forms.Label lblFixed;
        private System.Windows.Forms.RichTextBox txtChangeLog;

        /// <summary>
        /// Disposes resources used by the form.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        /// <summary>
        /// This method is required for Windows Forms designer support.
        /// Do not change the method contents inside the source code editor. The Forms designer might
        /// not be able to load this method if it was changed manually.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblLayoutPanelStates = new System.Windows.Forms.TableLayoutPanel();
            this.btnAK = new System.Windows.Forms.Button();
            this.btnAL = new System.Windows.Forms.Button();
            this.btnAR = new System.Windows.Forms.Button();
            this.btnAZ = new System.Windows.Forms.Button();
            this.btnCA = new System.Windows.Forms.Button();
            this.btnCO = new System.Windows.Forms.Button();
            this.btnCT = new System.Windows.Forms.Button();
            this.btnDC = new System.Windows.Forms.Button();
            this.btnDE = new System.Windows.Forms.Button();
            this.btnFL = new System.Windows.Forms.Button();
            this.btnGA = new System.Windows.Forms.Button();
            this.btnHI = new System.Windows.Forms.Button();
            this.btnIA = new System.Windows.Forms.Button();
            this.btnID = new System.Windows.Forms.Button();
            this.btnIL = new System.Windows.Forms.Button();
            this.btnIN = new System.Windows.Forms.Button();
            this.btnKS = new System.Windows.Forms.Button();
            this.btnKY = new System.Windows.Forms.Button();
            this.btnLA = new System.Windows.Forms.Button();
            this.btnMA = new System.Windows.Forms.Button();
            this.btnMD = new System.Windows.Forms.Button();
            this.btnME = new System.Windows.Forms.Button();
            this.btnMI = new System.Windows.Forms.Button();
            this.btnMN = new System.Windows.Forms.Button();
            this.btnMO = new System.Windows.Forms.Button();
            this.btnMS = new System.Windows.Forms.Button();
            this.btnMT = new System.Windows.Forms.Button();
            this.btnNC = new System.Windows.Forms.Button();
            this.btnND = new System.Windows.Forms.Button();
            this.btnNE = new System.Windows.Forms.Button();
            this.btnNH = new System.Windows.Forms.Button();
            this.btnNJ = new System.Windows.Forms.Button();
            this.btnNM = new System.Windows.Forms.Button();
            this.btnNV = new System.Windows.Forms.Button();
            this.btnNY = new System.Windows.Forms.Button();
            this.btnOH = new System.Windows.Forms.Button();
            this.btnOK = new System.Windows.Forms.Button();
            this.btnOR = new System.Windows.Forms.Button();
            this.btnPA = new System.Windows.Forms.Button();
            this.btnRI = new System.Windows.Forms.Button();
            this.btnSC = new System.Windows.Forms.Button();
            this.btnSD = new System.Windows.Forms.Button();
            this.btnTN = new System.Windows.Forms.Button();
            this.btnTX = new System.Windows.Forms.Button();
            this.btnUT = new System.Windows.Forms.Button();
            this.btnVA = new System.Windows.Forms.Button();
            this.btnVT = new System.Windows.Forms.Button();
            this.btnGuam = new System.Windows.Forms.Button();
            this.btnPR = new System.Windows.Forms.Button();
            this.btnWY = new System.Windows.Forms.Button();
            this.btnWV = new System.Windows.Forms.Button();
            this.btnWI = new System.Windows.Forms.Button();
            this.btnWA = new System.Windows.Forms.Button();
            this.lblStateButtons = new System.Windows.Forms.Label();
            this.btnFileBrowse = new System.Windows.Forms.Button();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.lblInstruct1 = new System.Windows.Forms.Label();
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblConfirmation = new System.Windows.Forms.Label();
            this.txtSuccessFailMessage = new System.Windows.Forms.RichTextBox();
            this.btnFileClear = new System.Windows.Forms.Button();
            this.lblFixed = new System.Windows.Forms.Label();
            this.txtChangeLog = new System.Windows.Forms.RichTextBox();
            this.btnSaveChangeLog = new System.Windows.Forms.Button();
            this.dialogSaveChangeLog = new System.Windows.Forms.SaveFileDialog();
            this.lblEmailForQuestions = new System.Windows.Forms.Label();
            this.btnVI = new System.Windows.Forms.Button();
            this.tblLayoutPanelStates.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblLayoutPanelStates
            // 
            this.tblLayoutPanelStates.BackColor = System.Drawing.SystemColors.ControlLight;
            this.tblLayoutPanelStates.ColumnCount = 3;
            this.tblLayoutPanelStates.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tblLayoutPanelStates.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblLayoutPanelStates.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tblLayoutPanelStates.Controls.Add(this.btnAK, 0, 0);
            this.tblLayoutPanelStates.Controls.Add(this.btnAL, 0, 1);
            this.tblLayoutPanelStates.Controls.Add(this.btnAR, 0, 2);
            this.tblLayoutPanelStates.Controls.Add(this.btnAZ, 0, 3);
            this.tblLayoutPanelStates.Controls.Add(this.btnCA, 0, 4);
            this.tblLayoutPanelStates.Controls.Add(this.btnCO, 0, 5);
            this.tblLayoutPanelStates.Controls.Add(this.btnCT, 0, 6);
            this.tblLayoutPanelStates.Controls.Add(this.btnDC, 0, 7);
            this.tblLayoutPanelStates.Controls.Add(this.btnDE, 0, 8);
            this.tblLayoutPanelStates.Controls.Add(this.btnFL, 0, 9);
            this.tblLayoutPanelStates.Controls.Add(this.btnGA, 0, 10);
            this.tblLayoutPanelStates.Controls.Add(this.btnHI, 0, 11);
            this.tblLayoutPanelStates.Controls.Add(this.btnIA, 0, 12);
            this.tblLayoutPanelStates.Controls.Add(this.btnID, 0, 13);
            this.tblLayoutPanelStates.Controls.Add(this.btnIL, 0, 14);
            this.tblLayoutPanelStates.Controls.Add(this.btnIN, 0, 15);
            this.tblLayoutPanelStates.Controls.Add(this.btnKS, 0, 16);
            this.tblLayoutPanelStates.Controls.Add(this.btnKY, 0, 17);
            this.tblLayoutPanelStates.Controls.Add(this.btnLA, 0, 18);
            this.tblLayoutPanelStates.Controls.Add(this.btnMA, 0, 19);
            this.tblLayoutPanelStates.Controls.Add(this.btnMD, 1, 0);
            this.tblLayoutPanelStates.Controls.Add(this.btnME, 1, 1);
            this.tblLayoutPanelStates.Controls.Add(this.btnMI, 1, 2);
            this.tblLayoutPanelStates.Controls.Add(this.btnMN, 1, 3);
            this.tblLayoutPanelStates.Controls.Add(this.btnMO, 1, 4);
            this.tblLayoutPanelStates.Controls.Add(this.btnMS, 1, 5);
            this.tblLayoutPanelStates.Controls.Add(this.btnMT, 1, 6);
            this.tblLayoutPanelStates.Controls.Add(this.btnNC, 1, 7);
            this.tblLayoutPanelStates.Controls.Add(this.btnND, 1, 8);
            this.tblLayoutPanelStates.Controls.Add(this.btnNE, 1, 9);
            this.tblLayoutPanelStates.Controls.Add(this.btnNH, 1, 10);
            this.tblLayoutPanelStates.Controls.Add(this.btnNJ, 1, 11);
            this.tblLayoutPanelStates.Controls.Add(this.btnNM, 1, 12);
            this.tblLayoutPanelStates.Controls.Add(this.btnNV, 1, 13);
            this.tblLayoutPanelStates.Controls.Add(this.btnNY, 1, 14);
            this.tblLayoutPanelStates.Controls.Add(this.btnOH, 1, 15);
            this.tblLayoutPanelStates.Controls.Add(this.btnOK, 1, 16);
            this.tblLayoutPanelStates.Controls.Add(this.btnOR, 1, 17);
            this.tblLayoutPanelStates.Controls.Add(this.btnPA, 1, 18);
            this.tblLayoutPanelStates.Controls.Add(this.btnRI, 1, 19);
            this.tblLayoutPanelStates.Controls.Add(this.btnSC, 2, 0);
            this.tblLayoutPanelStates.Controls.Add(this.btnSD, 2, 1);
            this.tblLayoutPanelStates.Controls.Add(this.btnTN, 2, 2);
            this.tblLayoutPanelStates.Controls.Add(this.btnTX, 2, 3);
            this.tblLayoutPanelStates.Controls.Add(this.btnUT, 2, 4);
            this.tblLayoutPanelStates.Controls.Add(this.btnVA, 2, 5);
            this.tblLayoutPanelStates.Controls.Add(this.btnVT, 2, 6);
            this.tblLayoutPanelStates.Controls.Add(this.btnWA, 2, 7);
            this.tblLayoutPanelStates.Controls.Add(this.btnWI, 2, 8);
            this.tblLayoutPanelStates.Controls.Add(this.btnWV, 2, 9);
            this.tblLayoutPanelStates.Controls.Add(this.btnWY, 2, 10);
            this.tblLayoutPanelStates.Controls.Add(this.btnPR, 2, 12);
            this.tblLayoutPanelStates.Controls.Add(this.btnGuam, 2, 11);
            this.tblLayoutPanelStates.Controls.Add(this.btnVI, 2, 13);
            this.tblLayoutPanelStates.Location = new System.Drawing.Point(19, 40);
            this.tblLayoutPanelStates.Margin = new System.Windows.Forms.Padding(0);
            this.tblLayoutPanelStates.Name = "tblLayoutPanelStates";
            this.tblLayoutPanelStates.RowCount = 20;
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
            this.tblLayoutPanelStates.Size = new System.Drawing.Size(180, 600);
            this.tblLayoutPanelStates.TabIndex = 0;
            // 
            // btnAK
            // 
            this.btnAK.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAK.BackColor = System.Drawing.Color.LightGray;
            this.btnAK.Enabled = false;
            this.btnAK.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnAK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAK.Location = new System.Drawing.Point(1, 1);
            this.btnAK.Margin = new System.Windows.Forms.Padding(1);
            this.btnAK.Name = "btnAK";
            this.btnAK.Size = new System.Drawing.Size(57, 28);
            this.btnAK.TabIndex = 10;
            this.btnAK.Text = "AK";
            this.btnAK.UseVisualStyleBackColor = false;
            // 
            // btnAL
            // 
            this.btnAL.Location = new System.Drawing.Point(1, 31);
            this.btnAL.Margin = new System.Windows.Forms.Padding(1);
            this.btnAL.Name = "btnAL";
            this.btnAL.Size = new System.Drawing.Size(57, 28);
            this.btnAL.TabIndex = 20;
            this.btnAL.Text = "AL";
            this.btnAL.UseVisualStyleBackColor = true;
            this.btnAL.Click += new System.EventHandler(this.BtnAL_Click);
            // 
            // btnAR
            // 
            this.btnAR.Location = new System.Drawing.Point(1, 61);
            this.btnAR.Margin = new System.Windows.Forms.Padding(1);
            this.btnAR.Name = "btnAR";
            this.btnAR.Size = new System.Drawing.Size(57, 28);
            this.btnAR.TabIndex = 30;
            this.btnAR.Text = "AR";
            this.btnAR.UseVisualStyleBackColor = true;
            // 
            // btnAZ
            // 
            this.btnAZ.Location = new System.Drawing.Point(1, 91);
            this.btnAZ.Margin = new System.Windows.Forms.Padding(1);
            this.btnAZ.Name = "btnAZ";
            this.btnAZ.Size = new System.Drawing.Size(57, 28);
            this.btnAZ.TabIndex = 40;
            this.btnAZ.Text = "AZ";
            this.btnAZ.UseVisualStyleBackColor = true;
            // 
            // btnCA
            // 
            this.btnCA.Location = new System.Drawing.Point(1, 121);
            this.btnCA.Margin = new System.Windows.Forms.Padding(1);
            this.btnCA.Name = "btnCA";
            this.btnCA.Size = new System.Drawing.Size(57, 28);
            this.btnCA.TabIndex = 50;
            this.btnCA.Text = "CA";
            this.btnCA.UseVisualStyleBackColor = true;
            // 
            // btnCO
            // 
            this.btnCO.Location = new System.Drawing.Point(1, 151);
            this.btnCO.Margin = new System.Windows.Forms.Padding(1);
            this.btnCO.Name = "btnCO";
            this.btnCO.Size = new System.Drawing.Size(57, 28);
            this.btnCO.TabIndex = 60;
            this.btnCO.Text = "CO";
            this.btnCO.UseVisualStyleBackColor = true;
            // 
            // btnCT
            // 
            this.btnCT.BackColor = System.Drawing.Color.LightGray;
            this.btnCT.Enabled = false;
            this.btnCT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnCT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCT.Location = new System.Drawing.Point(1, 181);
            this.btnCT.Margin = new System.Windows.Forms.Padding(1);
            this.btnCT.Name = "btnCT";
            this.btnCT.Size = new System.Drawing.Size(57, 28);
            this.btnCT.TabIndex = 0;
            this.btnCT.Text = "CT";
            this.btnCT.UseVisualStyleBackColor = false;
            // 
            // btnDC
            // 
            this.btnDC.Location = new System.Drawing.Point(1, 211);
            this.btnDC.Margin = new System.Windows.Forms.Padding(1);
            this.btnDC.Name = "btnDC";
            this.btnDC.Size = new System.Drawing.Size(57, 28);
            this.btnDC.TabIndex = 0;
            this.btnDC.Text = "DC";
            this.btnDC.UseVisualStyleBackColor = true;
            // 
            // btnDE
            // 
            this.btnDE.Location = new System.Drawing.Point(1, 241);
            this.btnDE.Margin = new System.Windows.Forms.Padding(1);
            this.btnDE.Name = "btnDE";
            this.btnDE.Size = new System.Drawing.Size(57, 28);
            this.btnDE.TabIndex = 0;
            this.btnDE.Text = "DE";
            this.btnDE.UseVisualStyleBackColor = true;
            // 
            // btnFL
            // 
            this.btnFL.Location = new System.Drawing.Point(1, 271);
            this.btnFL.Margin = new System.Windows.Forms.Padding(1);
            this.btnFL.Name = "btnFL";
            this.btnFL.Size = new System.Drawing.Size(57, 28);
            this.btnFL.TabIndex = 0;
            this.btnFL.Text = "FL";
            this.btnFL.UseVisualStyleBackColor = true;
            // 
            // btnGA
            // 
            this.btnGA.BackColor = System.Drawing.Color.LightGray;
            this.btnGA.Enabled = false;
            this.btnGA.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGA.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGA.Location = new System.Drawing.Point(1, 301);
            this.btnGA.Margin = new System.Windows.Forms.Padding(1);
            this.btnGA.Name = "btnGA";
            this.btnGA.Size = new System.Drawing.Size(57, 28);
            this.btnGA.TabIndex = 0;
            this.btnGA.Text = "GA";
            this.btnGA.UseVisualStyleBackColor = false;
            // 
            // btnHI
            // 
            this.btnHI.BackColor = System.Drawing.Color.LightGray;
            this.btnHI.Enabled = false;
            this.btnHI.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnHI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHI.Location = new System.Drawing.Point(1, 331);
            this.btnHI.Margin = new System.Windows.Forms.Padding(1);
            this.btnHI.Name = "btnHI";
            this.btnHI.Size = new System.Drawing.Size(57, 28);
            this.btnHI.TabIndex = 0;
            this.btnHI.Text = "HI";
            this.btnHI.UseVisualStyleBackColor = false;
            // 
            // btnIA
            // 
            this.btnIA.Location = new System.Drawing.Point(1, 361);
            this.btnIA.Margin = new System.Windows.Forms.Padding(1);
            this.btnIA.Name = "btnIA";
            this.btnIA.Size = new System.Drawing.Size(57, 28);
            this.btnIA.TabIndex = 0;
            this.btnIA.Text = "IA";
            this.btnIA.UseVisualStyleBackColor = true;
            // 
            // btnID
            // 
            this.btnID.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnID.BackColor = System.Drawing.Color.LightGray;
            this.btnID.Enabled = false;
            this.btnID.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnID.Location = new System.Drawing.Point(1, 391);
            this.btnID.Margin = new System.Windows.Forms.Padding(1);
            this.btnID.Name = "btnID";
            this.btnID.Size = new System.Drawing.Size(57, 28);
            this.btnID.TabIndex = 0;
            this.btnID.Text = "ID";
            this.btnID.UseVisualStyleBackColor = false;
            // 
            // btnIL
            // 
            this.btnIL.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIL.Location = new System.Drawing.Point(1, 421);
            this.btnIL.Margin = new System.Windows.Forms.Padding(1);
            this.btnIL.Name = "btnIL";
            this.btnIL.Size = new System.Drawing.Size(57, 28);
            this.btnIL.TabIndex = 0;
            this.btnIL.Text = "IL";
            this.btnIL.UseVisualStyleBackColor = true;
            // 
            // btnIN
            // 
            this.btnIN.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnIN.Location = new System.Drawing.Point(1, 451);
            this.btnIN.Margin = new System.Windows.Forms.Padding(1);
            this.btnIN.Name = "btnIN";
            this.btnIN.Size = new System.Drawing.Size(57, 28);
            this.btnIN.TabIndex = 0;
            this.btnIN.Text = "IN";
            this.btnIN.UseVisualStyleBackColor = true;
            // 
            // btnKS
            // 
            this.btnKS.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKS.Location = new System.Drawing.Point(1, 481);
            this.btnKS.Margin = new System.Windows.Forms.Padding(1);
            this.btnKS.Name = "btnKS";
            this.btnKS.Size = new System.Drawing.Size(57, 28);
            this.btnKS.TabIndex = 0;
            this.btnKS.Text = "KS";
            this.btnKS.UseVisualStyleBackColor = true;
            // 
            // btnKY
            // 
            this.btnKY.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnKY.Location = new System.Drawing.Point(1, 511);
            this.btnKY.Margin = new System.Windows.Forms.Padding(1);
            this.btnKY.Name = "btnKY";
            this.btnKY.Size = new System.Drawing.Size(57, 28);
            this.btnKY.TabIndex = 0;
            this.btnKY.Text = "KY";
            this.btnKY.UseVisualStyleBackColor = true;
            // 
            // btnLA
            // 
            this.btnLA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLA.Location = new System.Drawing.Point(1, 541);
            this.btnLA.Margin = new System.Windows.Forms.Padding(1);
            this.btnLA.Name = "btnLA";
            this.btnLA.Size = new System.Drawing.Size(57, 28);
            this.btnLA.TabIndex = 0;
            this.btnLA.Text = "LA";
            this.btnLA.UseVisualStyleBackColor = true;
            // 
            // btnMA
            // 
            this.btnMA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMA.Location = new System.Drawing.Point(1, 571);
            this.btnMA.Margin = new System.Windows.Forms.Padding(1);
            this.btnMA.Name = "btnMA";
            this.btnMA.Size = new System.Drawing.Size(57, 28);
            this.btnMA.TabIndex = 0;
            this.btnMA.Text = "MA";
            this.btnMA.UseVisualStyleBackColor = true;
            // 
            // btnMD
            // 
            this.btnMD.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnMD.Location = new System.Drawing.Point(60, 1);
            this.btnMD.Margin = new System.Windows.Forms.Padding(1);
            this.btnMD.Name = "btnMD";
            this.btnMD.Size = new System.Drawing.Size(58, 28);
            this.btnMD.TabIndex = 0;
            this.btnMD.Text = "MD";
            this.btnMD.UseVisualStyleBackColor = true;
            // 
            // btnME
            // 
            this.btnME.BackColor = System.Drawing.Color.LightGray;
            this.btnME.Enabled = false;
            this.btnME.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnME.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnME.Location = new System.Drawing.Point(60, 31);
            this.btnME.Margin = new System.Windows.Forms.Padding(1);
            this.btnME.Name = "btnME";
            this.btnME.Size = new System.Drawing.Size(57, 28);
            this.btnME.TabIndex = 0;
            this.btnME.Text = "ME";
            this.btnME.UseVisualStyleBackColor = false;
            // 
            // btnMI
            // 
            this.btnMI.Location = new System.Drawing.Point(60, 61);
            this.btnMI.Margin = new System.Windows.Forms.Padding(1);
            this.btnMI.Name = "btnMI";
            this.btnMI.Size = new System.Drawing.Size(57, 28);
            this.btnMI.TabIndex = 0;
            this.btnMI.Text = "MI";
            this.btnMI.UseVisualStyleBackColor = true;
            // 
            // btnMN
            // 
            this.btnMN.Location = new System.Drawing.Point(60, 91);
            this.btnMN.Margin = new System.Windows.Forms.Padding(1);
            this.btnMN.Name = "btnMN";
            this.btnMN.Size = new System.Drawing.Size(57, 28);
            this.btnMN.TabIndex = 0;
            this.btnMN.Text = "MN";
            this.btnMN.UseVisualStyleBackColor = true;
            // 
            // btnMO
            // 
            this.btnMO.Location = new System.Drawing.Point(60, 121);
            this.btnMO.Margin = new System.Windows.Forms.Padding(1);
            this.btnMO.Name = "btnMO";
            this.btnMO.Size = new System.Drawing.Size(57, 28);
            this.btnMO.TabIndex = 0;
            this.btnMO.Text = "MO";
            this.btnMO.UseVisualStyleBackColor = true;
            // 
            // btnMS
            // 
            this.btnMS.Location = new System.Drawing.Point(60, 151);
            this.btnMS.Margin = new System.Windows.Forms.Padding(1);
            this.btnMS.Name = "btnMS";
            this.btnMS.Size = new System.Drawing.Size(57, 28);
            this.btnMS.TabIndex = 0;
            this.btnMS.Text = "MS";
            this.btnMS.UseVisualStyleBackColor = true;
            // 
            // btnMT
            // 
            this.btnMT.BackColor = System.Drawing.Color.LightGray;
            this.btnMT.Enabled = false;
            this.btnMT.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnMT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMT.Location = new System.Drawing.Point(60, 181);
            this.btnMT.Margin = new System.Windows.Forms.Padding(1);
            this.btnMT.Name = "btnMT";
            this.btnMT.Size = new System.Drawing.Size(57, 28);
            this.btnMT.TabIndex = 0;
            this.btnMT.Text = "MT";
            this.btnMT.UseVisualStyleBackColor = false;
            // 
            // btnNC
            // 
            this.btnNC.Location = new System.Drawing.Point(60, 211);
            this.btnNC.Margin = new System.Windows.Forms.Padding(1);
            this.btnNC.Name = "btnNC";
            this.btnNC.Size = new System.Drawing.Size(57, 28);
            this.btnNC.TabIndex = 0;
            this.btnNC.Text = "NC";
            this.btnNC.UseVisualStyleBackColor = true;
            // 
            // btnND
            // 
            this.btnND.Location = new System.Drawing.Point(60, 241);
            this.btnND.Margin = new System.Windows.Forms.Padding(1);
            this.btnND.Name = "btnND";
            this.btnND.Size = new System.Drawing.Size(57, 28);
            this.btnND.TabIndex = 0;
            this.btnND.Text = "ND";
            this.btnND.UseVisualStyleBackColor = true;
            // 
            // btnNE
            // 
            this.btnNE.BackColor = System.Drawing.Color.LightGray;
            this.btnNE.Enabled = false;
            this.btnNE.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNE.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNE.Location = new System.Drawing.Point(60, 271);
            this.btnNE.Margin = new System.Windows.Forms.Padding(1);
            this.btnNE.Name = "btnNE";
            this.btnNE.Size = new System.Drawing.Size(57, 28);
            this.btnNE.TabIndex = 0;
            this.btnNE.Text = "NE";
            this.btnNE.UseVisualStyleBackColor = false;
            // 
            // btnNH
            // 
            this.btnNH.BackColor = System.Drawing.Color.LightGray;
            this.btnNH.Enabled = false;
            this.btnNH.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNH.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNH.Location = new System.Drawing.Point(60, 301);
            this.btnNH.Margin = new System.Windows.Forms.Padding(1);
            this.btnNH.Name = "btnNH";
            this.btnNH.Size = new System.Drawing.Size(57, 28);
            this.btnNH.TabIndex = 0;
            this.btnNH.Text = "NH";
            this.btnNH.UseVisualStyleBackColor = false;
            // 
            // btnNJ
            // 
            this.btnNJ.BackColor = System.Drawing.Color.LightGray;
            this.btnNJ.Enabled = false;
            this.btnNJ.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNJ.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNJ.Location = new System.Drawing.Point(60, 331);
            this.btnNJ.Margin = new System.Windows.Forms.Padding(1);
            this.btnNJ.Name = "btnNJ";
            this.btnNJ.Size = new System.Drawing.Size(57, 28);
            this.btnNJ.TabIndex = 0;
            this.btnNJ.Text = "NJ";
            this.btnNJ.UseVisualStyleBackColor = false;
            // 
            // btnNM
            // 
            this.btnNM.BackColor = System.Drawing.Color.LightGray;
            this.btnNM.Enabled = false;
            this.btnNM.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNM.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNM.Location = new System.Drawing.Point(60, 361);
            this.btnNM.Margin = new System.Windows.Forms.Padding(1);
            this.btnNM.Name = "btnNM";
            this.btnNM.Size = new System.Drawing.Size(57, 28);
            this.btnNM.TabIndex = 0;
            this.btnNM.Text = "NM";
            this.btnNM.UseVisualStyleBackColor = false;
            // 
            // btnNV
            // 
            this.btnNV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNV.BackColor = System.Drawing.Color.LightGray;
            this.btnNV.Enabled = false;
            this.btnNV.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNV.Location = new System.Drawing.Point(60, 391);
            this.btnNV.Margin = new System.Windows.Forms.Padding(1);
            this.btnNV.Name = "btnNV";
            this.btnNV.Size = new System.Drawing.Size(58, 28);
            this.btnNV.TabIndex = 0;
            this.btnNV.Text = "NV";
            this.btnNV.UseVisualStyleBackColor = false;
            // 
            // btnNY
            // 
            this.btnNY.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNY.BackColor = System.Drawing.Color.LightGray;
            this.btnNY.Enabled = false;
            this.btnNY.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnNY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNY.Location = new System.Drawing.Point(60, 421);
            this.btnNY.Margin = new System.Windows.Forms.Padding(1);
            this.btnNY.Name = "btnNY";
            this.btnNY.Size = new System.Drawing.Size(58, 28);
            this.btnNY.TabIndex = 0;
            this.btnNY.Text = "NY";
            this.btnNY.UseVisualStyleBackColor = false;
            // 
            // btnOH
            // 
            this.btnOH.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOH.Location = new System.Drawing.Point(60, 451);
            this.btnOH.Margin = new System.Windows.Forms.Padding(1);
            this.btnOH.Name = "btnOH";
            this.btnOH.Size = new System.Drawing.Size(58, 28);
            this.btnOH.TabIndex = 0;
            this.btnOH.Text = "OH";
            this.btnOH.UseVisualStyleBackColor = true;
            // 
            // btnOK
            // 
            this.btnOK.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOK.Location = new System.Drawing.Point(60, 481);
            this.btnOK.Margin = new System.Windows.Forms.Padding(1);
            this.btnOK.Name = "btnOK";
            this.btnOK.Size = new System.Drawing.Size(58, 28);
            this.btnOK.TabIndex = 0;
            this.btnOK.Text = "OK";
            this.btnOK.UseVisualStyleBackColor = true;
            // 
            // btnOR
            // 
            this.btnOR.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnOR.Location = new System.Drawing.Point(60, 511);
            this.btnOR.Margin = new System.Windows.Forms.Padding(1);
            this.btnOR.Name = "btnOR";
            this.btnOR.Size = new System.Drawing.Size(58, 28);
            this.btnOR.TabIndex = 0;
            this.btnOR.Text = "OR";
            this.btnOR.UseVisualStyleBackColor = true;
            // 
            // btnPA
            // 
            this.btnPA.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPA.Location = new System.Drawing.Point(60, 541);
            this.btnPA.Margin = new System.Windows.Forms.Padding(1);
            this.btnPA.Name = "btnPA";
            this.btnPA.Size = new System.Drawing.Size(58, 28);
            this.btnPA.TabIndex = 0;
            this.btnPA.Text = "PA";
            this.btnPA.UseVisualStyleBackColor = true;
            // 
            // btnRI
            // 
            this.btnRI.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRI.BackColor = System.Drawing.Color.LightGray;
            this.btnRI.Enabled = false;
            this.btnRI.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnRI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRI.Location = new System.Drawing.Point(60, 571);
            this.btnRI.Margin = new System.Windows.Forms.Padding(1);
            this.btnRI.Name = "btnRI";
            this.btnRI.Size = new System.Drawing.Size(58, 28);
            this.btnRI.TabIndex = 0;
            this.btnRI.Text = "RI";
            this.btnRI.UseVisualStyleBackColor = false;
            // 
            // btnSC
            // 
            this.btnSC.Location = new System.Drawing.Point(120, 1);
            this.btnSC.Margin = new System.Windows.Forms.Padding(1);
            this.btnSC.Name = "btnSC";
            this.btnSC.Size = new System.Drawing.Size(57, 28);
            this.btnSC.TabIndex = 0;
            this.btnSC.Text = "SC";
            this.btnSC.UseVisualStyleBackColor = true;
            // 
            // btnSD
            // 
            this.btnSD.BackColor = System.Drawing.Color.LightGray;
            this.btnSD.Enabled = false;
            this.btnSD.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnSD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSD.Location = new System.Drawing.Point(120, 31);
            this.btnSD.Margin = new System.Windows.Forms.Padding(1);
            this.btnSD.Name = "btnSD";
            this.btnSD.Size = new System.Drawing.Size(57, 28);
            this.btnSD.TabIndex = 0;
            this.btnSD.Text = "SD";
            this.btnSD.UseVisualStyleBackColor = false;
            // 
            // btnTN
            // 
            this.btnTN.Location = new System.Drawing.Point(120, 61);
            this.btnTN.Margin = new System.Windows.Forms.Padding(1);
            this.btnTN.Name = "btnTN";
            this.btnTN.Size = new System.Drawing.Size(57, 28);
            this.btnTN.TabIndex = 0;
            this.btnTN.Text = "TN";
            this.btnTN.UseVisualStyleBackColor = true;
            // 
            // btnTX
            // 
            this.btnTX.Location = new System.Drawing.Point(120, 91);
            this.btnTX.Margin = new System.Windows.Forms.Padding(1);
            this.btnTX.Name = "btnTX";
            this.btnTX.Size = new System.Drawing.Size(57, 28);
            this.btnTX.TabIndex = 0;
            this.btnTX.Text = "TX";
            this.btnTX.UseVisualStyleBackColor = true;
            // 
            // btnUT
            // 
            this.btnUT.Location = new System.Drawing.Point(120, 121);
            this.btnUT.Margin = new System.Windows.Forms.Padding(1);
            this.btnUT.Name = "btnUT";
            this.btnUT.Size = new System.Drawing.Size(57, 28);
            this.btnUT.TabIndex = 0;
            this.btnUT.Text = "UT";
            this.btnUT.UseVisualStyleBackColor = true;
            // 
            // btnVA
            // 
            this.btnVA.Location = new System.Drawing.Point(120, 151);
            this.btnVA.Margin = new System.Windows.Forms.Padding(1);
            this.btnVA.Name = "btnVA";
            this.btnVA.Size = new System.Drawing.Size(57, 28);
            this.btnVA.TabIndex = 0;
            this.btnVA.Text = "VA";
            this.btnVA.UseVisualStyleBackColor = true;
            // 
            // btnVT
            // 
            this.btnVT.Location = new System.Drawing.Point(120, 181);
            this.btnVT.Margin = new System.Windows.Forms.Padding(1);
            this.btnVT.Name = "btnVT";
            this.btnVT.Size = new System.Drawing.Size(57, 28);
            this.btnVT.TabIndex = 0;
            this.btnVT.Text = "VT";
            this.btnVT.UseVisualStyleBackColor = true;
            // 
            // btnGuam
            // 
            this.btnGuam.BackColor = System.Drawing.Color.LightGray;
            this.btnGuam.Enabled = false;
            this.btnGuam.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnGuam.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGuam.Location = new System.Drawing.Point(120, 331);
            this.btnGuam.Margin = new System.Windows.Forms.Padding(1);
            this.btnGuam.Name = "btnGuam";
            this.btnGuam.Size = new System.Drawing.Size(57, 28);
            this.btnGuam.TabIndex = 0;
            this.btnGuam.Text = "GUAM";
            this.btnGuam.UseVisualStyleBackColor = false;
            // 
            // btnPR
            // 
            this.btnPR.BackColor = System.Drawing.Color.LightGray;
            this.btnPR.Enabled = false;
            this.btnPR.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnPR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPR.Location = new System.Drawing.Point(120, 361);
            this.btnPR.Margin = new System.Windows.Forms.Padding(1);
            this.btnPR.Name = "btnPR";
            this.btnPR.Size = new System.Drawing.Size(57, 28);
            this.btnPR.TabIndex = 0;
            this.btnPR.Text = "PR";
            this.btnPR.UseVisualStyleBackColor = false;
            // 
            // btnWY
            // 
            this.btnWY.BackColor = System.Drawing.Color.LightGray;
            this.btnWY.Enabled = false;
            this.btnWY.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnWY.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnWY.Location = new System.Drawing.Point(120, 301);
            this.btnWY.Margin = new System.Windows.Forms.Padding(1);
            this.btnWY.Name = "btnWY";
            this.btnWY.Size = new System.Drawing.Size(57, 28);
            this.btnWY.TabIndex = 0;
            this.btnWY.Text = "WY";
            this.btnWY.UseVisualStyleBackColor = false;
            // 
            // btnWV
            // 
            this.btnWV.Location = new System.Drawing.Point(120, 271);
            this.btnWV.Margin = new System.Windows.Forms.Padding(1);
            this.btnWV.Name = "btnWV";
            this.btnWV.Size = new System.Drawing.Size(57, 28);
            this.btnWV.TabIndex = 0;
            this.btnWV.Text = "WV";
            this.btnWV.UseVisualStyleBackColor = true;
            // 
            // btnWI
            // 
            this.btnWI.Location = new System.Drawing.Point(120, 241);
            this.btnWI.Margin = new System.Windows.Forms.Padding(1);
            this.btnWI.Name = "btnWI";
            this.btnWI.Size = new System.Drawing.Size(57, 28);
            this.btnWI.TabIndex = 0;
            this.btnWI.Text = "WI";
            this.btnWI.UseVisualStyleBackColor = true;
            // 
            // btnWA
            // 
            this.btnWA.Location = new System.Drawing.Point(120, 211);
            this.btnWA.Margin = new System.Windows.Forms.Padding(1);
            this.btnWA.Name = "btnWA";
            this.btnWA.Size = new System.Drawing.Size(57, 28);
            this.btnWA.TabIndex = 0;
            this.btnWA.Text = "WA";
            this.btnWA.UseVisualStyleBackColor = true;
            // 
            // lblStateButtons
            // 
            this.lblStateButtons.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateButtons.Location = new System.Drawing.Point(18, 19);
            this.lblStateButtons.Margin = new System.Windows.Forms.Padding(3, 0, 1, 0);
            this.lblStateButtons.Name = "lblStateButtons";
            this.lblStateButtons.Size = new System.Drawing.Size(100, 19);
            this.lblStateButtons.TabIndex = 1;
            this.lblStateButtons.Text = "Select a State:";
            // 
            // btnFileBrowse
            // 
            this.btnFileBrowse.Location = new System.Drawing.Point(715, 45);
            this.btnFileBrowse.Name = "btnFileBrowse";
            this.btnFileBrowse.Size = new System.Drawing.Size(75, 23);
            this.btnFileBrowse.TabIndex = 2;
            this.btnFileBrowse.Text = "Browse...";
            this.btnFileBrowse.UseVisualStyleBackColor = true;
            this.btnFileBrowse.Click += new System.EventHandler(this.btnFileBrowse_Click);
            // 
            // txtFileName
            // 
            this.txtFileName.Location = new System.Drawing.Point(499, 46);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(210, 20);
            this.txtFileName.TabIndex = 1;
            // 
            // lblInstruct1
            // 
            this.lblInstruct1.Location = new System.Drawing.Point(208, 40);
            this.lblInstruct1.Name = "lblInstruct1";
            this.lblInstruct1.Size = new System.Drawing.Size(273, 59);
            this.lblInstruct1.TabIndex = 0;
            this.lblInstruct1.Text = "Select the batch file using the Browse button at right, then click the appropriat" +
    "e state button at left.";
            // 
            // lblInstructions
            // 
            this.lblInstructions.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.Location = new System.Drawing.Point(208, 19);
            this.lblInstructions.Margin = new System.Windows.Forms.Padding(3, 0, 1, 0);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(273, 19);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "Instructions:";
            // 
            // lblConfirmation
            // 
            this.lblConfirmation.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblConfirmation.Location = new System.Drawing.Point(211, 81);
            this.lblConfirmation.Margin = new System.Windows.Forms.Padding(3, 0, 1, 0);
            this.lblConfirmation.Name = "lblConfirmation";
            this.lblConfirmation.Size = new System.Drawing.Size(273, 32);
            this.lblConfirmation.TabIndex = 0;
            this.lblConfirmation.Text = "Confirmation or Error Message:";
            // 
            // txtConfirmationMessage
            // 
            this.txtSuccessFailMessage.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtSuccessFailMessage.Location = new System.Drawing.Point(211, 102);
            this.txtSuccessFailMessage.Name = "txtConfirmationMessage";
            this.txtSuccessFailMessage.ReadOnly = true;
            this.txtSuccessFailMessage.Size = new System.Drawing.Size(660, 190);
            this.txtSuccessFailMessage.TabIndex = 0;
            this.txtSuccessFailMessage.TabStop = false;
            this.txtSuccessFailMessage.Text = "Message will appear here.";
            // 
            // btnFileClear
            // 
            this.btnFileClear.Location = new System.Drawing.Point(796, 45);
            this.btnFileClear.Name = "btnFileClear";
            this.btnFileClear.Size = new System.Drawing.Size(75, 23);
            this.btnFileClear.TabIndex = 3;
            this.btnFileClear.Text = "Clear";
            this.btnFileClear.UseVisualStyleBackColor = true;
            // 
            // lblFixed
            // 
            this.lblFixed.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFixed.Location = new System.Drawing.Point(211, 312);
            this.lblFixed.Margin = new System.Windows.Forms.Padding(3, 0, 1, 0);
            this.lblFixed.Name = "lblFixed";
            this.lblFixed.Size = new System.Drawing.Size(273, 32);
            this.lblFixed.TabIndex = 0;
            this.lblFixed.Text = "Items Fixed:";
            // 
            // txtFixedDetails
            // 
            this.txtChangeLog.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtChangeLog.Location = new System.Drawing.Point(211, 336);
            this.txtChangeLog.Name = "txtFixedDetails";
            this.txtChangeLog.ReadOnly = true;
            this.txtChangeLog.Size = new System.Drawing.Size(660, 240);
            this.txtChangeLog.TabIndex = 0;
            this.txtChangeLog.TabStop = false;
            this.txtChangeLog.Text = "Change Log details will appear here.";
            // 
            // btnSaveChangeLog
            // 
            this.btnSaveChangeLog.Location = new System.Drawing.Point(749, 582);
            this.btnSaveChangeLog.Name = "btnSaveChangeLog";
            this.btnSaveChangeLog.Size = new System.Drawing.Size(122, 23);
            this.btnSaveChangeLog.TabIndex = 100;
            this.btnSaveChangeLog.Text = "Save Change Log...";
            this.btnSaveChangeLog.UseVisualStyleBackColor = true;
            // 
            // dialogSaveChangeLog
            // 
            this.dialogSaveChangeLog.Title = "Save Change Log As...";
            // 
            // lblEmailForQuestions
            // 
            this.lblEmailForQuestions.AutoSize = true;
            this.lblEmailForQuestions.Location = new System.Drawing.Point(585, 610);
            this.lblEmailForQuestions.Name = "lblEmailForQuestions";
            this.lblEmailForQuestions.Size = new System.Drawing.Size(290, 13);
            this.lblEmailForQuestions.TabIndex = 0;
            this.lblEmailForQuestions.Text = "If you have questions, email wbraddock@efficientforms.com";
            // 
            // btnVI
            // 
            this.btnVI.BackColor = System.Drawing.Color.LightGray;
            this.btnVI.Enabled = false;
            this.btnVI.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.btnVI.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVI.Location = new System.Drawing.Point(120, 391);
            this.btnVI.Margin = new System.Windows.Forms.Padding(1);
            this.btnVI.Name = "btnVI";
            this.btnVI.Size = new System.Drawing.Size(57, 28);
            this.btnVI.TabIndex = 0;
            this.btnVI.Text = "VI";
            this.btnVI.UseVisualStyleBackColor = false;
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 658);
            this.Controls.Add(this.lblEmailForQuestions);
            this.Controls.Add(this.btnSaveChangeLog);
            this.Controls.Add(this.txtChangeLog);
            this.Controls.Add(this.txtSuccessFailMessage);
            this.Controls.Add(this.lblInstruct1);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.btnFileClear);
            this.Controls.Add(this.btnFileBrowse);
            this.Controls.Add(this.lblInstructions);
            this.Controls.Add(this.lblFixed);
            this.Controls.Add(this.lblConfirmation);
            this.Controls.Add(this.lblStateButtons);
            this.Controls.Add(this.tblLayoutPanelStates);
            this.Name = "FormMain";
            this.Text = "Efficient Forms BatchFix Utility";
            this.tblLayoutPanelStates.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Button btnSaveChangeLog;
        private System.Windows.Forms.SaveFileDialog dialogSaveChangeLog;
        private System.Windows.Forms.Label lblEmailForQuestions;
        private System.Windows.Forms.Button btnVI;
    }

}

