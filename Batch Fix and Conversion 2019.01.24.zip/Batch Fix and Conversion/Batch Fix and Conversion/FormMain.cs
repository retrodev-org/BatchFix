﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch_Fix_and_Conversion
{
    public partial class FormMain : Form
    {
        // String to receive data from the batch input file
        private static String fileInputData;
        const string INVALID_FILENAME_MSG = "Invalid filename. Please select a batch file.";
        bool appSubmit = false;

        public bool AppSubmit { get => appSubmit; set => appSubmit = value; }
        public static string FileInputData { get => fileInputData; set => fileInputData = value; }

        public FormMain()
        {
            InitializeComponent();
            
            // TODO Create option to show or hide custom message boxes
            // Employee info box
            // Employer info box
            // Target group info box
            // Other(s)?

        }

        private void StartBatch(string stateAbbreviation)
        {
            MyBatchFile thisBatch = new MyBatchFile(stateAbbreviation);
        }

        private void btnFileBrowse_Click(object sender, EventArgs e)
        {
            // Displays an OpenFileDialog so the user can select a file.  
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Title = "Select a State Batch File";

            try
            {
                if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    System.IO.StreamReader sr = new
                       System.IO.StreamReader(openFileDialog1.FileName);
                    MessageBox.Show(sr.ReadToEnd());
                    sr.Close();

                    FileInputData = sr.ToString();
                }
            } catch (Exception fileError)
            {
                MessageBox.Show("Error reading file: " + openFileDialog1.FileName.ToString() + "\r" + fileError);
            }
        }

        private void BtnAL_Click(object sender, EventArgs e)
        {
            MyBatchFile thisBatch = CreateBatch(btnAL.Text);
            if (txtFileName.Text == "")
                txtSuccessFailMessage.Text = INVALID_FILENAME_MSG;
            else
            {
                thisBatch.StateOfSubmission.InitializeAL();
            }
        }

        private MyBatchFile CreateBatch(string stateAbbreviation)
        {
            MyBatchFile thisBatch = new MyBatchFile(stateAbbreviation);

            // TODO handle batch file, physical files, etc.
            
            // Validate application, all fields
            foreach (MyApp app in thisBatch.AppList)
            {
                thisBatch.IsReady = app.ValidateApplication(thisBatch.StateOfSubmission.StateIdentifier);
                if (thisBatch.IsReady == true)
                {
                    FormAppUpdate childForm = new FormAppUpdate(app);

                    while (app.ErrorCount > 0 && app.Bypass == false && AppSubmit == false)
                    {
                        // TODO Establish button handling and passing new values from text fields & checkboxes

                        if (childForm.bypassApp == true)
                        {
                            thisBatch.AppsErrorList.Add(app);
                            childForm.Dispose();
                        }

                        if (childForm.appSubmit == true)
                        {
                            if (app.ErrorCount == 0)
                            {
                                thisBatch.AppListFormatted.Add(app);
                                childForm.Dispose();
                            } else
                            {
                                string newError = "Please resolve all errors before submitting the application. See error list below and/or items in red above. \r\r" + childForm.GetTxtAppErrorMessageText();
                                childForm.appSubmit = false;
                            }
                        }
                    } // end while(app.ErrorCount > 0)

                    if (app.Bypass == false)
                    {
                        try
                        {
                            // Format application for state
                            MyApp formattedApp = thisBatch.FormatApplication(app, thisBatch.StateOfSubmission);
                            try
                            {
                                // Save app to new list of formatted apps
                                thisBatch.AppListFormatted.Add(formattedApp);
                            } catch (Exception e2)
                            {
                                // TODO Possible error thrown if adding app to AppListFormatted runs into a problem
                                MessageBox.Show("Problem occurred adding formatted application to batch list. SSN: " + app.GetSSNLast4() + e2);
                            }
                        } catch (Exception e)
                        {
                            // TODO Possible error thrown if thisBatch.FormatApplication() runs into a problem
                            MessageBox.Show("Problem occurred formatting application for state. " + e);
                        }
                    }
                }
                else
                {
                    thisBatch.AppsErrorList.Add(app);
                }
            }
            return thisBatch;
            // TODO handle messages re: AppsErrorList in conf/error messages & save to log file
            // TODO write batch records from AppsErrorList to new batch errors file (filename + _errors) to be rechecked later

        }

        public string GetTxtSuccessFailMessage()
        {
            return txtSuccessFailMessage.Text;
        }
        public void SetTxtSuccessFailMessage(string input)
        {
            txtSuccessFailMessage.Text = input;
            txtSuccessFailMessage.Refresh();
        }
        public string GetTxtChangeLog()
        {
            return txtChangeLog.Text;
        }
        public void SetTxtChangeLog(string input)
        {
            txtChangeLog.Text = input;
            txtChangeLog.Refresh();
        }
    }
}
