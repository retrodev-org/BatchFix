﻿namespace Batch_Fix_and_Conversion
{
    public partial class FormAppUpdate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        public void AppendErrorMessageAppUpdate(string errorMessage)
        {
            txtAppErrorMessageText.AppendText("\\r" + errorMessage);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.grpEmployeeInformation = new System.Windows.Forms.GroupBox();
            this.txtEmployeeEmailAddress = new System.Windows.Forms.TextBox();
            this.txtEmployeePhoneNumber = new System.Windows.Forms.TextBox();
            this.txtEmployeeDOB = new System.Windows.Forms.TextBox();
            this.txtEmployeeStreet1 = new System.Windows.Forms.TextBox();
            this.txtEmployeeZip = new System.Windows.Forms.TextBox();
            this.txtEmployeeState = new System.Windows.Forms.TextBox();
            this.txtEmployeeSignatureDate = new System.Windows.Forms.TextBox();
            this.txtEmployeeCounty = new System.Windows.Forms.TextBox();
            this.txtEmployeeCity = new System.Windows.Forms.TextBox();
            this.txtEmployeeStreet2 = new System.Windows.Forms.TextBox();
            this.txtEmployeeSSN = new System.Windows.Forms.TextBox();
            this.txtEmployeeLastName = new System.Windows.Forms.TextBox();
            this.txtEmployeeMiddleName = new System.Windows.Forms.TextBox();
            this.txtEmployeeFirstName = new System.Windows.Forms.TextBox();
            this.serviceController1 = new System.ServiceProcess.ServiceController();
            this.grp8850Questionnaire = new System.Windows.Forms.GroupBox();
            this.chkBx8850q7 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q6 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q5 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q4 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q3 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q2 = new System.Windows.Forms.CheckBox();
            this.chkBx8850q1 = new System.Windows.Forms.CheckBox();
            this.grp9061 = new System.Windows.Forms.GroupBox();
            this.txtLTUStateOther = new System.Windows.Forms.TextBox();
            this.cmb22LtuState = new System.Windows.Forms.ComboBox();
            this.txt9061EmployerSignatureDate = new System.Windows.Forms.TextBox();
            this.chkBx22LTU = new System.Windows.Forms.CheckBox();
            this.chkBx21Vet4Weeks = new System.Windows.Forms.CheckBox();
            this.chkBx20Vet6Months = new System.Windows.Forms.CheckBox();
            this.chkBx19SSI = new System.Windows.Forms.CheckBox();
            this.lbl18SummerYouthErrorMessage = new System.Windows.Forms.Label();
            this.chkBx18SummerYouth = new System.Windows.Forms.CheckBox();
            this.chkBx18EmpowermentZone = new System.Windows.Forms.CheckBox();
            this.chkBx18RuralRenewalCounty = new System.Windows.Forms.CheckBox();
            this.panelFelonFedOrState = new System.Windows.Forms.Panel();
            this.radFelonFederal = new System.Windows.Forms.RadioButton();
            this.radFelonState = new System.Windows.Forms.RadioButton();
            this.txtFelonReleaseDate = new System.Windows.Forms.TextBox();
            this.txtFelonConvictionDate = new System.Windows.Forms.TextBox();
            this.chkBxFelon = new System.Windows.Forms.CheckBox();
            this.chkBxTanf4 = new System.Windows.Forms.CheckBox();
            this.chkBxTanf3 = new System.Windows.Forms.CheckBox();
            this.chkBxTanf2 = new System.Windows.Forms.CheckBox();
            this.chkBx16Tanf1 = new System.Windows.Forms.CheckBox();
            this.chkBx15VAReferral = new System.Windows.Forms.CheckBox();
            this.chkBx15TicketToWork = new System.Windows.Forms.CheckBox();
            this.chkBx15VocRehab = new System.Windows.Forms.CheckBox();
            this.txtSnapRecipientName = new System.Windows.Forms.TextBox();
            this.chkBx14Snap2 = new System.Windows.Forms.CheckBox();
            this.chkBx14Snap1 = new System.Windows.Forms.CheckBox();
            this.chkBx13VetUnemployed6Months = new System.Windows.Forms.CheckBox();
            this.chkBx13Vet1Year = new System.Windows.Forms.CheckBox();
            this.chkBx13VetDisabled = new System.Windows.Forms.CheckBox();
            this.txtSnapRecipientState = new System.Windows.Forms.TextBox();
            this.txtVetSnapRecipientState = new System.Windows.Forms.TextBox();
            this.txtSnapRecipientCity = new System.Windows.Forms.TextBox();
            this.txtTanfRecipientCity = new System.Windows.Forms.TextBox();
            this.txtVetSnapRecipientCity = new System.Windows.Forms.TextBox();
            this.txtTanfRecipientName = new System.Windows.Forms.TextBox();
            this.txtVetSnapRecipientName = new System.Windows.Forms.TextBox();
            this.chkBx13VetSnap = new System.Windows.Forms.CheckBox();
            this.chkBx13Veteran = new System.Windows.Forms.CheckBox();
            this.cmboOnetCode = new System.Windows.Forms.ComboBox();
            this.txtEmployerStreet2 = new System.Windows.Forms.TextBox();
            this.txtWage = new System.Windows.Forms.TextBox();
            this.txtEmployerPhone = new System.Windows.Forms.TextBox();
            this.txtEmployerFEIN = new System.Windows.Forms.TextBox();
            this.txtEmployerStreet1 = new System.Windows.Forms.TextBox();
            this.txtEmployerName = new System.Windows.Forms.TextBox();
            this.txtEmployerCity = new System.Windows.Forms.TextBox();
            this.txtEmployerZip = new System.Windows.Forms.TextBox();
            this.txtEmployerState = new System.Windows.Forms.TextBox();
            this.btnAppUpdateSubmit = new System.Windows.Forms.Button();
            this.btnAppUpdateReset = new System.Windows.Forms.Button();
            this.btnAppUpdateSkip = new System.Windows.Forms.Button();
            this.lblAppErrorMessage = new System.Windows.Forms.Label();
            this.txtAppErrorMessageText = new System.Windows.Forms.TextBox();
            this.txtTanfRecipientState = new System.Windows.Forms.TextBox();
            this.grpEmployeeInformation.SuspendLayout();
            this.grp8850Questionnaire.SuspendLayout();
            this.grp9061.SuspendLayout();
            this.panelFelonFedOrState.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(640, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Please confirm and correct the information as needed. Required items are in black" +
    " and white. Optional items are grey. Errors will be red.";
            // 
            // grpEmployeeInformation
            // 
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeEmailAddress);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeePhoneNumber);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeDOB);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeStreet1);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeZip);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeState);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeSignatureDate);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeCounty);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeCity);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeStreet2);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeSSN);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeLastName);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeMiddleName);
            this.grpEmployeeInformation.Controls.Add(this.txtEmployeeFirstName);
            this.grpEmployeeInformation.Location = new System.Drawing.Point(17, 39);
            this.grpEmployeeInformation.Name = "grpEmployeeInformation";
            this.grpEmployeeInformation.Size = new System.Drawing.Size(298, 220);
            this.grpEmployeeInformation.TabIndex = 1;
            this.grpEmployeeInformation.TabStop = false;
            this.grpEmployeeInformation.Text = "Employee Information";
            // 
            // txtEmployeeEmailAddress
            // 
            this.txtEmployeeEmailAddress.Location = new System.Drawing.Point(142, 131);
            this.txtEmployeeEmailAddress.Name = "txtEmployeeEmailAddress";
            this.txtEmployeeEmailAddress.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeEmailAddress.TabIndex = 13;
            this.txtEmployeeEmailAddress.Text = "Email Address";
            this.txtEmployeeEmailAddress.Enter += new System.EventHandler(this.txtEmployeeEmailAddress_Enter);
            // 
            // txtEmployeePhoneNumber
            // 
            this.txtEmployeePhoneNumber.Location = new System.Drawing.Point(142, 105);
            this.txtEmployeePhoneNumber.Name = "txtEmployeePhoneNumber";
            this.txtEmployeePhoneNumber.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeePhoneNumber.TabIndex = 12;
            this.txtEmployeePhoneNumber.Text = "Phone Number";
            this.txtEmployeePhoneNumber.Enter += new System.EventHandler(this.txtEmployeePhone_Enter);
            // 
            // txtEmployeeDOB
            // 
            this.txtEmployeeDOB.Location = new System.Drawing.Point(142, 79);
            this.txtEmployeeDOB.Name = "txtEmployeeDOB";
            this.txtEmployeeDOB.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeDOB.TabIndex = 11;
            this.txtEmployeeDOB.Text = "Date of Birth";
            this.txtEmployeeDOB.Enter += new System.EventHandler(this.txtEmployeeDOB_Enter);
            // 
            // txtEmployeeStreet1
            // 
            this.txtEmployeeStreet1.Location = new System.Drawing.Point(7, 53);
            this.txtEmployeeStreet1.Name = "txtEmployeeStreet1";
            this.txtEmployeeStreet1.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeStreet1.TabIndex = 4;
            this.txtEmployeeStreet1.Text = "Street Address 1";
            this.txtEmployeeStreet1.Enter += new System.EventHandler(this.txtEmployeeStreet1_Enter);
            // 
            // txtEmployeeZip
            // 
            this.txtEmployeeZip.Location = new System.Drawing.Point(62, 131);
            this.txtEmployeeZip.Name = "txtEmployeeZip";
            this.txtEmployeeZip.Size = new System.Drawing.Size(64, 20);
            this.txtEmployeeZip.TabIndex = 8;
            this.txtEmployeeZip.Text = "Zip Code";
            this.txtEmployeeZip.Enter += new System.EventHandler(this.txtEmployeeZip_Enter);
            // 
            // txtEmployeeState
            // 
            this.txtEmployeeState.Location = new System.Drawing.Point(7, 131);
            this.txtEmployeeState.Name = "txtEmployeeState";
            this.txtEmployeeState.Size = new System.Drawing.Size(49, 20);
            this.txtEmployeeState.TabIndex = 7;
            this.txtEmployeeState.Text = "State";
            this.txtEmployeeState.Enter += new System.EventHandler(this.txtEmployeeState_Enter);
            // 
            // txtEmployeeSignatureDate
            // 
            this.txtEmployeeSignatureDate.Location = new System.Drawing.Point(7, 183);
            this.txtEmployeeSignatureDate.Name = "txtEmployeeSignatureDate";
            this.txtEmployeeSignatureDate.Size = new System.Drawing.Size(175, 20);
            this.txtEmployeeSignatureDate.TabIndex = 0;
            this.txtEmployeeSignatureDate.Text = "Employee Sign Date Form 8850";
            this.txtEmployeeSignatureDate.Enter += new System.EventHandler(this.txtEmployeeSignatureDate_Enter);
            // 
            // txtEmployeeCounty
            // 
            this.txtEmployeeCounty.Location = new System.Drawing.Point(7, 157);
            this.txtEmployeeCounty.Name = "txtEmployeeCounty";
            this.txtEmployeeCounty.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeCounty.TabIndex = 9;
            this.txtEmployeeCounty.Text = "County";
            this.txtEmployeeCounty.Enter += new System.EventHandler(this.txtEmployeeCity_Enter);
            // 
            // txtEmployeeCity
            // 
            this.txtEmployeeCity.Location = new System.Drawing.Point(7, 105);
            this.txtEmployeeCity.Name = "txtEmployeeCity";
            this.txtEmployeeCity.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeCity.TabIndex = 6;
            this.txtEmployeeCity.Text = "City";
            this.txtEmployeeCity.Enter += new System.EventHandler(this.txtEmployeeCity_Enter);
            // 
            // txtEmployeeStreet2
            // 
            this.txtEmployeeStreet2.Location = new System.Drawing.Point(7, 79);
            this.txtEmployeeStreet2.Name = "txtEmployeeStreet2";
            this.txtEmployeeStreet2.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeStreet2.TabIndex = 5;
            this.txtEmployeeStreet2.Text = "Street Address 2";
            this.txtEmployeeStreet2.Enter += new System.EventHandler(this.txtEmployeeStreet2_Enter);
            // 
            // txtEmployeeSSN
            // 
            this.txtEmployeeSSN.Location = new System.Drawing.Point(142, 53);
            this.txtEmployeeSSN.Name = "txtEmployeeSSN";
            this.txtEmployeeSSN.Size = new System.Drawing.Size(119, 20);
            this.txtEmployeeSSN.TabIndex = 10;
            this.txtEmployeeSSN.Text = "SSN";
            this.txtEmployeeSSN.Enter += new System.EventHandler(this.txtEmployeeSSN_Enter);
            // 
            // txtEmployeeLastName
            // 
            this.txtEmployeeLastName.Location = new System.Drawing.Point(188, 20);
            this.txtEmployeeLastName.Name = "txtEmployeeLastName";
            this.txtEmployeeLastName.Size = new System.Drawing.Size(100, 20);
            this.txtEmployeeLastName.TabIndex = 3;
            this.txtEmployeeLastName.Text = "Last Name";
            this.txtEmployeeLastName.Enter += new System.EventHandler(this.txtEmployeeLastName_Enter);
            // 
            // txtEmployeeMiddleName
            // 
            this.txtEmployeeMiddleName.Location = new System.Drawing.Point(113, 20);
            this.txtEmployeeMiddleName.Name = "txtEmployeeMiddleName";
            this.txtEmployeeMiddleName.Size = new System.Drawing.Size(69, 20);
            this.txtEmployeeMiddleName.TabIndex = 2;
            this.txtEmployeeMiddleName.Text = "Middle Name";
            this.txtEmployeeMiddleName.Enter += new System.EventHandler(this.txtEmployeeMiddleName_Enter);
            // 
            // txtEmployeeFirstName
            // 
            this.txtEmployeeFirstName.Location = new System.Drawing.Point(7, 20);
            this.txtEmployeeFirstName.Name = "txtEmployeeFirstName";
            this.txtEmployeeFirstName.Size = new System.Drawing.Size(100, 20);
            this.txtEmployeeFirstName.TabIndex = 1;
            this.txtEmployeeFirstName.Text = "First Name";
            this.txtEmployeeFirstName.Enter += new System.EventHandler(this.txtEmployeeFirstName_Enter);
            // 
            // grp8850Questionnaire
            // 
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q7);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q6);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q5);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q4);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q3);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q2);
            this.grp8850Questionnaire.Controls.Add(this.chkBx8850q1);
            this.grp8850Questionnaire.Location = new System.Drawing.Point(17, 266);
            this.grp8850Questionnaire.Name = "grp8850Questionnaire";
            this.grp8850Questionnaire.Size = new System.Drawing.Size(298, 196);
            this.grp8850Questionnaire.TabIndex = 2;
            this.grp8850Questionnaire.TabStop = false;
            this.grp8850Questionnaire.Text = "Form 8850 Questionnaire";
            // 
            // chkBx8850q7
            // 
            this.chkBx8850q7.AutoSize = true;
            this.chkBx8850q7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q7.Location = new System.Drawing.Point(7, 165);
            this.chkBx8850q7.Name = "chkBx8850q7";
            this.chkBx8850q7.Size = new System.Drawing.Size(156, 17);
            this.chkBx8850q7.TabIndex = 20;
            this.chkBx8850q7.Text = "7. Long term unemployment";
            this.chkBx8850q7.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q6
            // 
            this.chkBx8850q6.AutoSize = true;
            this.chkBx8850q6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q6.Location = new System.Drawing.Point(7, 143);
            this.chkBx8850q6.Name = "chkBx8850q6";
            this.chkBx8850q6.Size = new System.Drawing.Size(109, 17);
            this.chkBx8850q6.TabIndex = 19;
            this.chkBx8850q6.Text = "6. TANF recipient";
            this.chkBx8850q6.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q5
            // 
            this.chkBx8850q5.AutoSize = true;
            this.chkBx8850q5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q5.Location = new System.Drawing.Point(7, 121);
            this.chkBx8850q5.Name = "chkBx8850q5";
            this.chkBx8850q5.Size = new System.Drawing.Size(223, 17);
            this.chkBx8850q5.TabIndex = 18;
            this.chkBx8850q5.Text = "5. Vet disabled and unemployed 6 months";
            this.chkBx8850q5.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q4
            // 
            this.chkBx8850q4.AutoSize = true;
            this.chkBx8850q4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q4.Location = new System.Drawing.Point(7, 99);
            this.chkBx8850q4.Name = "chkBx8850q4";
            this.chkBx8850q4.Size = new System.Drawing.Size(233, 17);
            this.chkBx8850q4.TabIndex = 17;
            this.chkBx8850q4.Text = "4. Vet disabled and left service within 1 year";
            this.chkBx8850q4.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q3
            // 
            this.chkBx8850q3.AutoSize = true;
            this.chkBx8850q3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q3.Location = new System.Drawing.Point(7, 77);
            this.chkBx8850q3.Name = "chkBx8850q3";
            this.chkBx8850q3.Size = new System.Drawing.Size(160, 17);
            this.chkBx8850q3.TabIndex = 16;
            this.chkBx8850q3.Text = "3. Vet unemployed 6 months";
            this.chkBx8850q3.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q2
            // 
            this.chkBx8850q2.AutoSize = true;
            this.chkBx8850q2.CheckAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkBx8850q2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q2.Location = new System.Drawing.Point(7, 42);
            this.chkBx8850q2.Name = "chkBx8850q2";
            this.chkBx8850q2.Size = new System.Drawing.Size(203, 30);
            this.chkBx8850q2.TabIndex = 15;
            this.chkBx8850q2.Text = "2. SNAP/TANF, voc rehab, ex-felon, \r\n    RRC/EZ, SSI, or vet 4 weeks";
            this.chkBx8850q2.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.chkBx8850q2.UseVisualStyleBackColor = true;
            // 
            // chkBx8850q1
            // 
            this.chkBx8850q1.AutoSize = true;
            this.chkBx8850q1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx8850q1.Location = new System.Drawing.Point(7, 20);
            this.chkBx8850q1.Name = "chkBx8850q1";
            this.chkBx8850q1.Size = new System.Drawing.Size(282, 17);
            this.chkBx8850q1.TabIndex = 14;
            this.chkBx8850q1.Text = "1. Conditional certificate from State Workforce Agency";
            this.chkBx8850q1.UseVisualStyleBackColor = true;
            // 
            // grp9061
            // 
            this.grp9061.Controls.Add(this.txtLTUStateOther);
            this.grp9061.Controls.Add(this.cmb22LtuState);
            this.grp9061.Controls.Add(this.txt9061EmployerSignatureDate);
            this.grp9061.Controls.Add(this.chkBx22LTU);
            this.grp9061.Controls.Add(this.chkBx21Vet4Weeks);
            this.grp9061.Controls.Add(this.chkBx20Vet6Months);
            this.grp9061.Controls.Add(this.chkBx19SSI);
            this.grp9061.Controls.Add(this.lbl18SummerYouthErrorMessage);
            this.grp9061.Controls.Add(this.chkBx18SummerYouth);
            this.grp9061.Controls.Add(this.chkBx18EmpowermentZone);
            this.grp9061.Controls.Add(this.chkBx18RuralRenewalCounty);
            this.grp9061.Controls.Add(this.panelFelonFedOrState);
            this.grp9061.Controls.Add(this.txtFelonReleaseDate);
            this.grp9061.Controls.Add(this.txtFelonConvictionDate);
            this.grp9061.Controls.Add(this.chkBxFelon);
            this.grp9061.Controls.Add(this.chkBxTanf4);
            this.grp9061.Controls.Add(this.chkBxTanf3);
            this.grp9061.Controls.Add(this.chkBxTanf2);
            this.grp9061.Controls.Add(this.chkBx16Tanf1);
            this.grp9061.Controls.Add(this.chkBx15VAReferral);
            this.grp9061.Controls.Add(this.chkBx15TicketToWork);
            this.grp9061.Controls.Add(this.chkBx15VocRehab);
            this.grp9061.Controls.Add(this.txtSnapRecipientName);
            this.grp9061.Controls.Add(this.chkBx14Snap2);
            this.grp9061.Controls.Add(this.chkBx14Snap1);
            this.grp9061.Controls.Add(this.chkBx13VetUnemployed6Months);
            this.grp9061.Controls.Add(this.chkBx13Vet1Year);
            this.grp9061.Controls.Add(this.chkBx13VetDisabled);
            this.grp9061.Controls.Add(this.txtTanfRecipientState);
            this.grp9061.Controls.Add(this.txtSnapRecipientState);
            this.grp9061.Controls.Add(this.txtVetSnapRecipientState);
            this.grp9061.Controls.Add(this.txtSnapRecipientCity);
            this.grp9061.Controls.Add(this.txtTanfRecipientCity);
            this.grp9061.Controls.Add(this.txtVetSnapRecipientCity);
            this.grp9061.Controls.Add(this.txtTanfRecipientName);
            this.grp9061.Controls.Add(this.txtVetSnapRecipientName);
            this.grp9061.Controls.Add(this.chkBx13VetSnap);
            this.grp9061.Controls.Add(this.chkBx13Veteran);
            this.grp9061.Controls.Add(this.cmboOnetCode);
            this.grp9061.Controls.Add(this.txtEmployerStreet2);
            this.grp9061.Controls.Add(this.txtWage);
            this.grp9061.Controls.Add(this.txtEmployerPhone);
            this.grp9061.Controls.Add(this.txtEmployerFEIN);
            this.grp9061.Controls.Add(this.txtEmployerStreet1);
            this.grp9061.Controls.Add(this.txtEmployerName);
            this.grp9061.Controls.Add(this.txtEmployerCity);
            this.grp9061.Controls.Add(this.txtEmployerZip);
            this.grp9061.Controls.Add(this.txtEmployerState);
            this.grp9061.Location = new System.Drawing.Point(333, 39);
            this.grp9061.Name = "grp9061";
            this.grp9061.Size = new System.Drawing.Size(678, 423);
            this.grp9061.TabIndex = 3;
            this.grp9061.TabStop = false;
            this.grp9061.Text = "Form 9061";
            // 
            // txtLTUStateOther
            // 
            this.txtLTUStateOther.Enabled = false;
            this.txtLTUStateOther.Location = new System.Drawing.Point(510, 364);
            this.txtLTUStateOther.Name = "txtLTUStateOther";
            this.txtLTUStateOther.Size = new System.Drawing.Size(121, 20);
            this.txtLTUStateOther.TabIndex = 0;
            this.txtLTUStateOther.TabStop = false;
            this.txtLTUStateOther.Text = "Enter state/territory";
            // 
            // cmb22LtuState
            // 
            this.cmb22LtuState.FormattingEnabled = true;
            this.cmb22LtuState.Items.AddRange(new object[] {
            "AK",
            "AL",
            "AR",
            "AZ",
            "CA",
            "CO",
            "CT",
            "DC",
            "DE",
            "FL",
            "GA",
            "HI",
            "IA",
            "ID",
            "IL",
            "IN",
            "KS",
            "KY",
            "LA",
            "MA",
            "MD",
            "ME",
            "MI",
            "MN",
            "MO",
            "MS",
            "MT",
            "NC",
            "ND",
            "NE",
            "NH",
            "NJ",
            "NM",
            "NV",
            "NY",
            "OH",
            "OK",
            "OR",
            "PA",
            "RI",
            "SC",
            "SD",
            "TN",
            "TX",
            "UT",
            "VA",
            "VT",
            "WA",
            "WI",
            "WV",
            "WY",
            "GU",
            "PR",
            "VI",
            "Other"});
            this.cmb22LtuState.Location = new System.Drawing.Point(510, 337);
            this.cmb22LtuState.Name = "cmb22LtuState";
            this.cmb22LtuState.Size = new System.Drawing.Size(100, 21);
            this.cmb22LtuState.TabIndex = 66;
            this.cmb22LtuState.Text = "LTU State";
            // 
            // txt9061EmployerSignatureDate
            // 
            this.txt9061EmployerSignatureDate.Location = new System.Drawing.Point(359, 390);
            this.txt9061EmployerSignatureDate.Name = "txt9061EmployerSignatureDate";
            this.txt9061EmployerSignatureDate.Size = new System.Drawing.Size(131, 20);
            this.txt9061EmployerSignatureDate.TabIndex = 68;
            this.txt9061EmployerSignatureDate.Text = "Employer Signature Date";
            // 
            // chkBx22LTU
            // 
            this.chkBx22LTU.AutoSize = true;
            this.chkBx22LTU.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx22LTU.Location = new System.Drawing.Point(340, 340);
            this.chkBx22LTU.Name = "chkBx22LTU";
            this.chkBx22LTU.Size = new System.Drawing.Size(164, 17);
            this.chkBx22LTU.TabIndex = 65;
            this.chkBx22LTU.Text = "22. Long-term Unemployment";
            this.chkBx22LTU.UseVisualStyleBackColor = true;
            // 
            // chkBx21Vet4Weeks
            // 
            this.chkBx21Vet4Weeks.AutoSize = true;
            this.chkBx21Vet4Weeks.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx21Vet4Weeks.Location = new System.Drawing.Point(340, 316);
            this.chkBx21Vet4Weeks.Name = "chkBx21Vet4Weeks";
            this.chkBx21Vet4Weeks.Size = new System.Drawing.Size(184, 17);
            this.chkBx21Vet4Weeks.TabIndex = 64;
            this.chkBx21Vet4Weeks.Text = "21. Veteran unemployed 4 weeks";
            this.chkBx21Vet4Weeks.UseVisualStyleBackColor = true;
            // 
            // chkBx20Vet6Months
            // 
            this.chkBx20Vet6Months.AutoSize = true;
            this.chkBx20Vet6Months.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx20Vet6Months.Location = new System.Drawing.Point(340, 292);
            this.chkBx20Vet6Months.Name = "chkBx20Vet6Months";
            this.chkBx20Vet6Months.Size = new System.Drawing.Size(187, 17);
            this.chkBx20Vet6Months.TabIndex = 63;
            this.chkBx20Vet6Months.Text = "20. Veteran unemployed 6 months";
            this.chkBx20Vet6Months.UseVisualStyleBackColor = true;
            // 
            // chkBx19SSI
            // 
            this.chkBx19SSI.AutoSize = true;
            this.chkBx19SSI.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx19SSI.Location = new System.Drawing.Point(340, 268);
            this.chkBx19SSI.Name = "chkBx19SSI";
            this.chkBx19SSI.Size = new System.Drawing.Size(109, 17);
            this.chkBx19SSI.TabIndex = 62;
            this.chkBx19SSI.Text = "19. SSI Recipient";
            this.chkBx19SSI.UseVisualStyleBackColor = true;
            // 
            // lbl18SummerYouthErrorMessage
            // 
            this.lbl18SummerYouthErrorMessage.AutoSize = true;
            this.lbl18SummerYouthErrorMessage.Location = new System.Drawing.Point(459, 245);
            this.lbl18SummerYouthErrorMessage.Name = "lbl18SummerYouthErrorMessage";
            this.lbl18SummerYouthErrorMessage.Size = new System.Drawing.Size(0, 13);
            this.lbl18SummerYouthErrorMessage.TabIndex = 0;
            // 
            // chkBx18SummerYouth
            // 
            this.chkBx18SummerYouth.AutoSize = true;
            this.chkBx18SummerYouth.Location = new System.Drawing.Point(340, 244);
            this.chkBx18SummerYouth.Name = "chkBx18SummerYouth";
            this.chkBx18SummerYouth.Size = new System.Drawing.Size(116, 17);
            this.chkBx18SummerYouth.TabIndex = 61;
            this.chkBx18SummerYouth.Text = "   b. Summer Youth";
            this.chkBx18SummerYouth.UseVisualStyleBackColor = true;
            // 
            // chkBx18EmpowermentZone
            // 
            this.chkBx18EmpowermentZone.AutoSize = true;
            this.chkBx18EmpowermentZone.Location = new System.Drawing.Point(340, 220);
            this.chkBx18EmpowermentZone.Name = "chkBx18EmpowermentZone";
            this.chkBx18EmpowermentZone.Size = new System.Drawing.Size(142, 17);
            this.chkBx18EmpowermentZone.TabIndex = 60;
            this.chkBx18EmpowermentZone.Text = "   a. Empowerment Zone";
            this.chkBx18EmpowermentZone.UseVisualStyleBackColor = true;
            // 
            // chkBx18RuralRenewalCounty
            // 
            this.chkBx18RuralRenewalCounty.AutoSize = true;
            this.chkBx18RuralRenewalCounty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx18RuralRenewalCounty.Location = new System.Drawing.Point(340, 196);
            this.chkBx18RuralRenewalCounty.Name = "chkBx18RuralRenewalCounty";
            this.chkBx18RuralRenewalCounty.Size = new System.Drawing.Size(150, 17);
            this.chkBx18RuralRenewalCounty.TabIndex = 59;
            this.chkBx18RuralRenewalCounty.Text = "18. Rural Renewal County";
            this.chkBx18RuralRenewalCounty.UseVisualStyleBackColor = true;
            // 
            // panelFelonFedOrState
            // 
            this.panelFelonFedOrState.Controls.Add(this.radFelonFederal);
            this.panelFelonFedOrState.Controls.Add(this.radFelonState);
            this.panelFelonFedOrState.Location = new System.Drawing.Point(595, 157);
            this.panelFelonFedOrState.Name = "panelFelonFedOrState";
            this.panelFelonFedOrState.Size = new System.Drawing.Size(75, 46);
            this.panelFelonFedOrState.TabIndex = 57;
            // 
            // radFelonFederal
            // 
            this.radFelonFederal.AutoCheck = false;
            this.radFelonFederal.AutoSize = true;
            this.radFelonFederal.Location = new System.Drawing.Point(4, 26);
            this.radFelonFederal.Name = "radFelonFederal";
            this.radFelonFederal.Size = new System.Drawing.Size(60, 17);
            this.radFelonFederal.TabIndex = 57;
            this.radFelonFederal.TabStop = true;
            this.radFelonFederal.Text = "Federal";
            this.radFelonFederal.UseVisualStyleBackColor = true;
            // 
            // radFelonState
            // 
            this.radFelonState.AutoSize = true;
            this.radFelonState.Location = new System.Drawing.Point(4, 5);
            this.radFelonState.Name = "radFelonState";
            this.radFelonState.Size = new System.Drawing.Size(50, 17);
            this.radFelonState.TabIndex = 57;
            this.radFelonState.TabStop = true;
            this.radFelonState.Text = "State";
            this.radFelonState.UseVisualStyleBackColor = true;
            // 
            // txtFelonReleaseDate
            // 
            this.txtFelonReleaseDate.Location = new System.Drawing.Point(489, 169);
            this.txtFelonReleaseDate.Name = "txtFelonReleaseDate";
            this.txtFelonReleaseDate.Size = new System.Drawing.Size(100, 20);
            this.txtFelonReleaseDate.TabIndex = 56;
            this.txtFelonReleaseDate.Text = "Release Date";
            // 
            // txtFelonConvictionDate
            // 
            this.txtFelonConvictionDate.Location = new System.Drawing.Point(382, 169);
            this.txtFelonConvictionDate.Name = "txtFelonConvictionDate";
            this.txtFelonConvictionDate.Size = new System.Drawing.Size(100, 20);
            this.txtFelonConvictionDate.TabIndex = 55;
            this.txtFelonConvictionDate.Text = "Conviction Date";
            // 
            // chkBxFelon
            // 
            this.chkBxFelon.AutoSize = true;
            this.chkBxFelon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxFelon.Location = new System.Drawing.Point(340, 145);
            this.chkBxFelon.Name = "chkBxFelon";
            this.chkBxFelon.Size = new System.Drawing.Size(82, 17);
            this.chkBxFelon.TabIndex = 54;
            this.chkBxFelon.Text = "17. Ex-felon";
            this.chkBxFelon.UseVisualStyleBackColor = true;
            // 
            // chkBxTanf4
            // 
            this.chkBxTanf4.AutoSize = true;
            this.chkBxTanf4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxTanf4.Location = new System.Drawing.Point(340, 94);
            this.chkBxTanf4.Name = "chkBxTanf4";
            this.chkBxTanf4.Size = new System.Drawing.Size(190, 17);
            this.chkBxTanf4.TabIndex = 50;
            this.chkBxTanf4.Text = "   c. Benefits received for 9 months";
            this.chkBxTanf4.UseVisualStyleBackColor = true;
            // 
            // chkBxTanf3
            // 
            this.chkBxTanf3.AutoSize = true;
            this.chkBxTanf3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxTanf3.Location = new System.Drawing.Point(340, 70);
            this.chkBxTanf3.Name = "chkBxTanf3";
            this.chkBxTanf3.Size = new System.Drawing.Size(194, 17);
            this.chkBxTanf3.TabIndex = 49;
            this.chkBxTanf3.Text = "   b. Eligibility stopped within 2 years";
            this.chkBxTanf3.UseVisualStyleBackColor = true;
            // 
            // chkBxTanf2
            // 
            this.chkBxTanf2.AutoSize = true;
            this.chkBxTanf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBxTanf2.Location = new System.Drawing.Point(340, 46);
            this.chkBxTanf2.Name = "chkBxTanf2";
            this.chkBxTanf2.Size = new System.Drawing.Size(185, 17);
            this.chkBxTanf2.TabIndex = 48;
            this.chkBxTanf2.Text = "   a. Benefits ended within 2 years";
            this.chkBxTanf2.UseVisualStyleBackColor = true;
            // 
            // chkBx16Tanf1
            // 
            this.chkBx16Tanf1.AutoSize = true;
            this.chkBx16Tanf1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx16Tanf1.Location = new System.Drawing.Point(340, 22);
            this.chkBx16Tanf1.Name = "chkBx16Tanf1";
            this.chkBx16Tanf1.Size = new System.Drawing.Size(120, 17);
            this.chkBx16Tanf1.TabIndex = 47;
            this.chkBx16Tanf1.Text = "16. TANF Recipient";
            this.chkBx16Tanf1.UseVisualStyleBackColor = true;
            // 
            // chkBx15VAReferral
            // 
            this.chkBx15VAReferral.AutoSize = true;
            this.chkBx15VAReferral.Location = new System.Drawing.Point(6, 392);
            this.chkBx15VAReferral.Name = "chkBx15VAReferral";
            this.chkBx15VAReferral.Size = new System.Drawing.Size(151, 17);
            this.chkBx15VAReferral.TabIndex = 46;
            this.chkBx15VAReferral.Text = "   c. Veteran Affairs referral";
            this.chkBx15VAReferral.UseVisualStyleBackColor = true;
            // 
            // chkBx15TicketToWork
            // 
            this.chkBx15TicketToWork.AutoSize = true;
            this.chkBx15TicketToWork.Location = new System.Drawing.Point(6, 369);
            this.chkBx15TicketToWork.Name = "chkBx15TicketToWork";
            this.chkBx15TicketToWork.Size = new System.Drawing.Size(118, 17);
            this.chkBx15TicketToWork.TabIndex = 45;
            this.chkBx15TicketToWork.Text = "   b. Ticket to Work";
            this.chkBx15TicketToWork.UseVisualStyleBackColor = true;
            // 
            // chkBx15VocRehab
            // 
            this.chkBx15VocRehab.AutoSize = true;
            this.chkBx15VocRehab.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx15VocRehab.Location = new System.Drawing.Point(7, 346);
            this.chkBx15VocRehab.Name = "chkBx15VocRehab";
            this.chkBx15VocRehab.Size = new System.Drawing.Size(196, 17);
            this.chkBx15VocRehab.TabIndex = 44;
            this.chkBx15VocRehab.Text = "15. State Vocational Rehab Agency";
            this.chkBx15VocRehab.UseVisualStyleBackColor = true;
            // 
            // txtSnapRecipientName
            // 
            this.txtSnapRecipientName.Location = new System.Drawing.Point(49, 320);
            this.txtSnapRecipientName.Name = "txtSnapRecipientName";
            this.txtSnapRecipientName.Size = new System.Drawing.Size(122, 20);
            this.txtSnapRecipientName.TabIndex = 41;
            this.txtSnapRecipientName.Text = "Primary Recipient";
            this.txtSnapRecipientName.Enter += new System.EventHandler(this.txtSnapRecipientName_Enter);
            // 
            // chkBx14Snap2
            // 
            this.chkBx14Snap2.AutoSize = true;
            this.chkBx14Snap2.Location = new System.Drawing.Point(7, 297);
            this.chkBx14Snap2.Name = "chkBx14Snap2";
            this.chkBx14Snap2.Size = new System.Drawing.Size(171, 17);
            this.chkBx14Snap2.TabIndex = 40;
            this.chkBx14Snap2.Text = "   a. No longer receiving SNAP";
            this.chkBx14Snap2.UseVisualStyleBackColor = true;
            // 
            // chkBx14Snap1
            // 
            this.chkBx14Snap1.AutoSize = true;
            this.chkBx14Snap1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx14Snap1.Location = new System.Drawing.Point(7, 274);
            this.chkBx14Snap1.Name = "chkBx14Snap1";
            this.chkBx14Snap1.Size = new System.Drawing.Size(121, 17);
            this.chkBx14Snap1.TabIndex = 39;
            this.chkBx14Snap1.Text = "14. SNAP Recipient";
            this.chkBx14Snap1.UseVisualStyleBackColor = true;
            // 
            // chkBx13VetUnemployed6Months
            // 
            this.chkBx13VetUnemployed6Months.AutoSize = true;
            this.chkBx13VetUnemployed6Months.Location = new System.Drawing.Point(7, 251);
            this.chkBx13VetUnemployed6Months.Name = "chkBx13VetUnemployed6Months";
            this.chkBx13VetUnemployed6Months.Size = new System.Drawing.Size(190, 17);
            this.chkBx13VetUnemployed6Months.TabIndex = 38;
            this.chkBx13VetUnemployed6Months.Text = "   d. Veteran unemployed 6 months";
            this.chkBx13VetUnemployed6Months.UseVisualStyleBackColor = true;
            // 
            // chkBx13Vet1Year
            // 
            this.chkBx13Vet1Year.AutoSize = true;
            this.chkBx13Vet1Year.Location = new System.Drawing.Point(7, 228);
            this.chkBx13Vet1Year.Name = "chkBx13Vet1Year";
            this.chkBx13Vet1Year.Size = new System.Drawing.Size(232, 17);
            this.chkBx13Vet1Year.TabIndex = 37;
            this.chkBx13Vet1Year.Text = "   c. Veteran left service within the past year";
            this.chkBx13Vet1Year.UseVisualStyleBackColor = true;
            // 
            // chkBx13VetDisabled
            // 
            this.chkBx13VetDisabled.AutoSize = true;
            this.chkBx13VetDisabled.Location = new System.Drawing.Point(7, 205);
            this.chkBx13VetDisabled.Name = "chkBx13VetDisabled";
            this.chkBx13VetDisabled.Size = new System.Drawing.Size(179, 17);
            this.chkBx13VetDisabled.TabIndex = 36;
            this.chkBx13VetDisabled.Text = "   b. Service-connected disability";
            this.chkBx13VetDisabled.UseVisualStyleBackColor = true;
            // 
            // txtSnapRecipientState
            // 
            this.txtSnapRecipientState.Location = new System.Drawing.Point(285, 320);
            this.txtSnapRecipientState.Name = "txtSnapRecipientState";
            this.txtSnapRecipientState.Size = new System.Drawing.Size(33, 20);
            this.txtSnapRecipientState.TabIndex = 43;
            this.txtSnapRecipientState.Text = "State";
            this.txtSnapRecipientState.Enter += new System.EventHandler(this.txtSnapRecipientState_Enter);
            // 
            // txtVetSnapRecipientState
            // 
            this.txtVetSnapRecipientState.Location = new System.Drawing.Point(284, 179);
            this.txtVetSnapRecipientState.Name = "txtVetSnapRecipientState";
            this.txtVetSnapRecipientState.Size = new System.Drawing.Size(33, 20);
            this.txtVetSnapRecipientState.TabIndex = 35;
            this.txtVetSnapRecipientState.Text = "State";
            this.txtVetSnapRecipientState.Enter += new System.EventHandler(this.txtVetSnapRecipientState_Enter);
            // 
            // txtSnapRecipientCity
            // 
            this.txtSnapRecipientCity.Location = new System.Drawing.Point(177, 320);
            this.txtSnapRecipientCity.Name = "txtSnapRecipientCity";
            this.txtSnapRecipientCity.Size = new System.Drawing.Size(100, 20);
            this.txtSnapRecipientCity.TabIndex = 42;
            this.txtSnapRecipientCity.Text = "City";
            this.txtSnapRecipientCity.Enter += new System.EventHandler(this.txtSnapRecipientCity_Enter);
            // 
            // txtTanfRecipientCity
            // 
            this.txtTanfRecipientCity.Location = new System.Drawing.Point(510, 117);
            this.txtTanfRecipientCity.Name = "txtTanfRecipientCity";
            this.txtTanfRecipientCity.Size = new System.Drawing.Size(100, 20);
            this.txtTanfRecipientCity.TabIndex = 52;
            this.txtTanfRecipientCity.Text = "City";
            this.txtTanfRecipientCity.Enter += new System.EventHandler(this.txtTanfRecipientCity_Enter);
            // 
            // txtVetSnapRecipientCity
            // 
            this.txtVetSnapRecipientCity.Location = new System.Drawing.Point(177, 179);
            this.txtVetSnapRecipientCity.Name = "txtVetSnapRecipientCity";
            this.txtVetSnapRecipientCity.Size = new System.Drawing.Size(100, 20);
            this.txtVetSnapRecipientCity.TabIndex = 34;
            this.txtVetSnapRecipientCity.Text = "City";
            this.txtVetSnapRecipientCity.Enter += new System.EventHandler(this.txtVetSnapRecipientCity_Enter);
            // 
            // txtTanfRecipientName
            // 
            this.txtTanfRecipientName.Location = new System.Drawing.Point(382, 118);
            this.txtTanfRecipientName.Name = "txtTanfRecipientName";
            this.txtTanfRecipientName.Size = new System.Drawing.Size(122, 20);
            this.txtTanfRecipientName.TabIndex = 51;
            this.txtTanfRecipientName.Text = "Primary Recipient";
            this.txtTanfRecipientName.Enter += new System.EventHandler(this.txtTanfRecipientName_Enter);
            // 
            // txtVetSnapRecipientName
            // 
            this.txtVetSnapRecipientName.Location = new System.Drawing.Point(49, 179);
            this.txtVetSnapRecipientName.Name = "txtVetSnapRecipientName";
            this.txtVetSnapRecipientName.Size = new System.Drawing.Size(122, 20);
            this.txtVetSnapRecipientName.TabIndex = 33;
            this.txtVetSnapRecipientName.Text = "Primary Recipient";
            this.txtVetSnapRecipientName.Enter += new System.EventHandler(this.txtVetSnapRecipientName_Enter);
            // 
            // chkBx13VetSnap
            // 
            this.chkBx13VetSnap.AutoSize = true;
            this.chkBx13VetSnap.Location = new System.Drawing.Point(7, 156);
            this.chkBx13VetSnap.Name = "chkBx13VetSnap";
            this.chkBx13VetSnap.Size = new System.Drawing.Size(159, 17);
            this.chkBx13VetSnap.TabIndex = 32;
            this.chkBx13VetSnap.Text = "   a. Veteran SNAP recipient";
            this.chkBx13VetSnap.UseVisualStyleBackColor = true;
            // 
            // chkBx13Veteran
            // 
            this.chkBx13Veteran.AutoSize = true;
            this.chkBx13Veteran.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkBx13Veteran.Location = new System.Drawing.Point(7, 133);
            this.chkBx13Veteran.Name = "chkBx13Veteran";
            this.chkBx13Veteran.Size = new System.Drawing.Size(179, 17);
            this.chkBx13Veteran.TabIndex = 31;
            this.chkBx13Veteran.Text = "13. Veteran of the Armed Forces";
            this.chkBx13Veteran.UseVisualStyleBackColor = true;
            // 
            // cmboOnetCode
            // 
            this.cmboOnetCode.FormattingEnabled = true;
            this.cmboOnetCode.Items.AddRange(new object[] {
            "33 Protective Service Occupations",
            "35 Food Preparation & Serving Related",
            "37 Bldg. & Grounds Cleaning & Maintenance",
            "43 Office & Administrative Support",
            "51 Production Occupations",
            "",
            "-- ",
            "11 Management",
            "13 Business & Financial",
            "15 Computer & Mathematical Occupations",
            "17 Architecture & Engineering",
            "19 Life, Physical & Social Sciences",
            "21 Community & Social Services",
            "23 Legal Occupations",
            "25 Education, Training, & Library",
            "27 Arts Design Entertainment Sports & Media",
            "29 Healthcare Practitioner & Technical",
            "31 Healthcare Support Occupations",
            "33 Protective Service Occupations",
            "35 Food Preparation & Serving Related",
            "37 Bldg. & Grounds Cleaning & Maintenance",
            "39 Personal Care & Service",
            "41 Sales & Related Occupations",
            "43 Office & Administrative Support",
            "45 Farming, Fishing, & Forestry",
            "47 Construction & Extraction",
            "49 Installation, Maintenance & Repair",
            "51 Production Occupations",
            "53 Transportation & Material Moving",
            "55 Military Specific Occupations"});
            this.cmboOnetCode.Location = new System.Drawing.Point(191, 98);
            this.cmboOnetCode.Name = "cmboOnetCode";
            this.cmboOnetCode.Size = new System.Drawing.Size(119, 21);
            this.cmboOnetCode.TabIndex = 30;
            this.cmboOnetCode.Text = "Choose ONET Code";
            this.cmboOnetCode.Enter += new System.EventHandler(this.cmboOnetCode_Enter);
            // 
            // txtEmployerStreet2
            // 
            this.txtEmployerStreet2.Location = new System.Drawing.Point(6, 72);
            this.txtEmployerStreet2.Name = "txtEmployerStreet2";
            this.txtEmployerStreet2.Size = new System.Drawing.Size(178, 20);
            this.txtEmployerStreet2.TabIndex = 23;
            this.txtEmployerStreet2.Text = "Employer Street Address 2";
            this.txtEmployerStreet2.Enter += new System.EventHandler(this.txtEmployerStreet2_Enter);
            // 
            // txtWage
            // 
            this.txtWage.Location = new System.Drawing.Point(190, 72);
            this.txtWage.Name = "txtWage";
            this.txtWage.Size = new System.Drawing.Size(119, 20);
            this.txtWage.TabIndex = 29;
            this.txtWage.Text = "Starting Wage";
            this.txtWage.Enter += new System.EventHandler(this.txtWage_Enter);
            // 
            // txtEmployerPhone
            // 
            this.txtEmployerPhone.Location = new System.Drawing.Point(190, 46);
            this.txtEmployerPhone.Name = "txtEmployerPhone";
            this.txtEmployerPhone.Size = new System.Drawing.Size(119, 20);
            this.txtEmployerPhone.TabIndex = 28;
            this.txtEmployerPhone.Text = "Employer Phone";
            this.txtEmployerPhone.Enter += new System.EventHandler(this.txtEmployerPhone_Enter);
            // 
            // txtEmployerFEIN
            // 
            this.txtEmployerFEIN.Location = new System.Drawing.Point(190, 20);
            this.txtEmployerFEIN.Name = "txtEmployerFEIN";
            this.txtEmployerFEIN.Size = new System.Drawing.Size(119, 20);
            this.txtEmployerFEIN.TabIndex = 27;
            this.txtEmployerFEIN.Text = "Employer FEIN";
            this.txtEmployerFEIN.Enter += new System.EventHandler(this.txtEmployerFEIN_Enter);
            // 
            // txtEmployerStreet1
            // 
            this.txtEmployerStreet1.Location = new System.Drawing.Point(6, 46);
            this.txtEmployerStreet1.Name = "txtEmployerStreet1";
            this.txtEmployerStreet1.Size = new System.Drawing.Size(178, 20);
            this.txtEmployerStreet1.TabIndex = 22;
            this.txtEmployerStreet1.Text = "Employer Street Address 1";
            this.txtEmployerStreet1.Enter += new System.EventHandler(this.txtEmployerStreet1_Enter);
            // 
            // txtEmployerName
            // 
            this.txtEmployerName.Location = new System.Drawing.Point(6, 20);
            this.txtEmployerName.Name = "txtEmployerName";
            this.txtEmployerName.Size = new System.Drawing.Size(178, 20);
            this.txtEmployerName.TabIndex = 21;
            this.txtEmployerName.Text = "Employer Name";
            this.txtEmployerName.Enter += new System.EventHandler(this.txtEmployerName_Enter);
            // 
            // txtEmployerCity
            // 
            this.txtEmployerCity.Location = new System.Drawing.Point(6, 98);
            this.txtEmployerCity.Name = "txtEmployerCity";
            this.txtEmployerCity.Size = new System.Drawing.Size(76, 20);
            this.txtEmployerCity.TabIndex = 24;
            this.txtEmployerCity.Text = "Employer City";
            this.txtEmployerCity.Enter += new System.EventHandler(this.txtEmployerCity_Enter);
            // 
            // txtEmployerZip
            // 
            this.txtEmployerZip.Location = new System.Drawing.Point(127, 98);
            this.txtEmployerZip.Name = "txtEmployerZip";
            this.txtEmployerZip.Size = new System.Drawing.Size(57, 20);
            this.txtEmployerZip.TabIndex = 26;
            this.txtEmployerZip.Text = "Zip Code";
            this.txtEmployerZip.Enter += new System.EventHandler(this.txtEmployerZip_Enter);
            // 
            // txtEmployerState
            // 
            this.txtEmployerState.Location = new System.Drawing.Point(88, 98);
            this.txtEmployerState.Name = "txtEmployerState";
            this.txtEmployerState.Size = new System.Drawing.Size(33, 20);
            this.txtEmployerState.TabIndex = 25;
            this.txtEmployerState.Text = "State";
            this.txtEmployerState.Enter += new System.EventHandler(this.txtEmployerState_Enter);
            // 
            // btnAppUpdateSubmit
            // 
            this.btnAppUpdateSubmit.Location = new System.Drawing.Point(721, 481);
            this.btnAppUpdateSubmit.Name = "btnAppUpdateSubmit";
            this.btnAppUpdateSubmit.Size = new System.Drawing.Size(181, 23);
            this.btnAppUpdateSubmit.TabIndex = 4;
            this.btnAppUpdateSubmit.Text = "Submit Updated Application";
            this.btnAppUpdateSubmit.UseVisualStyleBackColor = true;
            this.btnAppUpdateSubmit.Click += new System.EventHandler(this.btnAppUpdateSubmit_Click);
            // 
            // btnAppUpdateReset
            // 
            this.btnAppUpdateReset.Location = new System.Drawing.Point(909, 480);
            this.btnAppUpdateReset.Name = "btnAppUpdateReset";
            this.btnAppUpdateReset.Size = new System.Drawing.Size(102, 23);
            this.btnAppUpdateReset.TabIndex = 5;
            this.btnAppUpdateReset.Text = "Reset All Fields";
            this.btnAppUpdateReset.UseVisualStyleBackColor = true;
            this.btnAppUpdateReset.Click += new System.EventHandler(this.btnAppUpdateReset_Click);
            // 
            // btnAppUpdateSkip
            // 
            this.btnAppUpdateSkip.Location = new System.Drawing.Point(13, 480);
            this.btnAppUpdateSkip.Name = "btnAppUpdateSkip";
            this.btnAppUpdateSkip.Size = new System.Drawing.Size(136, 23);
            this.btnAppUpdateSkip.TabIndex = 0;
            this.btnAppUpdateSkip.TabStop = false;
            this.btnAppUpdateSkip.Text = "Skip This Application";
            this.btnAppUpdateSkip.UseVisualStyleBackColor = true;
            this.btnAppUpdateSkip.Click += new System.EventHandler(this.btnAppUpdateSkip_Click);
            // 
            // lblAppErrorMessage
            // 
            this.lblAppErrorMessage.AutoSize = true;
            this.lblAppErrorMessage.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAppErrorMessage.Location = new System.Drawing.Point(163, 472);
            this.lblAppErrorMessage.Name = "lblAppErrorMessage";
            this.lblAppErrorMessage.Size = new System.Drawing.Size(142, 13);
            this.lblAppErrorMessage.TabIndex = 6;
            this.lblAppErrorMessage.Text = "Issue(s) with this Application:";
            // 
            // txtAppErrorMessageText
            // 
            this.txtAppErrorMessageText.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.txtAppErrorMessageText.Location = new System.Drawing.Point(312, 469);
            this.txtAppErrorMessageText.Multiline = true;
            this.txtAppErrorMessageText.Name = "txtAppErrorMessageText";
            this.txtAppErrorMessageText.ReadOnly = true;
            this.txtAppErrorMessageText.Size = new System.Drawing.Size(376, 35);
            this.txtAppErrorMessageText.TabIndex = 0;
            this.txtAppErrorMessageText.TabStop = false;
            this.txtAppErrorMessageText.Text = "Error message(s) would show here.";
            // 
            // txtTanfRecipientState
            // 
            this.txtTanfRecipientState.Location = new System.Drawing.Point(616, 117);
            this.txtTanfRecipientState.Name = "txtTanfRecipientState";
            this.txtTanfRecipientState.Size = new System.Drawing.Size(33, 20);
            this.txtTanfRecipientState.TabIndex = 43;
            this.txtTanfRecipientState.Text = "State";
            this.txtTanfRecipientState.Enter += new System.EventHandler(this.txtTanfRecipientState_Enter);
            // 
            // FormAppUpdate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1019, 515);
            this.Controls.Add(this.txtAppErrorMessageText);
            this.Controls.Add(this.lblAppErrorMessage);
            this.Controls.Add(this.btnAppUpdateSkip);
            this.Controls.Add(this.btnAppUpdateReset);
            this.Controls.Add(this.btnAppUpdateSubmit);
            this.Controls.Add(this.grp9061);
            this.Controls.Add(this.grp8850Questionnaire);
            this.Controls.Add(this.grpEmployeeInformation);
            this.Controls.Add(this.label1);
            this.Name = "FormAppUpdate";
            this.Text = "WOTC Application Update";
            this.grpEmployeeInformation.ResumeLayout(false);
            this.grpEmployeeInformation.PerformLayout();
            this.grp8850Questionnaire.ResumeLayout(false);
            this.grp8850Questionnaire.PerformLayout();
            this.grp9061.ResumeLayout(false);
            this.grp9061.PerformLayout();
            this.panelFelonFedOrState.ResumeLayout(false);
            this.panelFelonFedOrState.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grpEmployeeInformation;
        private System.Windows.Forms.TextBox txtEmployeeFirstName;
        private System.ServiceProcess.ServiceController serviceController1;
        private System.Windows.Forms.TextBox txtEmployeeEmailAddress;
        private System.Windows.Forms.TextBox txtEmployeePhoneNumber;
        private System.Windows.Forms.TextBox txtEmployeeDOB;
        private System.Windows.Forms.TextBox txtEmployeeStreet1;
        private System.Windows.Forms.TextBox txtEmployeeState;
        private System.Windows.Forms.TextBox txtEmployeeCity;
        private System.Windows.Forms.TextBox txtEmployeeStreet2;
        private System.Windows.Forms.TextBox txtEmployeeSSN;
        private System.Windows.Forms.TextBox txtEmployeeLastName;
        private System.Windows.Forms.TextBox txtEmployeeMiddleName;
        private System.Windows.Forms.TextBox txtEmployeeZip;
        private System.Windows.Forms.TextBox txtEmployeeCounty;
        private System.Windows.Forms.GroupBox grp8850Questionnaire;
        private System.Windows.Forms.TextBox txtEmployeeSignatureDate;
        private System.Windows.Forms.CheckBox chkBx8850q7;
        private System.Windows.Forms.CheckBox chkBx8850q6;
        private System.Windows.Forms.CheckBox chkBx8850q5;
        private System.Windows.Forms.CheckBox chkBx8850q4;
        private System.Windows.Forms.CheckBox chkBx8850q3;
        private System.Windows.Forms.CheckBox chkBx8850q2;
        private System.Windows.Forms.CheckBox chkBx8850q1;
        private System.Windows.Forms.GroupBox grp9061;
        private System.Windows.Forms.TextBox txtEmployerName;
        private System.Windows.Forms.TextBox txtEmployerStreet2;
        private System.Windows.Forms.TextBox txtEmployerStreet1;
        private System.Windows.Forms.TextBox txtEmployerCity;
        private System.Windows.Forms.TextBox txtEmployerZip;
        private System.Windows.Forms.TextBox txtEmployerState;
        private System.Windows.Forms.TextBox txtEmployerPhone;
        private System.Windows.Forms.TextBox txtEmployerFEIN;
        private System.Windows.Forms.TextBox txtWage;
        private System.Windows.Forms.ComboBox cmboOnetCode;
        private System.Windows.Forms.CheckBox chkBx13VetSnap;
        private System.Windows.Forms.CheckBox chkBx13Veteran;
        private System.Windows.Forms.TextBox txtVetSnapRecipientCity;
        private System.Windows.Forms.TextBox txtVetSnapRecipientState;
        private System.Windows.Forms.CheckBox chkBx13VetDisabled;
        private System.Windows.Forms.CheckBox chkBx13VetUnemployed6Months;
        private System.Windows.Forms.CheckBox chkBx13Vet1Year;
        private System.Windows.Forms.CheckBox chkBx14Snap1;
        private System.Windows.Forms.TextBox txtSnapRecipientName;
        private System.Windows.Forms.CheckBox chkBx14Snap2;
        private System.Windows.Forms.TextBox txtVetSnapRecipientName;
        private System.Windows.Forms.CheckBox chkBx15VAReferral;
        private System.Windows.Forms.CheckBox chkBx15TicketToWork;
        private System.Windows.Forms.CheckBox chkBx15VocRehab;
        private System.Windows.Forms.TextBox txtSnapRecipientState;
        private System.Windows.Forms.TextBox txtSnapRecipientCity;
        private System.Windows.Forms.TextBox txtFelonReleaseDate;
        private System.Windows.Forms.TextBox txtFelonConvictionDate;
        private System.Windows.Forms.CheckBox chkBxFelon;
        private System.Windows.Forms.CheckBox chkBxTanf4;
        private System.Windows.Forms.CheckBox chkBxTanf3;
        private System.Windows.Forms.CheckBox chkBxTanf2;
        private System.Windows.Forms.CheckBox chkBx16Tanf1;
        private System.Windows.Forms.TextBox txtTanfRecipientCity;
        private System.Windows.Forms.TextBox txtTanfRecipientName;
        private System.Windows.Forms.RadioButton radFelonState;
        private System.Windows.Forms.RadioButton radFelonFederal;
        private System.Windows.Forms.Panel panelFelonFedOrState;
        private System.Windows.Forms.CheckBox chkBx18EmpowermentZone;
        private System.Windows.Forms.CheckBox chkBx18RuralRenewalCounty;
        private System.Windows.Forms.Label lbl18SummerYouthErrorMessage;
        private System.Windows.Forms.CheckBox chkBx18SummerYouth;
        private System.Windows.Forms.CheckBox chkBx21Vet4Weeks;
        private System.Windows.Forms.CheckBox chkBx20Vet6Months;
        private System.Windows.Forms.CheckBox chkBx19SSI;
        private System.Windows.Forms.CheckBox chkBx22LTU;
        private System.Windows.Forms.TextBox txt9061EmployerSignatureDate;
        private System.Windows.Forms.ComboBox cmb22LtuState;
        private System.Windows.Forms.TextBox txtLTUStateOther;
        private System.Windows.Forms.Button btnAppUpdateSubmit;
        private System.Windows.Forms.Button btnAppUpdateReset;
        private System.Windows.Forms.Button btnAppUpdateSkip;
        private System.Windows.Forms.Label lblAppErrorMessage;
        private System.Windows.Forms.TextBox txtAppErrorMessageText;
        private System.Windows.Forms.TextBox txtTanfRecipientState;
    }
}