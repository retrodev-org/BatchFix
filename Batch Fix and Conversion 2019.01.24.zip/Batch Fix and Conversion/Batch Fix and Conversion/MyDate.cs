﻿using System;

namespace Batch_Fix_and_Conversion
{
    class MyDate
    {
        // Date formats
        public const int DATE_MMDDYY = 1;
        public const int DATE_MMDDYY_HYPHEN = 2;
        public const int DATE_MMDDYY_SLASH = 3;
        public const int DATE_MMDDYYYY = 4;
        public const int DATE_MMDDYYYY_HYPHEN = 5;
        public const int DATE_MMDDYYYY_SLASH = 6;
        public const int DATE_YYYYMMDD = 7;
        public const int DATE_YYYYMMDD_HYPHEN = 8;
        public const int DATE_YYYYMMDD_SLASH = 9;

        private string date;
        private DateTime dateTime;
        private String day;
        private String month;
        private String year;
        private String divider;

        // Getters and setters
        public DateTime DateTime { get => dateTime; set => dateTime = value; }
        public string Day { get => day; set => day = value; }
        public string Month { get => month; set => month = value; }
        public string Year { get => year; set => year = value; }
        public string Divider { get => divider; set => divider = value; }
        public string Date { get => date; set => date = value; }

        String FormatDate(int oldFormat, int newFormat)
        {
            if (oldFormat == DATE_MMDDYY)
            {
                if (newFormat == DATE_MMDDYY_HYPHEN)
                    return date.Substring(0, 2) + "-" + date.Substring(2, 2) + "-" + date.Substring(4);
                if (newFormat == DATE_MMDDYYYY)
                    return date;
            }

            return date;
        }

        // return default 8 digit date mmddyyyy
        public String toString() { return Day + Month + Year; }
        public String toStringMMDDYYYY() { return Day + Month + Year; }

        // return 10 char date with forward dash or hyphen between digits
        public String toStringHyphenMMDDYYYY()
        {
            Divider = "-";
            return Day + Divider + Month + Divider + Year;
        }

        // return 10 char date with forward slash between digits
        public String toStringSlashMMDDYYYY()
        {
            Divider = "/";
            return Day + Divider + Month + Divider + Year;
        }

        //todo toString for different date types needed by states YYYYMMDD, DDMMYYYY, etc
    }
}
