﻿using System;

namespace Batch_Fix_and_Conversion
{
    /// <summary>
	/// Class:	MyEmployer
	/// Use:	Read and store employer information. (EIN, Address, Phone, etc.)
	/// </summary>
	public class MyEmployer
    {
        // Variables
        private string fein;
        private string name;
        private string street1;
        private string street2;
        private string city;
        private string state;
        private string zipCode;
        private string phone;
        private string phoneExtension;

        private bool isReady;

        public string Fein { get => fein; set => fein = value; }
        public string Name { get => name; set => name = value; }
        public string Street1 { get => street1; set => street1 = value; }
        public string Street2 { get => street2; set => street2 = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public string ZipCode { get => zipCode; set => zipCode = value; }
        public string Phone { get => phone; set => phone = value; }
        public bool IsReady { get => isReady; set => isReady = value; }
        public string PhoneExtension { get => phoneExtension; set => phoneExtension = value; }


        // TODO: create getters and setters (encapsulate, use field?)

        public MyEmployer()
        {
            // TODO: create Employer public constructor	
        }
    }
}
