﻿using System;
using System.Collections.Generic;

namespace Batch_Fix_and_Conversion
{
    public class MyState
    {
        // TODO Continue adding variables that exist in other states, then continue AL configuration


        // For each state, initialize with the following:
        // Delimiter = MyConst.DELMT_SPACE;
        // TrueAnswer = MyConst.TRUE_Y;
        // FalseAnswer = MyConst.FALSE_N;
        // MinimumWage = MyConst.WAGE_DEFAULT;
        // ValidCities = list of cities, if necessary (see IN)

        // Basic Values
        int state;
        string delimiter;
        string trueAnswer;
        string falseAnswer;
        string stateName;
        double minimumWage;
        private int stateIdentifier;    // Holds the constant int value for given state (ex. MyConst.STATE_AL)
        List<string> validCities;
        List<string> varList;
        List<int> varLength;

        // Rural Renewal Counties and Empowerment Zones
        private List<string> empowermentZoneList;
        private List<string> ruralRenewalCountyNames;
        private List<string> ruralRenewalCountyZipCodes;

        // Variables
        private MyDate convictionDate;
        private MyDate dateOfBirth;
        private MyDate employeeSignDate8850;
        private MyDate employeeSignDate9061;
        private MyDate employerSignDate9061;
        private MyDate felConvictionDate;
        private MyDate felReleaseDate;
        private MyDate hireDate;
        private MyDate infoDate;
        private MyDate offerDate;
        private MyDate postmarkDate;
        private MyDate rehireDate;
        private MyDate releaseDate;
        private MyDate startDate;
        private MyDate unemploymentDeclarationDate;
        private MyDate unemploymentEndDate;
        private MyDate unemploymentStartDate;
        private string ageEligible;
        private string arraVetCategory;
        private string arraYouthCategory;
        private string consultantAddress;
        private string consultantCity;
        private string consultantEmail;
        private string consultantFax;
        private string consultantFEIN;
        private string consultantID;
        private string consultantName;
        private string consultantPhone;
        private string consultantSignerName;
        private string consultantSignerTitle;
        private string consultantState;
        private string consultantZipCode;
        private string employeeCity;
        private string employeeCounty;
        private string employeeEmail;
        private string employeeFirstName;
        private string employeeLastName;
        private string employeeMiddleName;
        private string employeePhone;
        private string employeeSignatureOnFile;
        private string employeeSocial;
        private string employeeState;
        private string employeeStreet;
        private string employeeStreet2;
        private string employeeZip;
        private string employerCity;
        private string employerCounty;
        private string employerEmail;
        private string employerFax;
        private string employerFEIN;
        private string employerName;
        private string employerPhone;
        private string employerPhoneDash;
        private string employerPhoneExtension;
        private string employerState;
        private string employerStreet;
        private string employerStreet2;
        private string employerZip;
        private string empowermentZone;
        private string empowermentZoneSummerJob;
        private string felonFederalStateFS;
        private string felonFederalStatus;
        private string felonStateName;
        private string felonStateStatus;
        private string felonStatus;
        private string form9062;
        private string formCompletedBy;
        private string katrinaEmployee;
        private string katrinaEmployeeCity;
        private string katrinaEmployeeCounty;
        private string katrinaEmployeeState;
        private string katrinaEmployeeStreet;
        private string katrinaEmployeeZip;
        private string katrinaJobCounty;
        private string katrinaJobState;
        private string katrinaNewEmployee;
        private string occupationCodeONET;
        private string outOfStateBenCity;
        private string outOfStateBenRecipient;
        private string outOfStateBenState;
        private string pin8850;
        private string position;
        private string positionTitle;
        private string q1_8850;
        private string q2_8850;
        private string q3_8850;
        private string q4_8850;
        private string q5_8850;
        private string q6_8850;
        private string q7_8850;
        private string rehire;
        private string representativeName;
        private string requestID;
        private string ruralRenewalCountyName;
        private string ruralRenewalCountyStatus;
        private string signatureOnFileForm9175;
        private string snap01;
        private string snap02;
        private string snapCity;
        private string snapRecipient;
        private string snapState;
        private string sourceDocuments01;
        private string sourceDocuments02;
        private string sourceDocuments03;
        private string sourceDocuments04;
        private string supplementalSecurity;
        private string tanf01;
        private string tanf02;
        private string tanf03;
        private string tanf04;
        private string tanfRecipient;
        private string tanfState;
        private string targetGroup;
        private string unemploymentFederal_YN;
        private string unemploymentFedState_FS;
        private string unemploymentState_YN;
        private string unemploymentStateName;
        private string unemploymentStatus;
        private string version8850;
        private string version9061;
        private string veteran1Year;
        private string veteran4Weeks;
        private string veteran6Months;
        private string veteranDisabled;
        private string veteranSnapRecipient;
        private string veteranSnapState;
        private string veteranStatus;
        private string veteranSNAP;
        private string vocRehabAgency;
        private string vocRehabTicketToWork;
        private string vocRehabVeteranAffairs;
        private string vowToHireHeroes;
        private string wage = MyConst.WAGE_DEFAULT.ToString();
        private string wageCentsOnly;
        private string wageDollarsOnly;


        public MyState()
        {
            // TODO MyState constructor
        } // end blank MyState constructor

        public MyState(int stateSelector)
        {
            CreateState(stateSelector);
        } // end blank MyState constructor

        public MyState CreateState(int stateSelector)
        {
            MyState thisState = new MyState();

            InitializeRRC();
            InitializeEZ();

            thisState.VarList = new List<string>();
            thisState.VarLength = new List<int>();

            // Initialize the state with delimiter, minimum wage, true/false values
            switch (stateSelector)
            {
                case MyConst.STATE_AK:
                    // TODO Configure State
                    break;

                case MyConst.STATE_AL:
                    StateName = "AL";
                    StateIdentifier = MyConst.STATE_AL;
                    InitializeAL();
                    break;

                case MyConst.STATE_AR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_AZ:
                    // TODO Configure State
                    break;

                case MyConst.STATE_CA:
                    // TODO Configure state
                    break;

                case MyConst.STATE_CO:
                    // TODO Configure State
                    break;

                case MyConst.STATE_CT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_DC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_DE:
                    // TODO Configure State
                    break;

                case MyConst.STATE_FL:
                    // TODO Configure State
                    break;

                case MyConst.STATE_GA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_GU:
                    // TODO Configure State
                    break;

                case MyConst.STATE_HI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ID:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IL:
                    // TODO Configure State
                    break;

                case MyConst.STATE_IN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_KS:
                    // TODO Configure State
                    break;

                case MyConst.STATE_KY:
                    // TODO Configure State
                    break;

                case MyConst.STATE_LA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MD:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ME:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MO:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MS:
                    // TODO Configure State
                    break;

                case MyConst.STATE_MT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_ND:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NE:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NH:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NJ:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NM:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NV:
                    // TODO Configure State
                    break;

                case MyConst.STATE_NY:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OH:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OK:
                    // TODO Configure State
                    break;

                case MyConst.STATE_OR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_PA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_PR:
                    // TODO Configure State
                    break;

                case MyConst.STATE_RI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_SC:
                    // TODO Configure State
                    break;

                case MyConst.STATE_SD:
                    // TODO Configure State
                    break;

                case MyConst.STATE_TN:
                    // TODO Configure State
                    break;

                case MyConst.STATE_TX:
                    // TODO Configure State
                    break;

                case MyConst.STATE_UT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_VA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_VT:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WA:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WI:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WV:
                    // TODO Configure State
                    break;

                case MyConst.STATE_WY:
                    // TODO Configure State
                    break;
            } // end switch (stateSelector)

            return thisState;
        } // end CreateState(int stateSelector)


        // General Utilities
        public string AddBlankSpaces(int count)
        {
            string spaces = "";
            while (spaces.Length < count)
                spaces = spaces + " ";
            return spaces;
        }

        public void InitializeAL()
        {
            // Basic values
            this.Delimiter = MyConst.DELMT_SPACE;
            this.TrueAnswer = MyConst.TRUE_Y;
            this.FalseAnswer = MyConst.FALSE_N;
            this.MinimumWage = 0.00;

            // Variables
            this.VarList.Add(ConsultantID);     // Add variable to state configuration
            this.VarLength.Add(12);             // Add variable length
            this.VarList.Add(EmployerFEIN);
            this.VarLength.Add(9);
            this.VarList.Add(EmployeeSocial);
            this.VarLength.Add(9);
            this.VarList.Add(EmployeeFirstName);
            this.VarLength.Add(10);
            this.VarList.Add(EmployeeMiddleName);
            this.VarLength.Add(1);
            this.VarList.Add(EmployeeLastName);
            this.VarLength.Add(19);
            this.VarList.Add(EmployeeStreet);
            this.VarLength.Add(30);
            this.VarList.Add(EmployeeCity);
            this.VarLength.Add(20);
            this.VarList.Add(EmployeeState);
            this.VarLength.Add(2);
            this.VarList.Add(EmployeeZip);
            this.VarLength.Add(5);
            this.VarList.Add(EmployeePhone);
            this.VarLength.Add(10);
            this.VarList.Add(DateOfBirth.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(KatrinaEmployee);
            this.VarLength.Add(1);
            this.VarList.Add(KatrinaEmployeeCounty);
            this.VarLength.Add(20);
            this.VarList.Add(KatrinaEmployeeStreet);
            this.VarLength.Add(30);
            this.VarList.Add(KatrinaEmployeeCity);
            this.VarLength.Add(20);
            this.VarList.Add(KatrinaEmployeeState);
            this.VarLength.Add(2);
            this.VarList.Add(KatrinaEmployeeZip);
            this.VarLength.Add(5);
            this.VarList.Add(Q2_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q3_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q4_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q5_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Pin8850);
            this.VarLength.Add(20);
            this.VarList.Add(EmployeeSignatureOnFile);
            this.VarLength.Add(1);
            this.VarList.Add(EmployeeSignDate8850.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(TargetGroup);
            this.VarLength.Add(1);
            this.VarList.Add(InfoDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(OfferDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(HireDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(StartDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(KatrinaJobCounty);
            this.VarLength.Add(20);
            this.VarList.Add(KatrinaJobState);
            this.VarLength.Add(2);
            this.VarList.Add(KatrinaNewEmployee);
            this.VarLength.Add(1);
            this.VarList.Add(EmployeeSignDate8850.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(WageDollarsOnly);
            this.VarLength.Add(2);
            this.VarList.Add(WageCentsOnly);
            this.VarLength.Add(2);
            this.VarList.Add(OccupationCodeONET);
            this.VarLength.Add(2);
            this.VarList.Add(Rehire);
            this.VarLength.Add(1);
            this.VarList.Add(VeteranSNAP);
            this.VarLength.Add(1);
            this.VarList.Add(VeteranDisabled);
            this.VarLength.Add(1);
            this.VarList.Add(Veteran1Year);
            this.VarLength.Add(1);
            this.VarList.Add(Veteran6Months);
            this.VarLength.Add(1);
            this.VarList.Add(Snap01);
            this.VarLength.Add(1);
            this.VarList.Add(Snap02);
            this.VarLength.Add(1);
            this.VarList.Add(VocRehabAgency);
            this.VarLength.Add(1);
            this.VarList.Add(VocRehabTicketToWork);
            this.VarLength.Add(1);
            this.VarList.Add(VocRehabVeteranAffairs);
            this.VarLength.Add(1);
            this.VarList.Add(Tanf01);
            this.VarLength.Add(1);
            this.VarList.Add(Tanf02);
            this.VarLength.Add(1);
            this.VarList.Add(Tanf03);
            this.VarLength.Add(1);
            this.VarList.Add(Tanf04);
            this.VarLength.Add(1);
            this.VarList.Add(SnapRecipient);
            this.VarLength.Add(30);
            this.VarList.Add(SnapCity);
            this.VarLength.Add(20);
            this.VarList.Add(SnapState);
            this.VarLength.Add(2);
            this.VarList.Add(FelonStatus);
            this.VarLength.Add(1);
            this.VarList.Add(FelConvictionDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(FelReleaseDate.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(EmpowermentZone);
            this.VarLength.Add(1);
            this.VarList.Add(RuralRenewalCountyStatus);
            this.VarLength.Add(1);
            this.VarList.Add(RuralRenewalCountyName);
            this.VarLength.Add(20);
            this.VarList.Add(SupplementalSecurity);
            this.VarLength.Add(1);
            this.VarList.Add(SourceDocuments01);
            this.VarLength.Add(1);
            this.VarList.Add(SourceDocuments02);
            this.VarLength.Add(1);
            this.VarList.Add(SourceDocuments03);
            this.VarLength.Add(1);
            this.VarList.Add(SourceDocuments04);
            this.VarLength.Add(1);
            this.VarList.Add(FormCompletedBy);
            this.VarLength.Add(1);
            this.VarList.Add(EmployeeSignDate9061.ToString());
            this.VarLength.Add(8);
            this.VarList.Add(OutOfStateBenCity);
            this.VarLength.Add(20);
            this.VarList.Add(OutOfStateBenState);
            this.VarLength.Add(2);
            this.VarList.Add(RepresentativeName);
            this.VarLength.Add(12);
            this.VarList.Add(ArraVetCategory);
            this.VarLength.Add(1);
            this.VarList.Add(ArraYouthCategory);
            this.VarLength.Add(1);
            this.VarList.Add(VowToHireHeroes);
            this.VarLength.Add(1);
            this.VarList.Add(Version8850);
            this.VarLength.Add(2);
            this.VarList.Add(Version9061);
            this.VarLength.Add(2);
            this.VarList.Add(Form9062);
            this.VarLength.Add(1);
            this.VarList.Add(Q2_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q3_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q4_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q5_8850);
            this.VarLength.Add(1);
            this.VarList.Add(Q6_8850);
            this.VarLength.Add(1);
            this.VarList.Add(FelonFederalStateFS);
            this.VarLength.Add(1);
            this.VarList.Add(FelonStateName);
            this.VarLength.Add(2);
            this.VarList.Add(Veteran6Months);
            this.VarLength.Add(1);
            this.VarList.Add(Veteran4Weeks);
            this.VarLength.Add(1);
            this.VarList.Add(SupplementalSecurity);                     // AL calls this category F
            this.VarLength.Add(1);
            this.VarList.Add(PostmarkDate.ToString());                  // AL calls this mail date
            this.VarLength.Add(8);
            this.VarList.Add(UnemploymentStatus);
            this.VarLength.Add(1);
            this.VarList.Add(UnemploymentState_YN);                     // AL asks if employee rec'd unempl federal or state (Y/N)
            this.VarLength.Add(1);
            this.VarList.Add(Q7_8850);
            this.VarLength.Add(1);
            this.VarList.Add(SignatureOnFileForm9175);                   // not implemented yet
            this.VarLength.Add(1);
            this.VarList.Add(UnemploymentStatus);                        // not implemented yet
            this.VarLength.Add(1);
            this.VarList.Add(UnemploymentState_YN);                      // not implemented yet
            this.VarLength.Add(1);
            this.VarList.Add(UnemploymentStartDate.ToString());          // not implemented yet
            this.VarLength.Add(8);
            this.VarList.Add(UnemploymentEndDate.ToString());            // not implemented yet
            this.VarLength.Add(8);
            this.VarList.Add(UnemploymentDeclarationDate.ToString());    // not implemented yet
            this.VarLength.Add(8);
            this.VarList.Add(UnemploymentStateName);
            this.VarLength.Add(2);
            this.VarList.Add(AddBlankSpaces(56));                        // AL says leave blank for future use
            this.VarLength.Add(56);
            this.VarList.Add(EmployerName);
            this.VarLength.Add(50);
            this.VarList.Add(EmployerStreet);
            this.VarLength.Add(30);
            this.VarList.Add(EmployerStreet2);
            this.VarLength.Add(30);
            this.VarList.Add(EmployerCity);
            this.VarLength.Add(20);
            this.VarList.Add(EmployerState);
            this.VarLength.Add(2);
            this.VarList.Add(EmployerZip);
            this.VarLength.Add(5);
            this.VarList.Add(EmployerPhone);                             // Phone number no hyphens
            this.VarLength.Add(10);
            this.VarList.Add(EmployerPhoneExtension);
            this.VarLength.Add(4);
        } // end InitializeAL()

        public string AddTrailingSpaces(string input, int length)
        {
            while (input.Length < length)
                input = input + " ";
            return input;
        }

        private void InitializeEZ()
        {
            //TODO  Add variations on commonly misspelled cities, e.g. Tucson and Minneapolis
            EmpowermentZoneList.Add("AZTucson");                // Commonly misspelled
            EmpowermentZoneList.Add("CA29 Palms");
            EmpowermentZoneList.Add("CAActon");
            EmpowermentZoneList.Add("CAAdelanto");
            EmpowermentZoneList.Add("CAAgua Dulce");
            EmpowermentZoneList.Add("CAAmboy");
            EmpowermentZoneList.Add("CAAntelope Acres");
            EmpowermentZoneList.Add("CAApple Valley");
            EmpowermentZoneList.Add("CABagdad");
            EmpowermentZoneList.Add("CABarstow");
            EmpowermentZoneList.Add("CABig River");
            EmpowermentZoneList.Add("CABishop");
            EmpowermentZoneList.Add("CABluewater");
            EmpowermentZoneList.Add("CABoron");
            EmpowermentZoneList.Add("CACadiz");
            EmpowermentZoneList.Add("CACalico");
            EmpowermentZoneList.Add("CACalifornia City");
            EmpowermentZoneList.Add("CAChambless");
            EmpowermentZoneList.Add("CACima");
            EmpowermentZoneList.Add("CADaggett");
            EmpowermentZoneList.Add("CADel Sur");
            EmpowermentZoneList.Add("CADesert Communities");
            EmpowermentZoneList.Add("CAEarp");
            EmpowermentZoneList.Add("CAEdwards");
            EmpowermentZoneList.Add("CAElizabeth Lake");
            EmpowermentZoneList.Add("CAEssex");
            EmpowermentZoneList.Add("CAFort Irwin");
            EmpowermentZoneList.Add("CAFresno");                // Commonly misspelled
            EmpowermentZoneList.Add("CAFrenso");
            EmpowermentZoneList.Add("CAFreso");
            EmpowermentZoneList.Add("CAFresn");
            EmpowermentZoneList.Add("CAFesno");
            EmpowermentZoneList.Add("CAFrsno");
            EmpowermentZoneList.Add("CAGoffs");
            EmpowermentZoneList.Add("CAHalloran Springs");
            EmpowermentZoneList.Add("CAHelendale");
            EmpowermentZoneList.Add("CAHesperia");
            EmpowermentZoneList.Add("CAHi Vista");
            EmpowermentZoneList.Add("CAHinkley");
            EmpowermentZoneList.Add("CAInyokern");
            EmpowermentZoneList.Add("CAJohnson Valley");
            EmpowermentZoneList.Add("CAJoshua Tree");
            EmpowermentZoneList.Add("CAKelso");
            EmpowermentZoneList.Add("CAKramer Junction");
            EmpowermentZoneList.Add("CALake Hughes");
            EmpowermentZoneList.Add("CALake Los Angeles");      // Commonly misspelled
            EmpowermentZoneList.Add("CALake LA");
            EmpowermentZoneList.Add("CALancaster");
            EmpowermentZoneList.Add("CALanders");
            EmpowermentZoneList.Add("CALenwood");
            EmpowermentZoneList.Add("CALeona Valley");
            EmpowermentZoneList.Add("CALittlerock");
            EmpowermentZoneList.Add("CALlano");
            EmpowermentZoneList.Add("CALone Pine");
            EmpowermentZoneList.Add("CALos Angeles");
            EmpowermentZoneList.Add("CALA");
            EmpowermentZoneList.Add("CALos Angel");
            EmpowermentZoneList.Add("CALosAngel");
            EmpowermentZoneList.Add("CALosAngeles");
            EmpowermentZoneList.Add("CALos Angles");
            EmpowermentZoneList.Add("CALosAngles");
            EmpowermentZoneList.Add("CALucerne Valley");
            EmpowermentZoneList.Add("CALudlow");
            EmpowermentZoneList.Add("CAMojave");
            EmpowermentZoneList.Add("CAMountain Pass");
            EmpowermentZoneList.Add("CAMountain View Acres");
            EmpowermentZoneList.Add("CANebo Center");
            EmpowermentZoneList.Add("CANeedles");
            EmpowermentZoneList.Add("CANeenach");
            EmpowermentZoneList.Add("CANewberry Springs");
            EmpowermentZoneList.Add("CANipton");
            EmpowermentZoneList.Add("CANorth Edwards");
            EmpowermentZoneList.Add("CAOak Hills");
            EmpowermentZoneList.Add("CAOro Grande");
            EmpowermentZoneList.Add("CAPalmdale");
            EmpowermentZoneList.Add("CAPearblossom");
            EmpowermentZoneList.Add("CAPhelan");
            EmpowermentZoneList.Add("CAPinon Hills");
            EmpowermentZoneList.Add("CAPioneertown");
            EmpowermentZoneList.Add("CAQuartz Hill");
            EmpowermentZoneList.Add("CARagtown");
            EmpowermentZoneList.Add("CARandsburg");
            EmpowermentZoneList.Add("CARice");
            EmpowermentZoneList.Add("CARidgecrest");
            EmpowermentZoneList.Add("CARiverside");
            EmpowermentZoneList.Add("CARosamond");
            EmpowermentZoneList.Add("CASantaAna");
            EmpowermentZoneList.Add("CASiberia");
            EmpowermentZoneList.Add("CASun Village");
            EmpowermentZoneList.Add("CASunfair");
            EmpowermentZoneList.Add("CASunfair Heights");
            EmpowermentZoneList.Add("CAThermal");
            EmpowermentZoneList.Add("CATrona");
            EmpowermentZoneList.Add("CATwenty Nine Palms");     // Commonly misspelled
            EmpowermentZoneList.Add("CATwentynine Palms");
            EmpowermentZoneList.Add("CA29 Palms");
            EmpowermentZoneList.Add("CATwentynine Palms Marine Corps Base");
            EmpowermentZoneList.Add("CATwentynine Palms MCB");
            EmpowermentZoneList.Add("CATwentynine Palms Base");
            EmpowermentZoneList.Add("CAValyermo");
            EmpowermentZoneList.Add("CAVictorville");
            EmpowermentZoneList.Add("CAVidal");
            EmpowermentZoneList.Add("CAVidal Junction");
            EmpowermentZoneList.Add("CAYermo");
            EmpowermentZoneList.Add("CAYucca Valley");
            EmpowermentZoneList.Add("CAZzyzx");
            EmpowermentZoneList.Add("CTNewHaven");
            EmpowermentZoneList.Add("FLJacksonville");          // Commonly misspelled
            EmpowermentZoneList.Add("FLJacksnville");
            EmpowermentZoneList.Add("FLJacksonvile");
            EmpowermentZoneList.Add("FLJcksonville");
            EmpowermentZoneList.Add("FLJax");
            EmpowermentZoneList.Add("FLJacksonville Beach");
            EmpowermentZoneList.Add("FLJax Beach");
            EmpowermentZoneList.Add("ILChicago");               // Commonly misspelled
            EmpowermentZoneList.Add("ILEastSt.Louis");          // Commonly misspelled
            EmpowermentZoneList.Add("INEast Chicago");          // Commonly misspelled
            EmpowermentZoneList.Add("INGary");
            EmpowermentZoneList.Add("INHammond");
            EmpowermentZoneList.Add("MABoston");
            EmpowermentZoneList.Add("MDBaltimore");             // Commonly misspelled
            EmpowermentZoneList.Add("MIDetroit");               // Commonly misspelled
            EmpowermentZoneList.Add("MNMinneapolis");           // Commonly misspelled     
            EmpowermentZoneList.Add("MOSaint Louis City");      // Commonly misspelled
            EmpowermentZoneList.Add("NJCamden");
            EmpowermentZoneList.Add("NYNewYork");               // Commonly misspelled
            EmpowermentZoneList.Add("NYSyracuse");
            EmpowermentZoneList.Add("NYYonkers");
            EmpowermentZoneList.Add("OHCincinnati");
            EmpowermentZoneList.Add("OHCleveland");
            EmpowermentZoneList.Add("OHColumbus");
            EmpowermentZoneList.Add("OHIronton");
            EmpowermentZoneList.Add("OKOklahoma City");
            EmpowermentZoneList.Add("OKOklhoma City");
            EmpowermentZoneList.Add("OKOklahma City");
            EmpowermentZoneList.Add("OKOklahom City");
            EmpowermentZoneList.Add("OKOklahoa City");
            EmpowermentZoneList.Add("OKOklahoma Cit");
            EmpowermentZoneList.Add("OKOklahomaCity");
            EmpowermentZoneList.Add("OKOKC");
            EmpowermentZoneList.Add("OKOK City");
            EmpowermentZoneList.Add("PAPhiladelphia");          // Commonly misspelled
            EmpowermentZoneList.Add("PAPhiladelpha");
            EmpowermentZoneList.Add("PAPhiladelphi");
            EmpowermentZoneList.Add("PAPhiladelhia");
            EmpowermentZoneList.Add("PAPhiladephia");
            EmpowermentZoneList.Add("PAPhiladlphia");
            EmpowermentZoneList.Add("PAPhilaelphia");
            EmpowermentZoneList.Add("PAPhildelphia");
            EmpowermentZoneList.Add("PAPhiadelphia");
            EmpowermentZoneList.Add("PAPhladelphia");
            EmpowermentZoneList.Add("PAPiladelphia");
            EmpowermentZoneList.Add("PAFiladelphia");
            EmpowermentZoneList.Add("PAPhil");
            EmpowermentZoneList.Add("PAPhilly");
            EmpowermentZoneList.Add("SCColumbia");              // Commonly misspelled
            EmpowermentZoneList.Add("SCColumba");
            EmpowermentZoneList.Add("SCColmbia");
            EmpowermentZoneList.Add("SCClumbia");
            EmpowermentZoneList.Add("SCSumter");
            EmpowermentZoneList.Add("SDOglala Sioux Tribe");
            EmpowermentZoneList.Add("TNKnoxville");             // Commonly misspelled
            EmpowermentZoneList.Add("TNKnox");
            EmpowermentZoneList.Add("TNKnxville");
            EmpowermentZoneList.Add("TNKnoxvile");
            EmpowermentZoneList.Add("TNKnx");
            EmpowermentZoneList.Add("TXEl Paso");               // Commonly misspelled
            EmpowermentZoneList.Add("TXElPaso");
            EmpowermentZoneList.Add("TXEl Pso");
            EmpowermentZoneList.Add("TXEl Pas");
            EmpowermentZoneList.Add("TXElPso");
            EmpowermentZoneList.Add("TXEP");
            EmpowermentZoneList.Add("TXSan Antonio");           // Commonly misspelled
            EmpowermentZoneList.Add("TXSan Anton");
            EmpowermentZoneList.Add("TXSan Antono");
            EmpowermentZoneList.Add("TXSan Antoni");
            EmpowermentZoneList.Add("TXSanAntonio");
            EmpowermentZoneList.Add("TXSanAnton");
            EmpowermentZoneList.Add("TXSn Antonio");
            EmpowermentZoneList.Add("VAClifton Forge");
            EmpowermentZoneList.Add("VACovington");
            EmpowermentZoneList.Add("VANorfolk");               // Commonly misspelled
            EmpowermentZoneList.Add("VANorflk");
            EmpowermentZoneList.Add("VANrfolk");
            EmpowermentZoneList.Add("VANorfok");
            EmpowermentZoneList.Add("VANorfuk");
            EmpowermentZoneList.Add("VANorton");
            EmpowermentZoneList.Add("VAPortsmouth");
            EmpowermentZoneList.Add("VAStanton");
            EmpowermentZoneList.Add("VAStaunton");
            EmpowermentZoneList.Add("WVHuntington");
        }

        private void InitializeRRC()
        {
            // TODO Compile list of eligible RRC zip codes
            throw new NotImplementedException("List of RRC zip codes not yet available.");
        }

        // Getters and Setters State Basic Values
        public int State { get => state; set => state = value; }
        public string Delimiter { get => delimiter; set => delimiter = value; }
        public string TrueAnswer { get => trueAnswer; set => trueAnswer = value; }
        public string FalseAnswer { get => falseAnswer; set => falseAnswer = value; }
        public double MinimumWage { get => minimumWage; set => minimumWage = value; }
        public List<string> ValidCities { get => validCities; set => validCities = value; }
        public List<string> VarList { get => varList; set => varList = value; }
        public List<int> VarLength { get => varLength; set => varLength = value; }

        // Getters and Setters Form Variables
        public int StateIdentifier { get => stateIdentifier; set => stateIdentifier = value; }
        public string AgeEligible { get => ageEligible; set => ageEligible = value; }
        public string ArraVetCategory { get => arraVetCategory; set => arraVetCategory = value; }
        public string ArraYouthCategory { get => arraYouthCategory; set => arraYouthCategory = value; }
        public string ConsultantAddress { get => consultantAddress; set => consultantAddress = value; }
        public string ConsultantCity { get => consultantCity; set => consultantCity = value; }
        public string ConsultantEmail { get => consultantEmail; set => consultantEmail = value; }
        public string ConsultantFax { get => consultantFax; set => consultantFax = value; }
        public string ConsultantFEIN { get => consultantFEIN; set => consultantFEIN = value; }
        public string ConsultantID { get => consultantID; set => consultantID = value; }
        public string ConsultantName { get => consultantName; set => consultantName = value; }
        public string ConsultantPhone { get => consultantPhone; set => consultantPhone = value; }
        public string ConsultantSignerName { get => consultantSignerName; set => consultantSignerName = value; }
        public string ConsultantSignerTitle { get => consultantSignerTitle; set => consultantSignerTitle = value; }
        public string ConsultantState { get => consultantState; set => consultantState = value; }
        public string ConsultantZipCode { get => consultantZipCode; set => consultantZipCode = value; }
        public string EmployeeCity { get => employeeCity; set => employeeCity = value; }
        public string EmployeeCounty { get => employeeCounty; set => employeeCounty = value; }
        public string EmployeeEmail { get => employeeEmail; set => employeeEmail = value; }
        public string EmployeeFirstName { get => employeeFirstName; set => employeeFirstName = value; }
        public string EmployeeLastName { get => employeeLastName; set => employeeLastName = value; }
        public string EmployeeMiddleName { get => employeeMiddleName; set => employeeMiddleName = value; }
        public string EmployeePhone { get => employeePhone; set => employeePhone = value; }
        public string EmployeeSignatureOnFile { get => employeeSignatureOnFile; set => employeeSignatureOnFile = value; }
        public string EmployeeSocial { get => employeeSocial; set => employeeSocial = value; }
        public string EmployeeState { get => employeeState; set => employeeState = value; }
        public string EmployeeStreet { get => employeeStreet; set => employeeStreet = value; }
        public string EmployeeStreet2 { get => employeeStreet2; set => employeeStreet2 = value; }
        public string EmployeeZip { get => employeeZip; set => employeeZip = value; }
        public string EmployerCity { get => employerCity; set => employerCity = value; }
        public string EmployerCounty { get => employerCounty; set => employerCounty = value; }
        public string EmployerEmail { get => employerEmail; set => employerEmail = value; }
        public string EmployerFax { get => employerFax; set => employerFax = value; }
        public string EmployerFEIN { get => employerFEIN; set => employerFEIN = value; }
        public string EmployerName { get => employerName; set => employerName = value; }
        public string EmployerPhone { get => employerPhone; set => employerPhone = value; }
        public string EmployerPhoneDash { get => employerPhoneDash; set => employerPhoneDash = value; }
        public string EmployerPhoneExtension { get => employerPhoneExtension; set => employerPhoneExtension = value; }
        public string EmployerState { get => employerState; set => employerState = value; }
        public string EmployerStreet { get => employerStreet; set => employerStreet = value; }
        public string EmployerStreet2 { get => employerStreet2; set => employerStreet2 = value; }
        public string EmployerZip { get => employerZip; set => employerZip = value; }
        public string EmpowermentZone { get => empowermentZone; set => empowermentZone = value; }
        public string EmpowermentZoneSummerJob { get => empowermentZoneSummerJob; set => empowermentZoneSummerJob = value; }
        public string FelonFederalStateFS { get => felonFederalStateFS; set => felonFederalStateFS = value; }
        public string FelonFederalStatus { get => felonFederalStatus; set => felonFederalStatus = value; }
        public string FelonStateName { get => felonStateName; set => felonStateName = value; }
        public string FelonStateStatus { get => felonStateStatus; set => felonStateStatus = value; }
        public string FelonStatus { get => felonStatus; set => felonStatus = value; }
        public string Form9062 { get => form9062; set => form9062 = value; }
        public string FormCompletedBy { get => formCompletedBy; set => formCompletedBy = value; }
        public string KatrinaEmployee { get => katrinaEmployee; set => katrinaEmployee = value; }
        public string KatrinaEmployeeCity { get => katrinaEmployeeCity; set => katrinaEmployeeCity = value; }
        public string KatrinaEmployeeCounty { get => katrinaEmployeeCounty; set => katrinaEmployeeCounty = value; }
        public string KatrinaEmployeeState { get => katrinaEmployeeState; set => katrinaEmployeeState = value; }
        public string KatrinaEmployeeStreet { get => katrinaEmployeeStreet; set => katrinaEmployeeStreet = value; }
        public string KatrinaEmployeeZip { get => katrinaEmployeeZip; set => katrinaEmployeeZip = value; }
        public string KatrinaJobCounty { get => katrinaJobCounty; set => katrinaJobCounty = value; }
        public string KatrinaJobState { get => katrinaJobState; set => katrinaJobState = value; }
        public string KatrinaNewEmployee { get => katrinaNewEmployee; set => katrinaNewEmployee = value; }
        public string OccupationCodeONET { get => occupationCodeONET; set => occupationCodeONET = value; }
        public string OutOfStateBenCity { get => outOfStateBenCity; set => outOfStateBenCity = value; }
        public string OutOfStateBenRecipient { get => outOfStateBenRecipient; set => outOfStateBenRecipient = value; }
        public string OutOfStateBenState { get => outOfStateBenState; set => outOfStateBenState = value; }
        public string Pin8850 { get => pin8850; set => pin8850 = value; }
        public string Position { get => position; set => position = value; }
        public string PositionTitle { get => positionTitle; set => positionTitle = value; }
        public string Q1_8850 { get => q1_8850; set => q1_8850 = value; }
        public string Q2_8850 { get => q2_8850; set => q2_8850 = value; }
        public string Q3_8850 { get => q3_8850; set => q3_8850 = value; }
        public string Q4_8850 { get => q4_8850; set => q4_8850 = value; }
        public string Q5_8850 { get => q5_8850; set => q5_8850 = value; }
        public string Q6_8850 { get => q6_8850; set => q6_8850 = value; }
        public string Q7_8850 { get => q7_8850; set => q7_8850 = value; }
        public string Rehire { get => rehire; set => rehire = value; }
        public string RepresentativeName { get => representativeName; set => representativeName = value; }
        public string RequestID { get => requestID; set => requestID = value; }
        public string RuralRenewalCountyName { get => ruralRenewalCountyName; set => ruralRenewalCountyName = value; }
        public string RuralRenewalCountyStatus { get => ruralRenewalCountyStatus; set => ruralRenewalCountyStatus = value; }
        public string SignatureOnFileForm9175 { get => signatureOnFileForm9175; set => signatureOnFileForm9175 = value; }
        public string Snap01 { get => snap01; set => snap01 = value; }
        public string Snap02 { get => snap02; set => snap02 = value; }
        public string SnapCity { get => snapCity; set => snapCity = value; }
        public string SnapRecipient { get => snapRecipient; set => snapRecipient = value; }
        public string SnapState { get => snapState; set => snapState = value; }
        public string SourceDocuments01 { get => sourceDocuments01; set => sourceDocuments01 = value; }
        public string SourceDocuments02 { get => sourceDocuments02; set => sourceDocuments02 = value; }
        public string SourceDocuments03 { get => sourceDocuments03; set => sourceDocuments03 = value; }
        public string SourceDocuments04 { get => sourceDocuments04; set => sourceDocuments04 = value; }
        public string SupplementalSecurity { get => supplementalSecurity; set => supplementalSecurity = value; }
        public string Tanf01 { get => tanf01; set => tanf01 = value; }
        public string Tanf02 { get => tanf02; set => tanf02 = value; }
        public string Tanf03 { get => tanf03; set => tanf03 = value; }
        public string Tanf04 { get => tanf04; set => tanf04 = value; }
        public string TanfRecipient { get => tanfRecipient; set => tanfRecipient = value; }
        public string TanfState { get => tanfState; set => tanfState = value; }
        public string TargetGroup { get => targetGroup; set => targetGroup = value; }
        public string UnemploymentFederal_YN { get => unemploymentFederal_YN; set => unemploymentFederal_YN = value; }
        public string UnemploymentFedState_FS { get => unemploymentFedState_FS; set => unemploymentFedState_FS = value; }
        public string UnemploymentState_YN { get => unemploymentState_YN; set => unemploymentState_YN = value; }
        public string UnemploymentStateName { get => unemploymentStateName; set => unemploymentStateName = value; }
        public string UnemploymentStatus { get => unemploymentStatus; set => unemploymentStatus = value; }
        public string Version8850 { get => version8850; set => version8850 = value; }
        public string Version9061 { get => version9061; set => version9061 = value; }
        public string Veteran1Year { get => veteran1Year; set => veteran1Year = value; }
        public string Veteran4Weeks { get => veteran4Weeks; set => veteran4Weeks = value; }
        public string Veteran6Months { get => veteran6Months; set => veteran6Months = value; }
        public string VeteranDisabled { get => veteranDisabled; set => veteranDisabled = value; }
        public string VeteranSnapRecipient { get => veteranSnapRecipient; set => veteranSnapRecipient = value; }
        public string VeteranSnapState { get => veteranSnapState; set => veteranSnapState = value; }
        public string VeteranStatus { get => veteranStatus; set => veteranStatus = value; }
        public string VeteranSNAP { get => veteranSNAP; set => veteranSNAP = value; }
        public string VocRehabAgency { get => vocRehabAgency; set => vocRehabAgency = value; }
        public string VocRehabTicketToWork { get => vocRehabTicketToWork; set => vocRehabTicketToWork = value; }
        public string VocRehabVeteranAffairs { get => vocRehabVeteranAffairs; set => vocRehabVeteranAffairs = value; }
        public string VowToHireHeroes { get => vowToHireHeroes; set => vowToHireHeroes = value; }
        public string Wage { get => wage; set => wage = value; }
        public string WageCentsOnly { get => wageCentsOnly; set => wageCentsOnly = value; }
        public string WageDollarsOnly { get => wageDollarsOnly; set => wageDollarsOnly = value; }
        internal MyDate ConvictionDate { get => convictionDate; set => convictionDate = value; }
        internal MyDate DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        internal MyDate EmployeeSignDate8850 { get => employeeSignDate8850; set => employeeSignDate8850 = value; }
        internal MyDate EmployeeSignDate9061 { get => employeeSignDate9061; set => employeeSignDate9061 = value; }
        internal MyDate EmployerSignDate9061 { get => employerSignDate9061; set => employerSignDate9061 = value; }
        internal MyDate FelConvictionDate { get => felConvictionDate; set => felConvictionDate = value; }
        internal MyDate FelReleaseDate { get => felReleaseDate; set => felReleaseDate = value; }
        internal MyDate HireDate { get => hireDate; set => hireDate = value; }
        internal MyDate InfoDate { get => infoDate; set => infoDate = value; }
        internal MyDate OfferDate { get => offerDate; set => offerDate = value; }
        internal MyDate PostmarkDate { get => postmarkDate; set => postmarkDate = value; }
        internal MyDate RehireDate { get => rehireDate; set => rehireDate = value; }
        internal MyDate ReleaseDate { get => releaseDate; set => releaseDate = value; }
        internal MyDate StartDate { get => startDate; set => startDate = value; }
        internal MyDate UnemploymentDeclarationDate { get => unemploymentDeclarationDate; set => unemploymentDeclarationDate = value; }
        internal MyDate UnemploymentEndDate { get => unemploymentEndDate; set => unemploymentEndDate = value; }
        internal MyDate UnemploymentStartDate { get => unemploymentStartDate; set => unemploymentStartDate = value; }
        public string StateName { get => stateName; set => stateName = value; }
        public List<string> EmpowermentZoneList { get => empowermentZoneList; set => empowermentZoneList = value; }
        public List<string> RuralRenewalCountyNames { get => ruralRenewalCountyNames; set => ruralRenewalCountyNames = value; }
        public List<string> RuralRenewalCountyZipCodes { get => ruralRenewalCountyZipCodes; set => ruralRenewalCountyZipCodes = value; }
    }
}
