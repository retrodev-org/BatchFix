﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Batch_Fix_and_Conversion
{
    public partial class FormAppUpdate : Form
    {
        public bool bypassApp = false;
        public bool appSubmit = false;

        public FormAppUpdate(MyApp app)
        {
            InitializeComponent();

        }

        // TODO Change employee county to drop-down combo box that populates with counties in that specific state
        // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches

        private void btnAppUpdateSubmit_Click(object sender, EventArgs e)
        {
            appSubmit = true;
            // TODO trigger UpdateApplication()

            this.Refresh();
        }

        private void btnAppUpdateReset_Click(object sender, EventArgs e)
        {
            // TODO Prompt to be sure, then reset fields to the values that were present before changes
        }

        private void btnAppUpdateSkip_Click(object sender, EventArgs e)
        {
            // MyBatch handles adding this app to the app error list
            bypassApp = true;
        }

        private void txtEmployeeCity_Enter(object sender, EventArgs e)
        {
            // if user enters the city field
            if (txtEmployeeCity.Text == "City")
            {
                txtEmployeeCity.Text = "";
            }
        }

        private void txtEmployeeDOB_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeDOB.Text == "Date of Birth")
            {
                txtEmployeeDOB.Text = "";
            }
        }

        private void txtEmployeeFirstName_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new first name
            if (txtEmployeeFirstName.Text == "First Name")
            {
                txtEmployeeFirstName.Text = "";
            }
        }

        private void txtEmployeeMiddleName_Enter(object sender, EventArgs e)
        {
            // if user enters middle name field
            if (txtEmployeeMiddleName.Text == "Middle Name")
            {
                txtEmployeeMiddleName.Text = "";
            }
        }

        private void txtEmployeeLastName_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeLastName.Text == "Last Name")
            {
                txtEmployeeLastName.Text = "";
            }
        }

        private void txtEmployeeSignatureDate_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeSignatureDate.Text == "Employee Sign Date Form 8850")
            {
                txtEmployeeSignatureDate.Text = "";
            }
        }

        private void txtEmployeeSSN_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeSSN.Text == "SSN")
            {
                txtEmployeeSSN.Text = "";
            }
        }

        private void txtEmployeeState_Enter(object sender, EventArgs e)
        {
            // if user enters employee state field
            if (txtEmployeeState.Text == "State")
            {
                txtEmployeeState.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee state cannot be changed yet.");
            }
        }

        private void txtEmployeeStreet1_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeStreet1.Text == "Street Address 1")
            {
                txtEmployeeStreet1.Text = "";
            }
        }

        private void txtEmployeeStreet2_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployeeStreet2.Text == "Street Address 2")
            {
                txtEmployeeStreet2.Text = "";
            }
        }

        private void txtEmployeeZip_Enter(object sender, EventArgs e)
        {
            // if user enters employee info box
            if (txtEmployeeZip.Text == "Zip Code")
            {
                txtEmployeeZip.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtEmployeePhone_Enter(object sender, EventArgs e)
        {
            // if user enters employee info box
            if (txtEmployeePhoneNumber.Text == "Phone Number")
            {
                txtEmployeePhoneNumber.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtEmployeeEmailAddress_Enter(object sender, EventArgs e)
        {
            // if user enters employee email box
            if (txtEmployeeEmailAddress.Text == "Email Address")
            {
                txtEmployeeEmailAddress.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtEmployerName_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new first name
            if (txtEmployerName.Text == "Employer Name")
            {
                txtEmployerName.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerPhone_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new first name
            if (txtEmployerPhone.Text == "Employer Phone")
            {
                txtEmployerPhone.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerFEIN_Enter(object sender, EventArgs e)
        {
            // if user enters the FEIN field
            if (txtEmployerFEIN.Text == "Employer FEIN")
            {
                txtEmployerFEIN.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerStreet1_Enter(object sender, EventArgs e)
        {
            // if user enters a employer street1 field
            if (txtEmployerStreet1.Text == "Employer Street 1")
            {
                txtEmployerStreet1.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerStreet2_Enter(object sender, EventArgs e)
        {
            // if user enters a employer street2 field
            if (txtEmployerStreet1.Text == "Employer Street 2")
            {
                txtEmployerStreet1.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerCity_Enter(object sender, EventArgs e)
        {
            // if user enters a employer city field
            if (txtEmployerCity.Text == "Employer City")
            {
                txtEmployerCity.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");

                // TODO Change employee county to drop-down combo box that populates with counties in that specific state
                // TODO Update county once zip code is entered, check RRC/Empowerment Zone if city/zip matches
            }
        }

        private void txtEmployerState_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtEmployerState.Text == "State")
            {
                txtEmployerState.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employer state cannot be changed yet.");
            }
        }

        private void txtEmployerZip_Enter(object sender, EventArgs e)
        {
            // if user enters employer zip field
            if (txtEmployerState.Text == "Zip Code")
            {
                txtEmployerState.Text = "";
                // TODO Update employer info
                // throw new NotImplementedException("Error: Employer info cannot be changed yet.");
            }
        }

        private void txtWage_Enter(object sender, EventArgs e)
        {
            // if user enters a valid new street address 2
            if (txtWage.Text == "Starting Wage")
            {
                txtWage.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void cmboOnetCode_Enter(object sender, EventArgs e)
        {
            // TODO maybe change value upon enter?
        }

        private void txtVetSnapRecipientName_Enter(object sender, EventArgs e)
        {
            // if user enters vet snap recipient name
            if (txtVetSnapRecipientName.Text == "Primary Recipient")
            {
                txtVetSnapRecipientName.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtSnapRecipientName_Enter(object sender, EventArgs e)
        {
            // if user enters normal snap recipient name
            if (txtSnapRecipientName.Text == "Primary Recipient")
            {
                txtSnapRecipientName.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtTanfRecipientName_Enter(object sender, EventArgs e)
        {
            // if user enters vet snap recipient name
            if (txtTanfRecipientName.Text == "Primary Recipient")
            {
                txtTanfRecipientName.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtVetSnapRecipientCity_Enter(object sender, EventArgs e)
        {
            // if user enters vet snap recipient city
            if (txtVetSnapRecipientCity.Text == "City")
            {
                txtVetSnapRecipientCity.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtSnapRecipientCity_Enter(object sender, EventArgs e)
        {
            // if user enters normal snap recipient city
            if (txtSnapRecipientCity.Text == "City")
            {
                txtSnapRecipientCity.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtTanfRecipientCity_Enter(object sender, EventArgs e)
        {
            // if user enters tanf recipient city
            if (txtTanfRecipientCity.Text == "City")
            {
                txtTanfRecipientCity.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee info cannot be changed yet.");
            }
        }

        private void txtVetSnapRecipientState_Enter(object sender, EventArgs e)
        {
            // if user enters vet snap recipient state field
            if (txtVetSnapRecipientState.Text == "State")
            {
                txtVetSnapRecipientState.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee state cannot be changed yet.");
            }
        }

        private void txtSnapRecipientState_Enter(object sender, EventArgs e)
        {
            // if user enters snap recipient state field
            if (txtSnapRecipientState.Text == "State")
            {
                txtSnapRecipientState.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee state cannot be changed yet.");
            }
        }

        private void txtTanfRecipientState_Enter(object sender, EventArgs e)
        {
            // if user enters tanf recipient state field
            if (txtTanfRecipientState.Text == "State")
            {
                txtTanfRecipientState.Text = "";
                // TODO Update employee info
                // throw new NotImplementedException("Error: Employee state cannot be changed yet.");
            }
        }

        public string GetTxtAppErrorMessageText()
        {
            return txtAppErrorMessageText.Text;
        }

        public void SetTxtAppErrorMessageText(string input)
        {
            txtAppErrorMessageText.Text = input;
        }
    }
}
