﻿using System;
using System.Collections.Generic;

namespace Batch_Fix_and_Conversion
{
    public class MyApp
    {
        // TODO Add function notes to explain input and process
        // Fields in the WOTC application are checked in this class. Whether the app overall is valid is handled by MyBatch when it calls ValidateApplication().

        // General Variables
        private string delimiter;
        private string positive;
        private string negative;
        private int errorCount;
        private int recordFormat;
        private MyState submissionState;
        private bool isReady = false;
        private bool bypass = false;
        List<string> errorList = new List<string>();
        List<string> changeList = new List<string>();

        // Application Variables
        private MyEmployee employee;
        private MyEmployer employer;
        private MyDate dateOfBirth;
        private MyDate employeeSignDate8850;
        private MyDate employeeSignDate9061;
        private MyDate employerSignDate9061;
        private MyDate felConvictionDate;
        private MyDate felReleaseDate;
        private MyDate hireDate;
        private MyDate infoDate;
        private MyDate offerDate;
        private MyDate postmarkDate;
        private MyDate rehireDate;
        private MyDate startDate;
        private MyDate unemploymentDeclarationDate;
        private MyDate unemploymentEndDate;
        private MyDate unemploymentStartDate;
        private string ageEligible;
        private string arraVetCategory;
        private string arraYouthCategory;
        private string employeeSignatureOnFile;
        private string employerCity;
        private string employerCounty;
        private string employerEmail;
        private string employerFax;
        private string employerFEIN;
        private string employerName;
        private string employerPhone;
        private string employerPhoneDash;
        private string employerPhoneExtension;
        private string employerState;
        private string employerStreet;
        private string employerStreet2;
        private string employerZip;
        private string empowermentZone;
        private string empowermentZoneSummerJob;
        private string felonFederalStateFS;
        private string felonFederalStatus;
        private string felonStateName;
        private string felonStateStatus;
        private string felonStatus;
        private string form9062;
        private string formCompletedBy;
        private string katrinaEmployee;
        private string katrinaEmployeeCity;
        private string katrinaEmployeeCounty;
        private string katrinaEmployeeState;
        private string katrinaEmployeeStreet;
        private string katrinaEmployeeZip;
        private string katrinaJobCounty;
        private string katrinaJobState;
        private string katrinaNewEmployee;
        private string occupationCodeONET;
        private string outOfStateBenCity;
        private string outOfStateBenRecipient;
        private string outOfStateBenState;
        private string pin8850;
        private string position;
        private string positionTitle;
        private string q1_8850;
        private string q2_8850;
        private string q3_8850;
        private string q4_8850;
        private string q5_8850;
        private string q6_8850;
        private string q7_8850;
        private string rehire;
        private string representativeName;
        private string requestID;
        private string ruralRenewalCountyStatus;
        private string signatureOnFileForm9175;
        private string snap01;
        private string snap02;
        private string snapCity;
        private string snapRecipient;
        private string snapState;
        private string sourceDocuments01;
        private string sourceDocuments02;
        private string sourceDocuments03;
        private string sourceDocuments04;
        private string supplementalSecurity;
        private string tanf01;
        private string tanf02;
        private string tanf03;
        private string tanf04;
        private string tanfRecipient;
        private string tanfRecipientCity;
        private string tanfRecipientState;
        private string targetGroup;
        private string unemploymentFederal_YN;
        private string unemploymentFedState_FS;
        private string unemploymentState_YN;
        private string unemploymentStateName;
        private string unemploymentStatus;
        private string version8850;
        private string version9061;
        private string veteran1Year;
        private string veteran4Weeks;
        private string veteran6Months;
        private string veteranDisabled;
        private string veteranSnapRecipient;
        private string veteranSnapState;
        private string veteranStatus;
        private string veteranSNAP;
        private string vocRehabAgency;
        private string vocRehabTicketToWork;
        private string vocRehabVeteranAffairs;
        private string vowToHireHeroes;
        private string wage = MyConst.WAGE_DEFAULT.ToString();
        private string wageCentsOnly;
        private string wageDollarsOnly;

        // Getters and Setters
        public int RecordFormat { get => recordFormat; set => recordFormat = value; }
        internal MyDate DateOfBirth { get => dateOfBirth; set => dateOfBirth = value; }
        internal MyDate EmployeeSignDate8850 { get => employeeSignDate8850; set => employeeSignDate8850 = value; }
        internal MyDate EmployeeSignDate9061 { get => employeeSignDate9061; set => employeeSignDate9061 = value; }
        internal MyDate EmployerSignDate9061 { get => employerSignDate9061; set => employerSignDate9061 = value; }
        internal MyDate FelConvictionDate { get => felConvictionDate; set => felConvictionDate = value; }
        internal MyDate FelReleaseDate { get => felReleaseDate; set => felReleaseDate = value; }
        internal MyDate HireDate { get => hireDate; set => hireDate = value; }
        internal MyDate InfoDate { get => infoDate; set => infoDate = value; }
        internal MyDate OfferDate { get => offerDate; set => offerDate = value; }
        internal MyDate PostmarkDate { get => postmarkDate; set => postmarkDate = value; }
        internal MyDate RehireDate { get => rehireDate; set => rehireDate = value; }
        internal MyDate StartDate { get => startDate; set => startDate = value; }
        internal MyDate UnemploymentDeclarationDate { get => unemploymentDeclarationDate; set => unemploymentDeclarationDate = value; }
        internal MyDate UnemploymentEndDate { get => unemploymentEndDate; set => unemploymentEndDate = value; }
        internal MyDate UnemploymentStartDate { get => unemploymentStartDate; set => unemploymentStartDate = value; }
        public string AgeEligible { get => ageEligible; set => ageEligible = value; }
        public string ArraVetCategory { get => arraVetCategory; set => arraVetCategory = value; }
        public string ArraYouthCategory { get => arraYouthCategory; set => arraYouthCategory = value; }
        public string EmployeeSignatureOnFile { get => employeeSignatureOnFile; set => employeeSignatureOnFile = value; }
        public string EmployerCity { get => employerCity; set => employerCity = value; }
        public string EmployerCounty { get => employerCounty; set => employerCounty = value; }
        public string EmployerEmail { get => employerEmail; set => employerEmail = value; }
        public string EmployerFax { get => employerFax; set => employerFax = value; }
        public string EmployerFEIN { get => employerFEIN; set => employerFEIN = value; }
        public string EmployerName { get => employerName; set => employerName = value; }
        public string EmployerPhone { get => employerPhone; set => employerPhone = value; }
        public string EmployerPhoneDash { get => employerPhoneDash; set => employerPhoneDash = value; }
        public string EmployerPhoneExtension { get => employerPhoneExtension; set => employerPhoneExtension = value; }
        public string EmployerState { get => employerState; set => employerState = value; }
        public string EmployerStreet { get => employerStreet; set => employerStreet = value; }
        public string EmployerStreet2 { get => employerStreet2; set => employerStreet2 = value; }
        public string EmployerZip { get => employerZip; set => employerZip = value; }
        public string EmpowermentZone { get => empowermentZone; set => empowermentZone = value; }
        public string EmpowermentZoneSummerJob { get => empowermentZoneSummerJob; set => empowermentZoneSummerJob = value; }
        public string FelonFederalStateFS { get => felonFederalStateFS; set => felonFederalStateFS = value; }
        public string FelonFederalStatus { get => felonFederalStatus; set => felonFederalStatus = value; }
        public string FelonStateName { get => felonStateName; set => felonStateName = value; }
        public string FelonStateStatus { get => felonStateStatus; set => felonStateStatus = value; }
        public string FelonStatus { get => felonStatus; set => felonStatus = value; }
        public string Form9062 { get => form9062; set => form9062 = value; }
        public string FormCompletedBy { get => formCompletedBy; set => formCompletedBy = value; }
        public string KatrinaEmployee { get => katrinaEmployee; set => katrinaEmployee = value; }
        public string KatrinaEmployeeCity { get => katrinaEmployeeCity; set => katrinaEmployeeCity = value; }
        public string KatrinaEmployeeCounty { get => katrinaEmployeeCounty; set => katrinaEmployeeCounty = value; }
        public string KatrinaEmployeeState { get => katrinaEmployeeState; set => katrinaEmployeeState = value; }
        public string KatrinaEmployeeStreet { get => katrinaEmployeeStreet; set => katrinaEmployeeStreet = value; }
        public string KatrinaEmployeeZip { get => katrinaEmployeeZip; set => katrinaEmployeeZip = value; }
        public string KatrinaJobCounty { get => katrinaJobCounty; set => katrinaJobCounty = value; }
        public string KatrinaJobState { get => katrinaJobState; set => katrinaJobState = value; }
        public string KatrinaNewEmployee { get => katrinaNewEmployee; set => katrinaNewEmployee = value; }
        public string OccupationCodeONET { get => occupationCodeONET; set => occupationCodeONET = value; }
        public string OutOfStateBenCity { get => outOfStateBenCity; set => outOfStateBenCity = value; }
        public string OutOfStateBenRecipient { get => outOfStateBenRecipient; set => outOfStateBenRecipient = value; }
        public string OutOfStateBenState { get => outOfStateBenState; set => outOfStateBenState = value; }
        public string Pin8850 { get => pin8850; set => pin8850 = value; }
        public string Position { get => position; set => position = value; }
        public string PositionTitle { get => positionTitle; set => positionTitle = value; }
        public string Q1_8850 { get => q1_8850; set => q1_8850 = value; }
        public string Q2_8850 { get => q2_8850; set => q2_8850 = value; }
        public string Q3_8850 { get => q3_8850; set => q3_8850 = value; }
        public string Q4_8850 { get => q4_8850; set => q4_8850 = value; }
        public string Q5_8850 { get => q5_8850; set => q5_8850 = value; }
        public string Q6_8850 { get => q6_8850; set => q6_8850 = value; }
        public string Q7_8850 { get => q7_8850; set => q7_8850 = value; }
        public string Rehire { get => rehire; set => rehire = value; }
        public string RepresentativeName { get => representativeName; set => representativeName = value; }
        public string RequestID { get => requestID; set => requestID = value; }
        public string RuralRenewalCountyStatus { get => ruralRenewalCountyStatus; set => ruralRenewalCountyStatus = value; }
        public string SignatureOnFileForm9175 { get => signatureOnFileForm9175; set => signatureOnFileForm9175 = value; }
        public string Snap01 { get => snap01; set => snap01 = value; }
        public string Snap02 { get => snap02; set => snap02 = value; }
        public string SnapCity { get => snapCity; set => snapCity = value; }
        public string SnapRecipient { get => snapRecipient; set => snapRecipient = value; }
        public string SnapState { get => snapState; set => snapState = value; }
        public string SourceDocuments01 { get => sourceDocuments01; set => sourceDocuments01 = value; }
        public string SourceDocuments02 { get => sourceDocuments02; set => sourceDocuments02 = value; }
        public string SourceDocuments03 { get => sourceDocuments03; set => sourceDocuments03 = value; }
        public string SourceDocuments04 { get => sourceDocuments04; set => sourceDocuments04 = value; }
        public string SupplementalSecurity { get => supplementalSecurity; set => supplementalSecurity = value; }
        public string Tanf01 { get => tanf01; set => tanf01 = value; }
        public string Tanf02 { get => tanf02; set => tanf02 = value; }
        public string Tanf03 { get => tanf03; set => tanf03 = value; }
        public string Tanf04 { get => tanf04; set => tanf04 = value; }
        public string TanfRecipient { get => tanfRecipient; set => tanfRecipient = value; }
        public string TanfRecipientCity { get => tanfRecipientCity; set => tanfRecipientCity = value; }
        public string TanfRecipientState { get => tanfRecipientState; set => tanfRecipientState = value; }
        public string TargetGroup { get => targetGroup; set => targetGroup = value; }
        public string UnemploymentFederal_YN { get => unemploymentFederal_YN; set => unemploymentFederal_YN = value; }
        public string UnemploymentFedState_FS { get => unemploymentFedState_FS; set => unemploymentFedState_FS = value; }
        public string UnemploymentState_YN { get => unemploymentState_YN; set => unemploymentState_YN = value; }
        public string UnemploymentStateName { get => unemploymentStateName; set => unemploymentStateName = value; }
        public string UnemploymentStatus { get => unemploymentStatus; set => unemploymentStatus = value; }
        public string Version8850 { get => version8850; set => version8850 = value; }
        public string Version9061 { get => version9061; set => version9061 = value; }
        public string Veteran1Year { get => veteran1Year; set => veteran1Year = value; }
        public string Veteran4Weeks { get => veteran4Weeks; set => veteran4Weeks = value; }
        public string Veteran6Months { get => veteran6Months; set => veteran6Months = value; }
        public string VeteranDisabled { get => veteranDisabled; set => veteranDisabled = value; }
        public string VeteranSnapRecipient { get => veteranSnapRecipient; set => veteranSnapRecipient = value; }
        public string VeteranSnapState { get => veteranSnapState; set => veteranSnapState = value; }
        public string VeteranStatus { get => veteranStatus; set => veteranStatus = value; }
        public string VeteranSNAP { get => veteranSNAP; set => veteranSNAP = value; }
        public string VocRehabAgency { get => vocRehabAgency; set => vocRehabAgency = value; }
        public string VocRehabTicketToWork { get => vocRehabTicketToWork; set => vocRehabTicketToWork = value; }
        public string VocRehabVeteranAffairs { get => vocRehabVeteranAffairs; set => vocRehabVeteranAffairs = value; }
        public string VowToHireHeroes { get => vowToHireHeroes; set => vowToHireHeroes = value; }
        public string Wage { get => wage; set => wage = value; }
        public string WageCentsOnly { get => wageCentsOnly; set => wageCentsOnly = value; }
        public string WageDollarsOnly { get => wageDollarsOnly; set => wageDollarsOnly = value; }
        public bool IsReady { get => isReady; set => isReady = value; }
        public string Delimiter { get => delimiter; set => delimiter = value; }
        public string Positive { get => positive; set => positive = value; }
        public string Negative { get => negative; set => negative = value; }
        public MyEmployee Employee { get => employee; set => employee = value; }
        public MyEmployer Employer { get => employer; set => employer = value; }
        public MyState SubmissionState { get => submissionState; set => submissionState = value; }
        public List<string> ErrorList { get => errorList; set => errorList = value; }
        public List<string> ChangeList { get => changeList; set => changeList = value; }
        public int ErrorCount { get => errorCount; set => errorCount = value; }
        public bool Bypass { get => bypass; set => bypass = value; }

        public MyApp(int stateSelector)
        {
            // TODO assign state by comparing state selector int with contants state values e.g. STATE_AL
        }

        public bool ValidateApplication(int stateSelector)
        {
            bool appValid = true;

            // TODO Update the logic of passing and returning bool, is it necessary & useful?

            // Validate target group statuses
            appValid = ValidateVeteranStatus(appValid);
            appValid = ValidateSNAP(appValid);
            appValid = ValidateTANF(appValid);
            appValid = ValidateVocRehab(stateSelector, appValid);
            appValid = ValidateFelon(appValid);
            appValid = ValidateRRC_EZ(appValid);
            appValid = ValidateSSI(appValid);
            appValid = ValidateLongTermUnemployment(appValid);

            // Validate employee information
            if (appValid)
                appValid = ValidateEmployee(appValid);

            // Validate employer, consultant, etc
            if (appValid)
                appValid = ValidateEmployer(appValid, stateSelector);

            // Check for no target groups
            if (Q1_8850 == Negative && Q2_8850 == Negative && Q3_8850 == Negative && Q4_8850 == Negative
                && Q5_8850 == Negative && Q6_8850 == Negative && Q7_8850 == Negative)
            {
                ErrorList.Add("No target groups are selected.");
                ErrorCount++;
            }

            // If appValid remains true, return true and confirm app valid
            return appValid;
        }

        private bool ValidateFelon(bool appValid)
        {
            // Ex-Felon
            if (FelonStatus == Positive)
            {
                if (FelConvictionDate.ToString().Trim().Length < 1)
                {
                    ErrorList.Add("If applicant is felon, conviction date must be provided.");
                    ErrorCount++;
                }
                else if (FelConvictionDate.ToString().Trim().Length < 8)
                {
                    ErrorList.Add("Please check the format of the felon conviction date.");
                    ErrorCount++;
                }

                if (FelReleaseDate.ToString().Trim().Length < 1)
                {
                    ErrorList.Add("If applicant is felon, release date must be provided.");
                    ErrorCount++;
                }
                else if (FelConvictionDate.ToString().Trim().Length < 8)
                {
                    ErrorList.Add("Please check the format of the felon release date.");
                    ErrorCount++;
                }

                if (IsGreaterThan(FelConvictionDate, FelReleaseDate) > 0)
                {
                    ErrorList.Add("Felon conviction and release dates cannot be the same. Release date must be at least one day later than conviction.");
                    ErrorCount++;
                }

                if (FelonStateStatus != Positive && FelonFederalStatus != Positive)
                {
                    FelonStateStatus = Positive;
                    FelonFederalStatus = Negative;
                    felonFederalStateFS = "S";
                    ChangeList.Add("Update state/federal felony to state.");
                }
                else if (FelonFederalStatus == Positive)
                {
                    FelonStateStatus = Negative;
                    FelonFederalStatus = Positive;
                    felonFederalStateFS = "F";
                }
                else if (FelonStateStatus == Positive)
                {
                    FelonStateStatus = Positive;
                    FelonFederalStatus = Negative;
                    felonFederalStateFS = "S";
                }

                appValid = true;
            } // End Ex-Felon

            return appValid;
        }

        private bool ValidateLongTermUnemployment(bool appValid)
        {
            // Long Term Unemployment or LTU
            if (Q7_8850 == Positive)
            {
                if (UnemploymentStatus != Positive)
                {
                    UnemploymentStatus = Positive;
                    ChangeList.Add("Update 9061 Q23 to true for LTU.");
                }

                if (UnemploymentStateName.Trim() == "")
                {
                    UnemploymentStateName = Employee.State;
                    ChangeList.Add("Update 9061 Q23b from blank to employee's state of residence for LTU benefits.");
                }

                if (UnemploymentFedState_FS.Trim() == "" || (UnemploymentFedState_FS.Trim() != "F" && UnemploymentFedState_FS.Trim() != "S"))
                {
                    UnemploymentFedState_FS = "S";
                    ChangeList.Add("Update 9061 Q23b from blank to employee's state of residence for LTU benefits.");
                }

                if (UnemploymentState_YN.Trim() == "" && UnemploymentFederal_YN.Trim() == "")
                {
                    UnemploymentState_YN = Positive;
                    UnemploymentFederal_YN = Negative;
                    ChangeList.Add("Update 9061 Q23c from blank to assume employee's state of residence for LTU benefits.");
                }

                if (UnemploymentFederal_YN.Trim() == "")
                    UnemploymentFederal_YN = Negative;

                appValid = true;
            } // End Long Term Unemployment or LTU

            return appValid;
        }

        private bool ValidateRRC_EZ(bool appValid)
        {
            // Rural Renewal County RRC or Empowerment Zone EZ
            if (CheckIfEmpowermentZone() == true)
            {
                EmpowermentZone = Positive;
                ChangeList.Add("Update empowerment zone to true.");
            }

            if (CheckIfRuralRenewalCounty() == true)
            {
                RuralRenewalCountyStatus = Positive;
                Employee.County = GetNameOfCounty();
                ChangeList.Add("Update rural renewal community to true.");
            }

            if (EmpowermentZone == Positive || RuralRenewalCountyStatus == Positive || EmpowermentZoneSummerJob == Positive)
            {
                if (Q2_8850 != Positive)
                {
                    Q2_8850 = Positive;
                    ChangeList.Add("Update 8850 Q2 to true for EZ or RRC.");
                }
                appValid = true;
            }
            // End RRC or EZ
            return appValid;
        }

        private bool ValidateSNAP(bool appValid)
        {
            // SNAP Answers
            if (Snap01 == Positive || Snap02 == Positive)
            {
                Snap01 = Positive;
                Snap02 = Positive;

                if (SnapRecipient.Trim() == "")
                    SnapRecipient = Employee.GetNameFull();

                if (SnapState.Trim() == "")
                    SnapState = Employee.State;

                appValid = true;
            } // end SNAP

            return appValid;
        }

        private bool ValidateSSI(bool appValid)
        {
            // Social Supplemental Income or SSI
            if (SupplementalSecurity == Positive)
            {
                Q2_8850 = Positive;
                ChangeList.Add("Update 8850 Q2 to true for SSI.");
                appValid = true;
            }

            return appValid;
        }

        private bool ValidateTANF(bool appValid)
        {
            // TANF Answers
            if (Tanf01 == Positive || Tanf02 == Positive || Tanf03 == Positive || Tanf04 == Positive)
            {
                if (Q6_8850 == Negative)
                {
                    Q6_8850 = Positive;
                    ChangeList.Add("Update 8850 Q6 to positive for TANF.");
                }

                Tanf01 = Positive;
                Tanf02 = Positive;
                Tanf03 = Positive;
                Tanf04 = Positive;

                if (TanfRecipient.Trim() == "")
                {
                    TanfRecipient = Employee.GetNameFull();
                    ChangeList.Add("Update 9061 Q16c TANF recipient name from blank to employee name.");
                }

                if (TanfRecipientCity.Trim() == "")
                {
                    TanfRecipientState = Employee.State;
                    ChangeList.Add("Update 9061 Q16c from blank to employee state.");
                }

                if (TanfRecipientState.Trim() == "")
                {
                    TanfRecipientState = Employee.State;
                    ChangeList.Add("Update 9061 Q16c TANF recipient state from blank to employee state.");
                }

                appValid = true;
            } // end TANF

            return appValid;
        }

        private bool ValidateVeteranStatus(bool appValid)
        {
            // Veteran Status
            if (VeteranStatus == Positive)
            {
                if (Q3_8850 == Negative && Veteran1Year == Negative && Veteran6Months == Negative && VeteranDisabled == Negative && Veteran4Weeks == Negative)
                {
                    ErrorList.Add("At least one veteran target should be selected if the applicant is a veteran.");
                    appValid = false;
                }
            }
            else
            { // if veteran status == false
                // If vet unemployed 4 weeks is marked
                if (Veteran4Weeks == Positive)
                {
                    if (Q2_8850 != Positive)
                    {
                        Q2_8850 = Positive;
                        ChangeList.Add("Update 8850 Q2 for Unemployed Veteran 4 weeks");
                    }
                    if (VeteranStatus != Positive)
                    {
                        VeteranStatus = Positive;
                        ChangeList.Add("Updated 9061 Q13 for Veteran");
                    }
                    appValid = true;
                }

                // If vet disabled, left service within one year, or unemployed 6 months is marked
                if (Q3_8850 == Positive || Veteran1Year == Positive || Veteran6Months == Positive || VeteranDisabled == Positive)
                {
                    if (Q3_8850 == Positive)
                    {
                        Veteran6Months = Positive;
                        ChangeList.Add("Updated 9061 Q21 for Unemployed Veteran 6 months");
                        appValid = true;
                    }

                    // If left svc within one year, must also be disabled
                    if (Veteran1Year == Positive)
                    {
                        Q4_8850 = Positive;
                        VeteranDisabled = Positive;
                        ChangeList.Add("Updated 8850 Q4 for Veteran");
                        appValid = true;
                    }

                    // Mark 8850 question 5 if disabled vet and unempl 6 months are both true
                    if (Veteran6Months == Positive && VeteranDisabled == Positive)
                    {
                        Q5_8850 = Positive;
                        ChangeList.Add("Updated 8850 Q5 for Veteran");
                        appValid = true;
                    }

                    if (VeteranStatus != Positive)
                    {
                        VeteranStatus = Positive;
                        ChangeList.Add("Updated 9061 Q13 for Veteran");
                        appValid = true;
                    }
                }

                // if Vet Status still false and one of the target groups is true
                if (VeteranStatus == Negative && (Q3_8850 == Positive || Veteran1Year == Positive || Veteran6Months == Positive || VeteranDisabled == Positive || Veteran4Weeks == Positive))
                {
                    VeteranStatus = Positive;
                    ChangeList.Add("Updated 9061 Q13 for Veteran");
                    appValid = true;
                }
            } // end veteran status check

            return appValid;
        }

        private bool ValidateVocRehab(int stateSelector, bool appValid)
        {
            /* Vocational Rehabilitation
             * If any voc rehab answer is true, mark all true unless the state is known to reject multiple true answers
             */
            if (VocRehabAgency == Positive || VocRehabTicketToWork == Positive || VocRehabVeteranAffairs == Positive)
            {
                // Exclude the states that only accept one Voc rehab answer
                if (stateSelector == MyConst.STATE_PA || stateSelector == MyConst.STATE_TN)
                {
                    if (VeteranStatus == Positive)
                    {
                        if (VocRehabVeteranAffairs != Positive)
                        {
                            VocRehabVeteranAffairs = Positive;
                            changeList.Add("Update Vocational Rehab referral from Veteran Affairs to true.");
                            appValid = true;
                        }   

                        VocRehabAgency = Negative;
                        VocRehabTicketToWork = Negative;
                    }
                    else
                    {
                        VocRehabAgency = Positive;
                        VocRehabTicketToWork = Negative;
                        VocRehabVeteranAffairs = Negative;
                        appValid = true;
                    }
                    // Set all available voc rehab categories to true
                }
                else
                {
                    if (VocRehabAgency != Positive)
                    {
                        VocRehabAgency = Positive;
                        changeList.Add("Update Vocational Rehab to true.");
                        appValid = true;
                    }

                    if (VocRehabTicketToWork != Positive)
                    {
                        VocRehabTicketToWork = Positive;
                        changeList.Add("Update Vocational Rehab Ticket to Work to true.");
                        appValid = true;
                    }

                    if (VeteranStatus == Positive)
                    {
                        if (VocRehabVeteranAffairs != Positive)
                        {
                            VocRehabVeteranAffairs = Positive;
                            changeList.Add("Update Vocational Rehab referral from Veteran Affairs to true.");
                            appValid = true;
                        }                        
                    }
                    else
                    {
                        VocRehabVeteranAffairs = Negative;
                        changeList.Add("Update Vocational Rehab referral from Veteran Affairs to false for non-veteran.");
                    }
                }
            } // end Vocational Rehabilitation
            return appValid;
        }

        private string GetNameOfCounty()
        {
            string zip = Employee.Zip;
            // TODO Look up county proper spelling based on zip code
            throw new NotImplementedException();
        }

        public bool ValidateEmployee(bool appValid)
        {
            // Trim employee name elements. Padding length occurs at the state level when adding an app to the batch list
            if (Employee.FirstName.Trim().Length < 1)
            {
                // TODO request full name and address from user
                appValid = false;
                ErrorCount++;
                ErrorList.Add("Employee first name cannot be blank: " + Employee.LastName + GetSSNLast4());
            }
            else
                Employee.FirstName = Employee.FirstName.Trim();

            if (Employee.LastName.Trim().Length < 1)
            {
                // TODO request full name and address from user
                appValid = false;
                ErrorCount++;
                ErrorList.Add("Employee last name cannot be blank: " + Employee.FirstName + " (" + GetSSNLast4() + "), " + Employer.Fein);
            }
            else
                Employee.LastName = Employee.LastName.Trim();

            // Social Security Number
            Employee.Social.Replace("-", "");           // Remove hyphen(s)
            Employee.Social = Employee.Social.Trim();   // Remove leading or trailing spaces

            if (Employee.Social.Length > 0)
                Employee.Social = AddLeadingZeros(Employee.Social, 9);

            if (Employee.Social.Length < 1 || Employee.Social == "123456789" || Employee.Social == "987654321" || Employee.Social.Substring(0,8) == "0")
            {
                ErrorCount++;
                ErrorList.Add("Invalid or missing employee SSN: " + Employee.GetNameFull());
            }

            // Phone number
            Employee.Phone = Employee.Phone.Trim();
            foreach (char a in Employee.Phone)
            {
                // Substitute hyphen for invalid characters
                if (char.IsDigit(a) == false)
                {
                    // Check if character is a digit. If not, replace with a hyphen that will be removed in the next step
                    Employee.Phone.Replace(a, '-');
                }
            }

            // Remove hyphen(s)
            Employee.Phone.Replace("-", "");

            // If employee phone is invalid
            if (Employee.Phone.Length != 10)
            {
                Employee.Phone = AddBlankSpaces(10);
                ChangeList.Add("Remove invalid employee phone number.");
            }

            // Address Information
            if (Employee.Street.Trim().Length < 1 && Employee.Street2.Trim().Length > 5)
            { // if employee entered info in street 2 instead of street 1, move the info to street 1
                Employee.Street = Employee.Street2.Trim();
                Employee.Street2 = "";
                ChangeList.Add("Moved street address from line 2 up to line 1. Line 1 was blank.");
            }

            if (Employee.State.Trim() == "" || Employee.City.Trim() == ""
                || (Employee.Street.Trim() == "" && Employee.Street2.Trim() == ""))
            {
                ErrorCount++;
                ErrorList.Add("Employee address cannot be incomplete.");
            }

            return true;
        }

        // Validate employer
        public bool ValidateEmployer(bool appValid, int stateSelector)
        {
            bool coloradoState = false;
            bool kentuckyState = false;
            
            for (int i = 0; i < MyConst.COLORADO_STATES.Length; i++)
            {
                if (stateSelector == MyConst.COLORADO_STATES[i])
                    coloradoState = true;
            }

            for (int i = 0; i < MyConst.KENTUCKY_STATES.Length; i++)
            {
                if (stateSelector == MyConst.KENTUCKY_STATES[i])
                    kentuckyState = true;
            }

            foreach (char a in Employer.Fein)
            {
                // Substitute hyphen for invalid characters
                if (char.IsDigit(a) == false)
                {
                    // Check if character is a digit. If not, replace with a hyphen that will be removed in the next step
                    Employer.Fein.Replace(a, '-');
                }
            }
            Employer.Fein.Replace("-", "");

            if (Employer.Fein.Trim().Length < 9)
            {
                Employer.Fein.AddLeadingZeros(9);
                ChangeList.Add("Added leading zero(s) to employer FEIN.");
            }

            foreach (char a in Employer.Phone)
            {
                // Substitute hyphen for invalid characters
                if (char.IsDigit(a) == false)
                {
                    // Check if character is a digit. If not, replace with a hyphen that will be removed in the next step
                    Employer.Phone.Replace(a, '-');
                }
            }
            Employer.Phone.Replace("-", "");

            // In CO states the employer name, etc. is optional unless setting up a new employer
            if (coloradoState)
            {
                Employer.Name = EmployerName.Trim();
                Employer.Street1 = Employer.Street1.Trim();
                Employer.Street2 = Employer.Street2.Trim();
                Employer.City = Employer.City.Trim();
                Employer.State = Employer.State.Trim();
                Employer.ZipCode = Employer.ZipCode.Trim();
            } else if (kentuckyState)
            {
                // TODO Add special handling if necessary for KY stype states
            } else
            {
                // TODO Validate normal employer
                Employer.Name = EmployerName.Trim();
                if (Employer.Name.Length < 1)
                {
                    ErrorCount++;
                    ErrorList.Add("Employer name is blank.");
                }

                Employer.Street1 = Employer.Street1.Trim();
                Employer.Street2 = Employer.Street2.Trim();
                if (Employer.Street1.Length < 1)
                {
                    // If both street address fields are blank, flag error. Otherwise move street address 2 up to first line
                    if (Employer.Street2.Length < 1)
                    {
                        ErrorCount++;
                        ErrorList.Add("Employer street address is blank.");
                    } else
                    {
                        Employer.Street1 = Employer.Street2;
                        Employer.Street2 = "";
                        ChangeList.Add("Moved employer street address from line 2 to line 1.");
                    }
                }

                Employer.City = Employer.City.Trim();
                if (Employer.City.Length < 1)
                {
                    ErrorCount++;
                    ErrorList.Add("Employer city is blank.");
                }

                Employer.State = Employer.State.Trim();
                if (Employer.State.Length < 1)
                {
                    ErrorCount++;
                    ErrorList.Add("Employer state is blank.");
                }

                Employer.ZipCode = Employer.ZipCode.Trim();
                Employer.ZipCode.Replace("-", "");
                if (Employer.ZipCode.Length < 1)
                {
                    ErrorCount++;
                    ErrorList.Add("Employer zip code is blank.");
                } else if(Employer.ZipCode.Length > 5)
                {
                    Employer.ZipCode = Employer.ZipCode.Substring(0, 5);
                } else if(Employer.ZipCode.Length < 5)
                {
                    Employer.ZipCode.AddLeadingZeros(5);
                }

                CheckEmployerPhone();   // Employer phone is handled in MyBatch

                Employer.PhoneExtension = Employer.PhoneExtension.Trim();
                Employer.PhoneExtension.AddLeadingZeros(4);
            }

            return appValid;
        }

        // Will substitute default phone number if given phone is invalid
        public void CheckEmployerPhone()
        {
            bool replacePhoneNumber = false;

            // Remove hyphens
            Employer.Phone.Replace("-", "");

            // If phone is not present or invalid (less than 10 digits), substitute consultant phone number 
            if (Employer.Phone == null || Employer.Phone.Length < 10)
            {
                replacePhoneNumber = true;
            }

            // Check for invalid characters
            foreach(char a in Employer.Phone)
            {
                if (char.IsDigit(a) == false)
                    replacePhoneNumber = true;
            }

            // Remove phone number if invalid. In MyBatch, will replace with consultant phone number if necessary
            if (replacePhoneNumber == true)
            {
                Employer.Phone = AddBlankSpaces(10);
            }
        }

        public string GetSSNLast4()
        {
            return Employee.Social.Substring(Employee.Social.Trim().Length - 4);
        }

        public string AddTrailingSpaces(string input, int count)
        {
            while (input.Length < count)
                input = input + " ";
            return input;
        }

        public string AddBlankSpaces(int count)
        {
            string spaces = "";
            while (spaces.Length < count)
                spaces = spaces + " ";
            return spaces;
        }

        public string AddLeadingZeros(string input, int length)
        {
            while (input.Length < length)
                input = "0" + input;

            return input;
        }

        /*  IsGreaterThan(begindate,enddate)
         *  Compares two dates and returns int to indicate results.
         *  0 = false
         *  1 = true
         *  -1 = error, possibly invalid date(s)
         */
        private int IsGreaterThan(MyDate begin, MyDate end)
        {
            try
            {
                if (Int32.Parse(end.Year) > Int32.Parse(begin.Year))
                    return 1;
                else if (Int32.Parse(end.Month) > Int32.Parse(begin.Year))
                    return 1;
                else if (Int32.Parse(end.Day) > Int32.Parse(begin.Month))
                    return 1;
                else
                    return 0;
            }
            catch (Exception e)
            {
                // TODO Write error message to FormAppUpdate error message box
                WriteError(e);
                return -1;
            }
        }

        private bool CheckIfEmpowermentZone()
        {
            if (SubmissionState.EmpowermentZoneList.Contains(Employee.State + employee.City))
                return true;
            else
                return false;
        }

        private bool CheckIfRuralRenewalCounty()
        {
            if (SubmissionState.RuralRenewalCountyNames.Contains(Employee.State + employee.County))
                return true;
            else
                if (SubmissionState.RuralRenewalCountyZipCodes.Contains(Employee.Zip.Substring(0,5)))
                return true;
            else
                return false;
        }

        public MyApp CopyApplication(MyApp app)
        {
            return app;
        }

        public void UpdateApplication()
        {
            // TODO push all text/data fields from FormAppUpdate into app fields
            // TODO re-validate application
        }
    }
}
