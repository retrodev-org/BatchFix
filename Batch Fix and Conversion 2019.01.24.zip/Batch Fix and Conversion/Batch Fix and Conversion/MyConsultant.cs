﻿using System;
namespace Batch_Fix_and_Conversion
{
    class MyConsultant
    {
        private string name;
        private string address;
        private string city;
        private string state;
        private string zipCode;
        private string phone;
        private string fax;
        private string email;
        private string signerName;
        private string signerTitle;

        MyConsultant(string consultantName)
        {

            if (consultantName == "EF")
            {
                // Assign values based on public constant strings for each company
                Name = MyConst.EF_NAME;
                Address = MyConst.EF_ADDRESS;
                City = MyConst.EF_CITY;
                State = MyConst.EF_STATE;
                ZipCode = MyConst.EF_ZIP;
                Phone = MyConst.EF_PHONE;
                Fax = MyConst.EF_FAX;
                Email = MyConst.EF_EMAIL;
                SignerName = MyConst.EF_SIGNER;
                SignerTitle = MyConst.EF_SIGNER_TITLE;

            }
            else if (consultantName == "NTC")
            {
                // Assign values based on public constant strings for each company
                Name = MyConst.NTC_NAME;
                Address = MyConst.NTC_ADDRESS;
                City = MyConst.NTC_CITY;
                State = MyConst.NTC_STATE;
                ZipCode = MyConst.NTC_ZIP;
                Phone = MyConst.NTC_PHONE;
                Fax = MyConst.NTC_FAX;
                Email = MyConst.NTC_EMAIL;
                SignerName = MyConst.NTC_SIGNER;
                SignerTitle = MyConst.NTC_SIGNER_TITLE;
            }
            else
            {
                // todo error message for invalid consultant
                Console.WriteLine("Invalid consultant company name. Must be EF or NTC.");
            }
        }

        public string Name { get => name; set => name = value; }
        public string Address { get => address; set => address = value; }
        public string City { get => city; set => city = value; }
        public string State { get => state; set => state = value; }
        public string ZipCode { get => zipCode; set => zipCode = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Fax { get => fax; set => fax = value; }
        public string Email { get => email; set => email = value; }
        public string SignerName { get => signerName; set => signerName = value; }
        public string SignerTitle { get => signerTitle; set => signerTitle = value; }
    }
}
