﻿using System;

namespace BatchFixer
{
	class Program
	{
		static void Main(string[] args)
		{
            string inputState;

            // DELIMITERS
            public readonly string DELMT_PIPE = "|";
            public readonly string DELMT_COMMA = ",";
            public readonly string DELMT_HYPHEN = "-";
            public readonly string DELMT_SPACE = " ";

			// Gather state from user
			Console.Write("Input state: ");
			inputState = Console.Read().ToString();
			Console.WriteLine("Processing for " + inputState);
		}
	}
}
