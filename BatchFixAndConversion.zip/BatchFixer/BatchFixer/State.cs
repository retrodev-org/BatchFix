﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BatchFixer
{
	class State
	{
        // STATES
        const int STATE_AK = 1;
        const int STATE_AL = 2;
        const int STATE_AR = 3;
        const int STATE_AZ = 4;
        const int STATE_CA = 5;
        const int STATE_CO = 6;
        const int STATE_CT = 7;
        const int STATE_DC = 8;
        const int STATE_DE = 9;
        const int STATE_FL = 10;
        const int STATE_GA = 11;
        const int STATE_GUAM = 12;
        const int STATE_HI = 13;
        const int STATE_IA = 14;
        const int STATE_ID = 15;
        const int STATE_IL = 16;
        const int STATE_IN = 17;
        const int STATE_KS = 18;
        const int STATE_KY = 19;
        const int STATE_LA = 20;
        const int STATE_MA = 21;
        const int STATE_MD = 22;
        const int STATE_ME = 23;
        const int STATE_MI = 24;
        const int STATE_MN = 25;
        const int STATE_MO = 26;
        const int STATE_MS = 27;
        const int STATE_MT = 28;
        const int STATE_NC = 29;
        const int STATE_ND = 30;
        const int STATE_NE = 31;
        const int STATE_NH = 32;
        const int STATE_NJ = 33;
        const int STATE_NM = 34;
        const int STATE_NV = 35;
        const int STATE_NY = 36;
        const int STATE_OH = 37;
        const int STATE_OK = 38;
        const int STATE_OR = 39;
        const int STATE_PA = 40;
        const int STATE_PR = 41;
        const int STATE_RI = 42;
        const int STATE_SC = 43;
        const int STATE_SD = 44;
        const int STATE_TN = 45;
        const int STATE_TX = 46;
        const int STATE_UT = 47;
        const int STATE_VA = 48;
        const int STATE_VT = 49;
        const int STATE_WA = 50;
        const int STATE_WI = 51;
        const int STATE_WV = 52;
        const int STATE_WY = 53;

        private string name;
		private string delimiter;			// delimiter symbol (comma, carat, or space)
		private string answerTrue;			// 1, Y, or TRUE - sets format for state
		private string answerFalse;			// 0, N, or FALSE - sets format for state
		private Array zipCodesRRC;			// list of zip codes that qualify for RRC
		private Array citiesEmpowerment;    // list of cities that are empowerment zones
		
		public void InitializeState(int thisState){
		switch (thisState){
			case STATE_AK:
				// TODO Verify these answers. This is just an example.
				name = "AK";
				delimiter = DELMT_COMMA;
				answerTrue = TRUE_Y;
				answerFalse = FALSE_N;
				// Create RRC_AK.csv from combined lists of EZ and zip codes
				// Individual file per state = faster read time
				// TODO load citiesEmpowerment from RRC_AK.csv
				// TODO load zipCodesRRC from RRC_AK.csv
				break;
			case STATE_AL:
				break;
			case STATE_AR:
				break;
			case STATE_AZ:
				break;
			case STATE_CA:
				break;
			case STATE_CO:
				break;
			case STATE_CT:
				break;
			case STATE_DC:
				break;
			case STATE_DE:
				break;
			case STATE_FL:
				break;
			case STATE_GA:
				break;
			case STATE_GUAM:
				break;
			case STATE_HI:
				break;
			case STATE_IA:
				break;
			case STATE_ID:
				break;
			case STATE_IL:
				break;
			case STATE_IN:
				break;
			case STATE_KS:
				break;
			case STATE_KY:
				break;
			case STATE_LA:
				break;
			case STATE_MA:
				break;
			case STATE_MD:
				break;
			case STATE_ME:
				break;
			case STATE_MI:
				break;
			case STATE_MN:
				break;
			case STATE_MO:
				break;
			case STATE_MS:
				break;
			case STATE_MT:
				break;
			case STATE_NC:
				break;
			case STATE_ND:
				break;
			case STATE_NE:
				break;
			case STATE_NH:
				break;
			case STATE_NJ:
				break;
			case STATE_NM:
				break;
			case STATE_NV:
				break;
			case STATE_NY:
				break;
			case STATE_OH:
				break;
			case STATE_OK:
				break;
			case STATE_OR:
				break;
			case STATE_PA:
				break;
			case STATE_PR:
				break;
			case STATE_RI:
				break;
			case STATE_SC:
				break;
			case STATE_SD:
				break;
			case STATE_TN:
				break;
			case STATE_TX:
				break;
			case STATE_UT:
				break;
			case STATE_VA:
				break;
			case STATE_VT:
				break;
			case STATE_WA:
				break;
			case STATE_WI:
				break;
			case STATE_WV:
				break;
			case STATE_WY:
				break;
			}
		}
	}
	
	}
