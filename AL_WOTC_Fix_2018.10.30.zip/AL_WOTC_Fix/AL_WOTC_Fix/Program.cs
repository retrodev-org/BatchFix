﻿/*
 * Created by SharpDevelop.
 * User: wholland
 * Date: 10/26/2018
 * Time: 3:45 PM
 */
using System;
using System.IO;
using System.Collections.Generic; 

namespace AL_WOTC_Fix
{
	class Program
	{
		public static void Main(string[] args)
		{
			int counter = 0;
			string[] lines = {null};
			string filePath = args[0];
			string thisState = "AL";
			
			var list = new List<string>();
			var fileStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

			// Read file into array of lines
			using (var streamReader = new StreamReader(fileStream))
			{
				try {
					string line;
					while ((line = streamReader.ReadLine()) != null)
					{
						list.Add(line);
						Console.WriteLine(line.Substring(0, 15));
						counter++;
					}
				} catch (Exception e) {
					Console.WriteLine("Encountered error reading line " + (counter + 1) + ". Error: " + e.ToString());
				}

				try
				{
					for (int i = 0; i < list.Count; i++)
					{
						// Copy input List into actual string array
						lines[i] = list[i].ToString();
					}
				} catch(Exception e)
				{
					Console.WriteLine("Encountered error writing line " + (counter + 1) + " to string array. Error: " + e.ToString());
				}
				
				
			}
			
			try {
				lines = list.ToArray();
			} catch(Exception e){
				Console.WriteLine("Encountered error converting lines to array. Error: " + e.ToString());
			}

			// Parse Data - Alabama

			for (int i = 0; i < lines.Length; i++)
			{
				if (thisState == "AL")
				{
					string consultantID = list[i].Substring(0, 12);
					string fein = list[i].Substring(12, 9);
					string ssn = list[i].Substring(21, 9);
					string employeeFirstName = list[i].Substring(30, 10);
					string employeeMiddleName = list[i].Substring(40, 1);
					string employeeLastName = list[i].Substring(41, 19);
					string employeeStreet1 = list[i].Substring(60, 30);
					string employeeCity = list[i].Substring(90, 20);
					string employeeState = list[i].Substring(110, 2);
					string employeeZip = list[i].Substring(112, 5);
					string employeePhone = list[i].Substring(117, 10);
					string employeeDOB = list[i].Substring(127, 8);
					string katrinaEmployee = list[i].Substring(135, 1);
					string katrinaCounty = list[i].Substring(136, 20);
					string katrinaStreet = list[i].Substring(156, 30);
					string katrinaCity = list[i].Substring(186, 20);
					string katrinaState = list[i].Substring(206, 2);
					string katrinaZip = list[i].Substring(208, 5);
					
				}
			}


			{
				Console.WriteLine("Error: Invalid state abbreviation in ReadLinesToData.");
			}


			Console.Write("Press any key to continue . . . ");
			Console.ReadKey(true);
		}
	}
}